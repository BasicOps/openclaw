#!/usr/bin/env bash
set -euo pipefail

echo 'TARGET AGENT: thor'
echo 'READ ONLY: /tmp/thor-bundle-test-packaged/NEXT-STEPS.md'
echo 'Finishing local install for thor...'

/usr/bin/python3 /home/hjhlarsen/basicops-agent-bundle/scripts/basicops_mcp.py --as thor get-self-context --agent-id thor --cache-path /home/hjhlarsen/.cache/basicops-agents/thor-self.json --refresh

/usr/bin/python3 /home/hjhlarsen/basicops-agent-bundle/scripts/render_basicops_hook_config.py --template /home/hjhlarsen/basicops-agent-bundle/templates/prompts/basicops-worker-policy.template.md --openclaw-config /home/hjhlarsen/.openclaw/openclaw.json --self-context-cache /home/hjhlarsen/.cache/basicops-agents/thor-self.json --agent-id thor --basicops-profile thor --hook-path basicops-thor --display-name Thor --mapping-name "BasicOps Thor Hook" --wrapper-path /home/hjhlarsen/basicops-agent-bundle/scripts/basicops_mcp.py --message-template 'Thor structured runtime dispatch.' --deliver false --thinking off --session-key 'hook:thor:{{payload.event}}:{{payload.timestamp}}' --transform-module thor-structured-runtime-hook.js --mode render --stdout summary

/usr/bin/python3 /home/hjhlarsen/basicops-agent-bundle/scripts/render_basicops_hook_config.py --template /home/hjhlarsen/basicops-agent-bundle/templates/prompts/basicops-worker-policy.template.md --openclaw-config /home/hjhlarsen/.openclaw/openclaw.json --self-context-cache /home/hjhlarsen/.cache/basicops-agents/thor-self.json --agent-id thor --basicops-profile thor --hook-path basicops-thor --display-name Thor --mapping-name "BasicOps Thor Hook" --wrapper-path /home/hjhlarsen/basicops-agent-bundle/scripts/basicops_mcp.py --message-template 'Thor structured runtime dispatch.' --deliver false --thinking off --session-key 'hook:thor:{{payload.event}}:{{payload.timestamp}}' --transform-module thor-structured-runtime-hook.js --mode apply --backup

openclaw gateway restart
openclaw gateway status

systemctl --user daemon-reload
systemctl --user enable --now basicops-preack@thor.service
systemctl --user status basicops-preack@thor.service --no-pager

export OPENCLAW_HOOKS_TOKEN="$(/usr/bin/python3 - <<'PY'
import json
from pathlib import Path
cfg = json.loads(Path("/home/hjhlarsen/.openclaw/openclaw.json").expanduser().read_text())
hooks = cfg.get('hooks') if isinstance(cfg.get('hooks'), dict) else {}
value = hooks.get('token') if isinstance(hooks.get('token'), str) else ''
print(value.strip())
PY
)"
curl -i -sS http://127.0.0.1:18789/hooks/basicops-thor -H "Authorization: Bearer ${OPENCLAW_HOOKS_TOKEN:?set OPENCLAW_HOOKS_TOKEN first}" -H 'Content-Type: application/json' --data-binary '{}'
