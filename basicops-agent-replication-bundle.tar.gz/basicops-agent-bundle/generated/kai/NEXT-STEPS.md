# Next steps for kai

Generated files in this folder:
- kai.env
- basicops-preack@.service
- kai.values.env
- kai.openclaw-agent.json
- kai.basicops-personas.example.json
- install-context.json
- OPENCLAW-INSTALL-PROMPT.txt
- AFTER-GATEWAY-RESTART.txt
- INSTALL-LIVE-FILES.sh
- FINISH-LOCAL-INSTALL.sh
- PRECHECK-AGENT-INSTALL.sh

## Key values

- BasicOps profile: `kai`
- public webhook path: `/webhooks/basicops-kai`
- local shim target: `127.0.0.1:18899`
- OpenClaw hook target: `127.0.0.1:18789/hooks/basicops-kai`

## Before you begin

Important: files in this generated folder are not live yet. They do not affect the running service until you copy them into their final locations.

If you want the local OpenClaw assistant to guide the rest of the install, paste the contents of `OPENCLAW-INSTALL-PROMPT.txt` into that assistant after you skim this file once.

Target agent safety rail:
- TARGET AGENT: `kai`
- READ ONLY: `/home/hjhlarsen/basicops-agent-bundle/generated/kai/NEXT-STEPS.md`
- do not use another agent's generated folder for this install

Read this file top to bottom once, then work through the steps in order:

1. Finish BasicOps account and persona setup.
2. Run the quick sanity checks and detect whether a reverse proxy already exists.
3. Copy the generated files into place with `INSTALL-LIVE-FILES.sh`.
4. Register the OpenClaw agent if needed, then restart the gateway.
5. Run `PRECHECK-AGENT-INSTALL.sh` and clear any FAIL lines.
6. Finish local install with `FINISH-LOCAL-INSTALL.sh`.
7. Re-run `PRECHECK-AGENT-INSTALL.sh` until local checks pass.
8. Configure the public reverse proxy.
9. Test the public webhook path from outside the server.
10. Point BasicOps at that same public webhook path.

## Registration status

- agent registration: already added to `agents.list` in `/home/hjhlarsen/.openclaw/openclaw.json`
- config backup: `/home/hjhlarsen/.openclaw/openclaw.json.bak.20260425T165018Z`

## 1. BasicOps login and persona setup

If this is a brand new BasicOps-backed agent, do these steps first:

1. Log in to BasicOps in the browser.
2. Create the agent user if it does not already exist.
3. Create an API key for that agent user.
4. Copy the API key somewhere safe.

The bundle cannot do those BasicOps-side account steps for you.

Next you will create or update `basicops-personas.json`. That file establishes the connection between this OpenClaw agent and the BasicOps agent user by storing the BasicOps API key under the selected profile name.

Typical persona file path:

```bash
/home/hjhlarsen/.config/basicops-agents/basicops-personas.json
```

Create the directory first if needed:

```bash
mkdir -p /home/hjhlarsen/.config/basicops-agents
```

If this is the first agent on the machine, you can start from the generated example file in this folder. It already uses profile `kai`, so you only need to replace `YOUR_BASICOPS_API_KEY`:

```bash
cp /home/hjhlarsen/basicops-agent-bundle/generated/kai/kai.basicops-personas.example.json /home/hjhlarsen/.config/basicops-agents/basicops-personas.json
```

Add or update the persona entry for profile `kai` so it uses the real API key:

```json
{
  "personas": {
    "kai": {
      "headers": {
        "Authorization": "Bearer YOUR_BASICOPS_API_KEY"
      }
    }
  }
}
```

Keep the profile name `kai` exactly consistent with the commands in this bundle.

## 2. Quick sanity checks

```bash
/usr/bin/python3 --version
mcporter --version
openclaw status
test -f /home/hjhlarsen/basicops-agent-bundle/scripts/basicops_mcp.py && echo 'wrapper ok' || echo 'wrapper missing'
test -f /home/hjhlarsen/basicops-agent-bundle/scripts/preack_webhook.py && echo 'preack ok' || echo 'preack missing'
test -f /home/hjhlarsen/.config/basicops-agents/basicops-personas.json && echo 'personas ok' || echo 'personas missing'
systemctl --user status --no-pager >/dev/null && echo 'systemd user ok' || echo 'systemd user unavailable'
```

Before planning any public setup work, also detect whether the machine already has a reverse proxy installed and listening:

```bash
command -v caddy >/dev/null && echo 'proxy: caddy already installed' || echo 'proxy: caddy not found'
command -v nginx >/dev/null && echo 'proxy: nginx already installed' || echo 'proxy: nginx not found'
command -v traefik >/dev/null && echo 'proxy: traefik already installed' || echo 'proxy: traefik not found'
ss -ltnp 2>/dev/null | grep -E ':(80|443) ' || true
```

If any of those commands fail, go back to `QUICKSTART.md` and fix the prerequisites before continuing.
If `personas missing` appears above, do not continue to `get-self-context` until `/home/hjhlarsen/.config/basicops-agents/basicops-personas.json` exists and contains the `kai` profile.

## 3. Review and copy the generated files into place

Review and edit `kai.env` if any placeholder paths or tokens still need changes.

This is the step that makes the new values live. If you skip it, the running service may still use older values from an already-installed env file.

Recommended idempotent install command:

```bash
./INSTALL-LIVE-FILES.sh
```

Manual equivalent:

```bash
mkdir -p ~/.config/basicops-agents ~/.config/systemd/user /home/hjhlarsen/.cache/basicops-agents /home/hjhlarsen/.config/systemd/user/openclaw-gateway.service.d
cp /home/hjhlarsen/basicops-agent-bundle/generated/kai/kai.env ~/.config/basicops-agents/kai.env
cp /home/hjhlarsen/basicops-agent-bundle/generated/kai/basicops-preack@.service /home/hjhlarsen/.config/systemd/user/basicops-preack@.service
systemctl --user daemon-reload
```

After the copy step, confirm the exact live paths now exist:

```bash
test -f /home/hjhlarsen/.config/basicops-agents/kai.env && echo 'PASS live env exists: /home/hjhlarsen/.config/basicops-agents/kai.env' || echo 'FAIL live env missing: /home/hjhlarsen/.config/basicops-agents/kai.env'
test -f /home/hjhlarsen/.config/systemd/user/basicops-preack@.service && echo 'PASS live service exists: /home/hjhlarsen/.config/systemd/user/basicops-preack@.service' || echo 'FAIL live service missing: /home/hjhlarsen/.config/systemd/user/basicops-preack@.service'
```

## 4. Register the OpenClaw agent and restart the gateway

The hook renderer validates that `kai` already exists in `agents.list`. That prevents a broken route where a hook exists for an agent ID that OpenClaw does not actually know about.

This step is already complete for `kai`.

Minimum checks before moving on:
- `agents.list` contains an object with `id` = `kai`
- its `workspace` is `/home/hjhlarsen/.openclaw/workspace-kai`
- its runtime `cwd` is `/home/hjhlarsen/.openclaw/workspace-kai` under `runtime.acp.cwd`
- for ACP agents, do **not** put `cwd` under `runtime.cwd`

If you added or changed `agents.list`, restart the OpenClaw gateway before live testing so the runtime definitely picks up the updated config:

```bash
openclaw gateway restart
openclaw gateway status
```

Important restart boundary: restarting the gateway can interrupt the assistant session that is guiding the install. If that happens, do not restart it again by reflex. Paste `AFTER-GATEWAY-RESTART.txt` into the assistant, run the checks it lists, and resume at Step 5 unless those checks prove you are already farther along.

## 5. Agent-specific local precheck

Run this before you do any deeper troubleshooting. It checks the exact agent profile, live copied files, agent registration shape, hook mapping, and local hook path:

```bash
./PRECHECK-AGENT-INSTALL.sh
```

## 6. Create self-context

This calls the BasicOps MCP server using the authorization from `basicops-personas.json` and returns information about the connected BasicOps agent user. That information is cached and reused in the later hook-rendering steps.

```bash
/usr/bin/python3 /home/hjhlarsen/basicops-agent-bundle/scripts/basicops_mcp.py \
  --as kai \
  get-self-context \
  --agent-id kai \
  --cache-path /home/hjhlarsen/.cache/basicops-agents/kai-self.json \
  --refresh
```

Expected output should include `userId`, `displayName`, `email`, `timeZone`, `dateFormat`, and `timeFormat`.

Hard stop check: confirm the resolved `displayName` and `email` belong to the intended BasicOps agent user for this setup. If it resolves to a previous agent user or the wrong person, stop immediately, fix the API key in `basicops-personas.json`, and rerun this step before you touch hook mappings or webhooks.

## 7. Preview and apply the OpenClaw hook mapping

Start with the compact summary first. It is easier to read than the full diff:

```bash
/usr/bin/python3 /home/hjhlarsen/basicops-agent-bundle/scripts/render_basicops_hook_config.py \
  --template /home/hjhlarsen/basicops-agent-bundle/templates/prompts/basicops-worker-policy.template.md \
  --openclaw-config /home/hjhlarsen/.openclaw/openclaw.json \
  --self-context-cache /home/hjhlarsen/.cache/basicops-agents/kai-self.json \
  --agent-id kai \
  --basicops-profile kai \
  --hook-path basicops-kai \
  --display-name Kai \
  --mapping-name "BasicOps Kai Hook" \
  --wrapper-path /home/hjhlarsen/basicops-agent-bundle/scripts/basicops_mcp.py \
  --mode render \
  --stdout summary
```

Quick checklist for the summary output:
- hookPath should be `basicops-kai`
- agentId should be `kai`
- agentRegistered should be `true`
- mappingName should be `BasicOps Kai Hook`
- basicopsProfile should be `kai`
- warnings should be empty, or clearly understood before you continue

If you want the full diff as well, run:

```bash
/usr/bin/python3 /home/hjhlarsen/basicops-agent-bundle/scripts/render_basicops_hook_config.py \
  --template /home/hjhlarsen/basicops-agent-bundle/templates/prompts/basicops-worker-policy.template.md \
  --openclaw-config /home/hjhlarsen/.openclaw/openclaw.json \
  --self-context-cache /home/hjhlarsen/.cache/basicops-agents/kai-self.json \
  --agent-id kai \
  --basicops-profile kai \
  --hook-path basicops-kai \
  --display-name Kai \
  --mapping-name "BasicOps Kai Hook" \
  --wrapper-path /home/hjhlarsen/basicops-agent-bundle/scripts/basicops_mcp.py \
  --mode render \
  --stdout diff
```

When the summary looks right, apply the hook mapping with backup:

```bash
/usr/bin/python3 /home/hjhlarsen/basicops-agent-bundle/scripts/render_basicops_hook_config.py \
  --template /home/hjhlarsen/basicops-agent-bundle/templates/prompts/basicops-worker-policy.template.md \
  --openclaw-config /home/hjhlarsen/.openclaw/openclaw.json \
  --self-context-cache /home/hjhlarsen/.cache/basicops-agents/kai-self.json \
  --agent-id kai \
  --basicops-profile kai \
  --hook-path basicops-kai \
  --display-name Kai \
  --mapping-name "BasicOps Kai Hook" \
  --wrapper-path /home/hjhlarsen/basicops-agent-bundle/scripts/basicops_mcp.py \
  --hooks-token 082533d9f6b900e05ed9884ac8c655db6715370ee5909a40 \
  --mode apply \
  --backup
```

## 8. Validate hook prerequisites and load OPENCLAW_HOOKS_TOKEN

Quick checks:

```bash
/usr/bin/python3 - <<'PY'
import json
from pathlib import Path
cfg = json.loads(Path("/home/hjhlarsen/.openclaw/openclaw.json").expanduser().read_text())
hooks = cfg.get('hooks') if isinstance(cfg.get('hooks'), dict) else {}
gateway = cfg.get('gateway') if isinstance(cfg.get('gateway'), dict) else {}
auth = gateway.get('auth') if isinstance(gateway.get('auth'), dict) else {}
hooks_enabled = hooks.get('enabled')
hooks_token = hooks.get('token') if isinstance(hooks.get('token'), str) else None
gateway_token = auth.get('token') if isinstance(auth.get('token'), str) else None
print(f'hooks.enabled={hooks_enabled!r}')
print(f'hooks.token in config={bool(hooks_token and hooks_token.strip())}')
print(f'gateway.auth.token in config={bool(gateway_token and gateway_token.strip())}')
if hooks_token and gateway_token:
    print(f'hooks.token matches gateway.auth.token={hooks_token.strip() == gateway_token.strip()}')
else:
    print('hooks.token matches gateway.auth.token=unknown (one or both may come from env or SecretRef)')
ok = True
if hooks_enabled is not True:
    ok = False
if not (hooks_token and hooks_token.strip()):
    ok = False
if hooks_token and gateway_token and hooks_token.strip() == gateway_token.strip():
    ok = False
print('PASSED' if ok else 'FAILED')
PY
```

After the apply step and gateway restart, you want `hooks.enabled=True` and `hooks.token in config=True`.
If both hook and gateway auth tokens are present, they should not match. The check ends with `PASSED` or `FAILED` so it is easier to scan quickly.

## Find or load OPENCLAW_HOOKS_TOKEN for curl smoke tests

You only need `OPENCLAW_HOOKS_TOKEN` in your current shell for the curl smoke tests below. After the apply step, the simplest source of truth is `hooks.token` in `/home/hjhlarsen/.openclaw/openclaw.json`.

If you just want to print the raw token value so you can inspect or copy it, use:

```bash
/usr/bin/python3 - <<'PY'
import json
from pathlib import Path
cfg = json.loads(Path("/home/hjhlarsen/.openclaw/openclaw.json").expanduser().read_text())
hooks = cfg.get('hooks') if isinstance(cfg.get('hooks'), dict) else {}
value = hooks.get('token') if isinstance(hooks.get('token'), str) else ''
print(value.strip())
PY
```

If you want to load it into your current shell, use:

```bash
export OPENCLAW_HOOKS_TOKEN="$(/usr/bin/python3 - <<'PY'
import json
from pathlib import Path
cfg = json.loads(Path("/home/hjhlarsen/.openclaw/openclaw.json").expanduser().read_text())
hooks = cfg.get('hooks') if isinstance(cfg.get('hooks'), dict) else {}
value = hooks.get('token') if isinstance(hooks.get('token'), str) else ''
print(value.strip())
PY
)"
printf '%s\n' "${OPENCLAW_HOOKS_TOKEN:+token_loaded}"
```

## 9. Local hook smoke test

Before involving the public reverse proxy or BasicOps, send a local POST directly to the OpenClaw hook endpoint:

```bash
curl -i -sS http://127.0.0.1:18789/hooks/basicops-kai \
  -H "Authorization: Bearer ${OPENCLAW_HOOKS_TOKEN:?set OPENCLAW_HOOKS_TOKEN first}" \
  -H 'Content-Type: application/json' \
  --data-binary '{}'
```

How to read the result:
- `200 OK` means the local hook endpoint answered successfully
- `Connection refused` means the gateway is down or not listening yet
- `404 Not Found` means the hook path is not active, hooks are disabled, or the mapping was not loaded
- `401 Unauthorized` means the caller token does not match the gateway hooks token

If you want one agent-specific command to do the local finish sequence in order, use:

```bash
./FINISH-LOCAL-INSTALL.sh
```

## 10. Start the pre-ack service and check logs

```bash
ls -l /home/hjhlarsen/.config/basicops-agents/kai.env
systemctl --user daemon-reload
systemctl --user cat basicops-preack@.service
systemctl --user start basicops-preack@kai.service
systemctl --user enable basicops-preack@kai.service
systemctl --user status basicops-preack@kai.service --no-pager
journalctl --user -u basicops-preack@kai.service -n 50 --no-pager
```

If `systemctl --user cat basicops-preack@.service` says the unit is not found, the copied service file is not visible to the user service manager yet. In that case, go back to step 3, confirm the file really exists at `/home/hjhlarsen/.config/systemd/user/basicops-preack@.service`, rerun `systemctl --user daemon-reload`, and then retry this step.

If `systemctl --user` fails with a user-bus or session error on headless Linux, the user systemd instance is not available in the current shell yet. A common fix is to run `loginctl enable-linger $(whoami)`, start a fresh login shell, confirm `systemctl --user status --no-pager` works, and then retry this step.

## 11. Configure the public reverse proxy

Reserve `/webhooks/basicops-kai` for this agent and route it to `127.0.0.1:18899`.

This matters because BasicOps will send webhook payloads to your public webhook URL, and the reverse proxy is what forwards that request from the public internet to the local pre-ack service on this machine.

At this point the pre-ack service is already running, so port `18899` should normally be in use. That is expected. The earlier preflight and guided setup are the steps that should catch a real port conflict before you reach this point.

If you want to confirm the shim is listening locally before you touch the reverse proxy, use this TCP connect check instead:

```bash
/usr/bin/python3 - <<'PY'
import socket
s = socket.socket()
s.settimeout(1)
try:
    s.connect(('127.0.0.1', 18899))
    print('shim port is accepting connections')
except OSError as exc:
    print('shim port is not accepting connections: 18899 (' + str(exc) + ')')
finally:
    s.close()
PY
```

You need some public reverse proxy in front of the shim. The examples below use Caddy, but Caddy is not required. If you already have nginx, Traefik, HAProxy, or another edge proxy, adapt the route there instead.

### If you plan to use Caddy on Debian or Ubuntu

Use the official Caddy repo so you get a current release instead of an older distro package:

```bash
sudo apt update
sudo apt install -y debian-keyring debian-archive-keyring apt-transport-https curl gnupg
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | sudo gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | sudo tee /etc/apt/sources.list.d/caddy-stable.list >/dev/null
sudo apt update
sudo apt install -y caddy
sudo systemctl enable --now caddy
sudo systemctl status --no-pager caddy
```

### Caddy example, single agent route

Replace `YOUR_HOST_NAME` with your real hostname:

```caddyfile
YOUR_HOST_NAME {
    handle_path /webhooks/basicops-kai* {
        reverse_proxy 127.0.0.1:18899
    }
}
```

### Caddy example, alongside an existing worker route

```caddyfile
YOUR_HOST_NAME {
    handle_path /webhooks/basicops-worker* {
        reverse_proxy 127.0.0.1:18891
    }

    handle_path /webhooks/basicops-kai* {
        reverse_proxy 127.0.0.1:18899
    }
}
```

After editing `/etc/caddy/Caddyfile`, verify and reload it:

```bash
caddy validate --config /etc/caddy/Caddyfile
sudo systemctl reload caddy
```

## 12. External webhook smoke test

After the local hook smoke test works and the pre-ack service is running, test the public route from outside the server, for example from your laptop:

```bash
curl -i -sS https://YOUR_HOST_NAME/webhooks/basicops-kai \
  -H "Authorization: Bearer ${OPENCLAW_HOOKS_TOKEN:?set OPENCLAW_HOOKS_TOKEN first}" \
  -H 'Content-Type: application/json' \
  --data-binary '{}'
```

How to read the result:
- `200 OK` means the public route answered successfully
- DNS, TLS, timeout, or connection errors mean the public hostname or reverse proxy path is still wrong
- `404 Not Found` usually means the public reverse proxy path is not routing to the shim you expected
- `401 Unauthorized` means the caller token does not match what the public endpoint expects

## 13. Create or verify the BasicOps webhook

Only do this after the external webhook smoke test works. The URL here must match the same public webhook path you just tested.

Use the configured BasicOps MCP profile for this agent instead of a raw curl command. That reuses the API key already stored in `basicops-personas.json`.

First, verify identity and current webhook state without changing anything:

```bash
/usr/bin/python3 /home/hjhlarsen/basicops-agent-bundle/scripts/ensure_basicops_webhook.py \
  --profile kai \
  --agent-id kai \
  --public-webhook-url https://YOUR_HOST_NAME/webhooks/basicops-kai \
  --wrapper-path /home/hjhlarsen/basicops-agent-bundle/scripts/basicops_mcp.py
```

What this check does:
- calls `get_current_user` through the configured BasicOps profile
- calls `list_webhooks` through the same profile
- verifies that any exact matching webhook belongs to the same BasicOps user id
- warns if the BasicOps first name looks unrelated to the intended agent id `kai`

If it warns about an identity mismatch, pause there and resolve that before you create anything. Example: setting up agent `kai`, but the BasicOps user firstName is different.

If the check says no exact webhook exists, create it and verify it in one step:

```bash
/usr/bin/python3 /home/hjhlarsen/basicops-agent-bundle/scripts/ensure_basicops_webhook.py \
  --profile kai \
  --agent-id kai \
  --public-webhook-url https://YOUR_HOST_NAME/webhooks/basicops-kai \
  --wrapper-path /home/hjhlarsen/basicops-agent-bundle/scripts/basicops_mcp.py \
  --create-if-missing
```

This helper is intentionally conservative. If the same URL already exists with the wrong user id, it will stop and ask for review. If the same URL already exists under the current user but with the wrong event set, `--create-if-missing` repairs it in place with `update_webhook` instead of creating a duplicate.

## 14. Ready to test in BasicOps

If the local hook smoke test worked, the service is running, and the external webhook smoke test also works, you should now be ready to try this in BasicOps.

A simple first test message is:
- `@Kai are you there?`

If your workspace uses a different mention format, adapt the agent name accordingly.

## Common friction points

- `/home/hjhlarsen/.config/basicops-agents/basicops-personas.json` must exist before `get-self-context` can work
- the BasicOps profile name must stay `kai` everywhere
- the hook path `basicops-kai` and public webhook path `/webhooks/basicops-kai` must stay aligned
- if you changed `agents.list`, restart the gateway before testing hooks
- if local hook tests return `401`, re-check `OPENCLAW_HOOKS_TOKEN`
- if public tests fail but local tests work, the problem is almost always DNS, TLS, or reverse-proxy routing

## References

- Manual guide: `/home/hjhlarsen/basicops-agent-bundle/docs/INSTALL.md`
- Values file: `/home/hjhlarsen/basicops-agent-bundle/generated/kai/kai.values.env`
- Env file: `/home/hjhlarsen/basicops-agent-bundle/generated/kai/kai.env`
- Webhook helper: `/home/hjhlarsen/basicops-agent-bundle/scripts/ensure_basicops_webhook.py`
- Service file: `/home/hjhlarsen/basicops-agent-bundle/generated/kai/basicops-preack@.service`
