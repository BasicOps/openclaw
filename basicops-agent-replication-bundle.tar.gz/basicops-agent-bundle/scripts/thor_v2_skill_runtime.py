#!/usr/bin/env python3
import argparse
import json
import re
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from basicops_event_normalizer import normalize_basicops_skill_payload
from json_schema_helper import load_json_file
from openclaw_agent_runner_client import RunnerClientError, invoke_agent_runner

SCRIPT_DIR = Path(__file__).resolve().parent
WORKSPACE_ROOT = Path("/home/hjhlarsen/.openclaw/workspace-basicops")
THOR_WORKSPACE_ROOT = Path("/home/hjhlarsen/.openclaw/workspace-thor")
DEFAULT_PROMPT_PATH = WORKSPACE_ROOT / "THOR-V2-SKILL-PROMPT.md"
DEFAULT_WRAPPER_PATH = SCRIPT_DIR / "basicops_mcp.py"
DEFAULT_BASE_INSTRUCTIONS_PATH = THOR_WORKSPACE_ROOT / "BASICOPS.md"
DEFAULT_CUSTOM_INSTRUCTIONS_PATH = THOR_WORKSPACE_ROOT / "BASICOPS_CUSTOM.md"
DEFAULT_USER_PREFS_PATH = THOR_WORKSPACE_ROOT / "user-prefs.json"
DEFAULT_THOR_RUNNER_PATH = SCRIPT_DIR / "thor_openclaw_agent_runner.mjs"

NO_REPLY_EVENT_TYPES = {
    "basicops.agent_instructions.updated",
    "basicops.agent_configuration.updated",
}


class RuntimeErrorWithContext(RuntimeError):
    pass


def load_json_source(path: str | None, *, allow_stdin: bool, label: str) -> Any:
    if path and path != "-":
        return load_json_file(path)
    if allow_stdin:
        return json.load(sys.stdin)
    raise RuntimeErrorWithContext(f"{label} source not provided")


def load_text_file(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def compact_json(value: Any) -> str:
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False)


def _normalize_text_file_content(value: str) -> str:
    if value.endswith("\n"):
        return value
    return f"{value}\n"


def persist_text_if_present(path: Path, value: Any) -> bool:
    if not isinstance(value, str):
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_normalize_text_file_content(value), encoding="utf-8")
    return True


def load_optional_text(path: Path) -> str | None:
    if not path.exists():
        return None
    return path.read_text(encoding="utf-8")


def build_prompt_payload(
    *,
    prompt_text: str,
    skill_payload: dict[str, Any],
    wrapper_path: Path,
    persona: str,
    base_instructions: str | None,
    custom_instructions: str | None,
    base_instructions_path: Path,
    custom_instructions_path: Path,
    user_prefs_path: Path,
) -> dict[str, Any]:
    return {
        "prompt": prompt_text.strip(),
        "skillPayload": skill_payload,
        "runtimeTooling": {
            "wrapperPath": str(wrapper_path),
            "persona": persona,
            "baseInstructionsPath": str(base_instructions_path),
            "customInstructionsPath": str(custom_instructions_path),
            "userPrefsPath": str(user_prefs_path),
        },
        "activeInstructionCaches": {
            "base": base_instructions,
            "custom": custom_instructions,
        },
    }


def build_runtime_tooling_notes(
    *,
    wrapper_path: Path,
    persona: str,
    base_instructions_path: Path,
    custom_instructions_path: Path,
    user_prefs_path: Path,
) -> str:
    wrapper = str(wrapper_path)
    return "\n".join(
        [
            "Runtime tooling notes:",
            f"- Active base instruction cache path: {base_instructions_path}",
            f"- Active custom instruction cache path: {custom_instructions_path}",
            f"- User prefs cache path: {user_prefs_path}",
        ]
    )


def build_thor_invocation_message(
    *,
    prompt_text: str,
    skill_payload: dict[str, Any],
    tooling_notes: str,
    base_instructions: str | None,
    custom_instructions: str | None,
) -> str:
    sections = [
        "Thor v2 skill-style runtime invocation.",
        prompt_text.strip(),
        tooling_notes.strip(),
    ]
    if base_instructions is not None:
        sections.extend(["Active BASICOPS.md content:", base_instructions.strip()])
    if custom_instructions is not None:
        sections.extend(["Active BASICOPS_CUSTOM.md content:", custom_instructions.strip()])
    sections.extend(
        [
            "Runtime payload JSON:",
            compact_json(skill_payload),
            "Return only the final HTML string result. If no visible reply is needed, return an empty string.",
        ]
    )
    return "\n\n".join(section for section in sections if section is not None and section != "")


def _compact_output_excerpt(text: str, *, limit: int = 1200) -> str:
    value = text.strip()
    if len(value) <= limit:
        return value
    return f"{value[:limit]}... [truncated {len(value) - limit} chars]"


def _extract_visible_text(invocation_result: dict[str, Any]) -> str:
    result = invocation_result.get("result", {}) if isinstance(invocation_result, dict) else {}
    payloads = result.get("payloads")
    if isinstance(payloads, list):
        for payload in payloads:
            if not isinstance(payload, dict):
                continue
            if "text" in payload and isinstance(payload.get("text"), str):
                return payload.get("text") or ""
    turn = result.get("turn") if isinstance(result, dict) else None
    if isinstance(turn, dict) and isinstance(turn.get("finalAssistantVisibleText"), str):
        return turn.get("finalAssistantVisibleText") or ""
    return ""


def _normalize_html_output(text: str) -> str:
    stripped = (text or "").strip()
    if stripped.startswith("```"):
        lines = stripped.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        stripped = "\n".join(lines).strip()
    if stripped in {'""', "''", "__EMPTY__", "<empty>"}:
        return ""
    return stripped


def _extract_last_json_line(text: str) -> str | None:
    for line in reversed((text or "").splitlines()):
        candidate = line.strip()
        if candidate.startswith("{") and candidate.endswith("}"):
            return candidate
    return None


def _normalize_agent_token(value: str | None) -> str:
    trimmed = (value or "").strip().lower()
    normalized = re.sub(r"[^a-z0-9_-]+", "-", trimmed).strip("-")
    return normalized or "main"


def build_isolated_session_key(thor_agent: str) -> str:
    return f"agent:{_normalize_agent_token(thor_agent)}:explicit:thor-v2-{uuid.uuid4()}"


def resolve_session_key(thor_agent: str, explicit_session_key: str | None) -> str:
    if isinstance(explicit_session_key, str) and explicit_session_key.strip():
        return explicit_session_key.strip()
    return build_isolated_session_key(thor_agent)


def invoke_thor_via_openclaw(
    *,
    openclaw_bin: str,
    thor_agent: str,
    timeout_seconds: int,
    thinking: str | None,
    model: str | None,
    message: str,
    session_key: str | None = None,
) -> tuple[dict[str, Any], str]:
    session_key = resolve_session_key(thor_agent, session_key)
    runner_request = {
        "agentId": thor_agent,
        "sessionKey": session_key,
        "message": message,
        "timeoutSeconds": timeout_seconds,
        "thinking": thinking,
        "model": model,
        "openclawBin": openclaw_bin,
    }

    try:
        invocation_result = invoke_agent_runner(
            runner_request=runner_request,
            runner_path=DEFAULT_THOR_RUNNER_PATH,
        )
    except RunnerClientError as exc:
        raise RuntimeErrorWithContext(str(exc)) from exc

    meta = invocation_result.get("result", {}).get("meta")
    if isinstance(meta, dict):
        system_prompt_report = meta.get("systemPromptReport")
        if isinstance(system_prompt_report, dict) and not system_prompt_report.get("sessionKey"):
            system_prompt_report["sessionKey"] = session_key
    return invocation_result, _normalize_html_output(_extract_visible_text(invocation_result))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Standalone Thor v2 skill-style runtime harness")
    parser.add_argument("payload", nargs="?", help="BasicOps webhook payload JSON path. Defaults to stdin.")
    parser.add_argument("--payload-stdin", action="store_true", help="Read payload JSON from stdin.")
    parser.add_argument("--agent-id", default="thor")
    parser.add_argument("--profile", default="thor", help="BasicOps persona/profile for basicops_mcp.py")
    parser.add_argument("--prompt-path", default=str(DEFAULT_PROMPT_PATH))
    parser.add_argument("--wrapper-path", default=str(DEFAULT_WRAPPER_PATH))
    parser.add_argument("--openclaw-bin", default="openclaw")
    parser.add_argument("--thor-timeout-seconds", type=int, default=180)
    parser.add_argument("--thor-thinking", help="Optional thinking override passed to `openclaw agent`")
    parser.add_argument("--thor-model", help="Optional model override passed to `openclaw agent`")
    parser.add_argument("--thor-session-key", help="Optional explicit Thor session key to reuse instead of creating a fresh isolated session")
    parser.add_argument("--base-instructions-path", default=str(DEFAULT_BASE_INSTRUCTIONS_PATH))
    parser.add_argument("--custom-instructions-path", default=str(DEFAULT_CUSTOM_INSTRUCTIONS_PATH))
    parser.add_argument("--user-prefs-path", default=str(DEFAULT_USER_PREFS_PATH))
    parser.add_argument("--print-prompt-only", action="store_true", help="Only print the prompt payload.")
    parser.add_argument("--pretty", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    if args.payload_stdin and args.payload:
        raise SystemExit("provide either a payload path or --payload-stdin, not both")

    payload = load_json_source(args.payload, allow_stdin=args.payload_stdin or not args.payload, label="payload")
    skill_payload = normalize_basicops_skill_payload(payload)

    base_instructions_path = Path(args.base_instructions_path)
    custom_instructions_path = Path(args.custom_instructions_path)
    user_prefs_path = Path(args.user_prefs_path)

    base_updated = persist_text_if_present(base_instructions_path, skill_payload.get("instructions"))
    custom_updated = persist_text_if_present(custom_instructions_path, skill_payload.get("agentInstructions"))
    base_instructions = load_optional_text(base_instructions_path)
    custom_instructions = load_optional_text(custom_instructions_path)

    prompt_text = load_text_file(Path(args.prompt_path))
    prompt_payload = build_prompt_payload(
        prompt_text=prompt_text,
        skill_payload=skill_payload,
        wrapper_path=Path(args.wrapper_path),
        persona=args.profile,
        base_instructions=base_instructions,
        custom_instructions=custom_instructions,
        base_instructions_path=base_instructions_path,
        custom_instructions_path=custom_instructions_path,
        user_prefs_path=user_prefs_path,
    )
    tooling_notes = build_runtime_tooling_notes(
        wrapper_path=Path(args.wrapper_path),
        persona=args.profile,
        base_instructions_path=base_instructions_path,
        custom_instructions_path=custom_instructions_path,
        user_prefs_path=user_prefs_path,
    )
    thor_message = build_thor_invocation_message(
        prompt_text=prompt_text,
        skill_payload=skill_payload,
        tooling_notes=tooling_notes,
        base_instructions=base_instructions,
        custom_instructions=custom_instructions,
    )

    if args.print_prompt_only:
        print(json.dumps(prompt_payload, indent=2 if args.pretty else None))
        return 0

    output: dict[str, Any] = {
        "mode": "skill_html",
        "skillPayload": skill_payload,
        "instructionCache": {
            "base": {
                "path": str(base_instructions_path),
                "updated": base_updated,
                "present": base_instructions is not None,
            },
            "custom": {
                "path": str(custom_instructions_path),
                "updated": custom_updated,
                "present": custom_instructions is not None,
            },
            "userPrefs": {
                "path": str(user_prefs_path),
                "present": user_prefs_path.exists(),
            },
        },
        "promptPayload": prompt_payload,
        "thorRequest": {
            "agentId": args.agent_id,
            "timeoutSeconds": args.thor_timeout_seconds,
            "thinking": args.thor_thinking,
            "model": args.thor_model,
            "message": thor_message,
            "sessionKey": args.thor_session_key,
            "sessionIsolation": "explicit-reused-session-key" if args.thor_session_key else "per-invocation-session-key",
        },
        "thorInvocation": None,
        "htmlOutput": "",
        "htmlWasEmpty": True,
    }

    event_type = skill_payload.get("context", {}).get("event") if isinstance(skill_payload.get("context"), dict) else None
    if event_type in NO_REPLY_EVENT_TYPES:
        output["shortCircuitReason"] = f"empty-string contract for {event_type}"
        print(json.dumps(output, indent=2 if args.pretty else None))
        return 0

    invocation_result, html_output = invoke_thor_via_openclaw(
        openclaw_bin=args.openclaw_bin,
        thor_agent=args.agent_id,
        timeout_seconds=args.thor_timeout_seconds,
        thinking=args.thor_thinking,
        model=args.thor_model,
        message=thor_message,
        session_key=args.thor_session_key,
    )

    meta = invocation_result.get("result", {}).get("meta", {})
    agent_meta = meta.get("agentMeta", {}) if isinstance(meta, dict) else {}
    system_prompt_report = meta.get("systemPromptReport", {}) if isinstance(meta, dict) else {}
    payloads = invocation_result.get("result", {}).get("payloads")
    first_payload_text = None
    if isinstance(payloads, list) and payloads and isinstance(payloads[0], dict):
        first_payload_text = payloads[0].get("text")

    output["thorInvocation"] = {
        "invokedAt": datetime.now(timezone.utc).isoformat(),
        "runId": invocation_result.get("runId"),
        "status": invocation_result.get("status"),
        "summary": invocation_result.get("summary"),
        "sessionId": agent_meta.get("sessionId"),
        "sessionKey": system_prompt_report.get("sessionKey"),
        "workspaceDir": system_prompt_report.get("workspaceDir"),
        "provider": agent_meta.get("provider"),
        "model": agent_meta.get("model"),
        "durationMs": meta.get("durationMs") if isinstance(meta, dict) else None,
        "runnerTiming": invocation_result.get("runnerTiming"),
        "runnerTransport": invocation_result.get("runnerTransport"),
        "assistantText": first_payload_text,
    }
    output["htmlOutput"] = html_output
    output["htmlWasEmpty"] = html_output == ""

    print(json.dumps(output, indent=2 if args.pretty else None))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except RuntimeErrorWithContext as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(3)
