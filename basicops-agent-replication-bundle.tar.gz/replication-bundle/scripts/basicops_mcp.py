#!/usr/bin/env python3
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

from basicops_self_context import get_self_context
from basicops_agent_context import get_remote_agent_context

DEFAULT_CONFIG_DIR = Path(os.getenv("XDG_CONFIG_HOME", str(Path.home() / ".config"))) / "basicops-agents"
MCPORTER_CONFIG = Path(os.getenv("BASICOPS_MCPORTER_CONFIG") or (DEFAULT_CONFIG_DIR / "mcporter.json"))
PERSONAS_CONFIG = Path(os.getenv("BASICOPS_PERSONAS_CONFIG") or (DEFAULT_CONFIG_DIR / "basicops-personas.json"))
BASICOPS_URL = os.getenv("BASICOPS_MCP_BASE_URL", "https://app.basicops.com/mcp")
DEFAULT_CACHE_DIR = Path(os.getenv("XDG_CACHE_HOME", str(Path.home() / ".cache"))) / "basicops-agents"

def load_personas():
    if not PERSONAS_CONFIG.exists():
        raise SystemExit(f"Missing personas config: {PERSONAS_CONFIG}")
    data = json.loads(PERSONAS_CONFIG.read_text())
    personas = {}
    if isinstance(data, dict):
        nested = data.get("personas")
        if isinstance(nested, dict) and nested:
            personas = nested
        elif data:
            personas = data
    if not personas:
        raise SystemExit(f"No personas found in {PERSONAS_CONFIG}")
    return personas

def ensure_config(persona: str) -> str:
    personas = load_personas()
    if persona not in personas:
        raise SystemExit(f"Unknown persona '{persona}'. Check {PERSONAS_CONFIG}")

    server_name = f"basicops-{persona}"
    MCPORTER_CONFIG.parent.mkdir(parents=True, exist_ok=True)
    data = {"mcpServers": {}, "imports": []}

    if MCPORTER_CONFIG.exists():
        try:
            data = json.loads(MCPORTER_CONFIG.read_text())
        except Exception:
            pass

    data.setdefault("mcpServers", {})
    data.setdefault("imports", [])
    data["mcpServers"][server_name] = {
        "baseUrl": BASICOPS_URL,
        "headers": personas[persona]["headers"],
    }
    MCPORTER_CONFIG.write_text(json.dumps(data, indent=2) + "\n")
    return server_name

def run(cmd):
    proc = subprocess.run(cmd, text=True)
    return proc.returncode


def spawn_detached(cmd, log_path: Path) -> int:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("ab") as log_file:
        proc = subprocess.Popen(
            cmd,
            stdout=log_file,
            stderr=log_file,
            start_new_session=True,
        )
    return proc.pid


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--as", dest="persona", required=True)
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("list-tools")

    call = sub.add_parser("call")
    call.add_argument("--tool", required=True)
    call.add_argument("--args", default="{}")

    set_status_async = sub.add_parser("set-status-async")
    set_status_async.add_argument("--event", required=True)
    set_status_async.add_argument("--id", dest="trigger_id", required=True)
    set_status_async.add_argument("--status", required=True)
    set_status_async.add_argument("--message")

    get_self = sub.add_parser("get-self-context")
    get_self.add_argument("--agent-id", required=True)
    get_self.add_argument("--cache-path", required=True)
    get_self.add_argument("--max-age-seconds", type=int, default=21600)
    get_self.add_argument("--refresh", action="store_true")

    get_agent = sub.add_parser("get-agent-context")
    get_agent.add_argument("--agent-id", required=True)
    get_agent.add_argument("--cache-path", required=True)
    get_agent.add_argument("--max-age-seconds", type=int, default=-1)
    get_agent.add_argument("--refresh", action="store_true")

    args = parser.parse_args()
    server_name = ensure_config(args.persona)

    if args.command == "list-tools":
        return run([
            "mcporter", "list", server_name,
            "--schema", "--output", "json",
            "--config", str(MCPORTER_CONFIG)
        ])

    if args.command == "call":
        return run([
            "mcporter", "call", f"{server_name}.{args.tool}",
            "--args", args.args,
            "--output", "json",
            "--config", str(MCPORTER_CONFIG),
        ])

    if args.command == "set-status-async":
        payload = {
            "event": args.event,
            "id": args.trigger_id,
            "status": args.status,
        }
        if args.message:
            payload["message"] = args.message

        log_path = DEFAULT_CACHE_DIR / f"{args.persona}-set-agent-status.log"
        pid = spawn_detached([
            "mcporter", "call", f"{server_name}.set_agent_status",
            "--args", json.dumps(payload),
            "--output", "json",
            "--config", str(MCPORTER_CONFIG),
        ], log_path)
        print(json.dumps({
            "ok": True,
            "spawned": True,
            "pid": pid,
            "tool": "set_agent_status",
            "logPath": str(log_path),
        }))
        return 0

    if args.command == "get-self-context":
        result = get_self_context(
            agent_id=args.agent_id,
            profile=args.persona,
            wrapper_path=str(Path(__file__).resolve()),
            cache_path=args.cache_path,
            max_age_seconds=args.max_age_seconds,
            force_refresh=args.refresh,
        )
        print(json.dumps(result, indent=2))
        return 0

    if args.command == "get-agent-context":
        result = get_remote_agent_context(
            agent_id=args.agent_id,
            profile=args.persona,
            wrapper_path=str(Path(__file__).resolve()),
            cache_path=args.cache_path,
            max_age_seconds=args.max_age_seconds,
            force_refresh=args.refresh,
        )
        print(json.dumps(result, indent=2))
        return 0

    return 1

if __name__ == "__main__":
    sys.exit(main())
