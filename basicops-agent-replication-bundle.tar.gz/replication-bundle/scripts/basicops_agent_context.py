#!/usr/bin/env python3
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional


PYTHON_BIN = sys.executable or "python3"


def call_wrapper_tool(profile: str, wrapper_path: str, tool: str, args: dict[str, Any]) -> Any:
    proc = subprocess.run(
        [
            PYTHON_BIN,
            wrapper_path,
            "--as",
            profile,
            "call",
            "--tool",
            tool,
            "--args",
            json.dumps(args),
        ],
        text=True,
        capture_output=True,
        check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"{tool} failed rc={proc.returncode} stdout={proc.stdout!r} stderr={proc.stderr!r}"
        )

    stdout = (proc.stdout or "").strip()
    if not stdout:
        raise RuntimeError(f"{tool} returned empty stdout")

    try:
        parsed = json.loads(stdout)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"{tool} returned non-JSON output: {stdout!r}") from exc

    if isinstance(parsed, dict) and "data" in parsed:
        return parsed["data"]
    return parsed


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _display_name(raw: dict[str, Any]) -> Optional[str]:
    for key in ("Display name", "displayName", "DisplayName"):
        value = raw.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def normalize_configuration(raw: dict[str, Any], agent_id: str, profile: str) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise RuntimeError(f"get_agent_configuration returned unexpected payload: {raw!r}")

    remote_agent_id = raw.get("agentId") or agent_id
    enabled = raw.get("enabled")
    if enabled is not None and not isinstance(enabled, bool):
        enabled = bool(enabled)

    return {
        "agentId": remote_agent_id,
        "profile": profile,
        "displayName": _display_name(raw),
        "enabled": enabled,
        "configurationUpdated": raw.get("configurationUpdated"),
        "instructionsUpdated": raw.get("instructionsUpdated"),
        "raw": raw,
    }


def normalize_instructions(raw: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise RuntimeError(f"get_agent_instructions returned unexpected payload: {raw!r}")

    instructions = raw.get("instructions")
    if instructions is None:
        instructions = ""
    if not isinstance(instructions, str):
        instructions = str(instructions)

    format_value = raw.get("format")
    if format_value is not None and not isinstance(format_value, str):
        format_value = str(format_value)

    return {
        "instructions": instructions,
        "format": format_value,
        "updated": raw.get("updated"),
        "raw": raw,
    }


def build_payload(
    *,
    agent_id: str,
    profile: str,
    configuration: dict[str, Any],
    instructions: dict[str, Any],
    source: str,
    event_type: str | None = None,
    event_timestamp: str | None = None,
) -> dict[str, Any]:
    return {
        "version": 1,
        "remoteAgentContext": {
            "agentId": agent_id,
            "profile": profile,
            "configuration": configuration,
            "instructions": instructions,
            "refreshedAt": _iso_now(),
            "source": source,
            "eventType": event_type,
            "eventTimestamp": event_timestamp,
        },
    }


def read_cache(cache_path: str, max_age_seconds: int = -1) -> Optional[dict[str, Any]]:
    path = Path(cache_path).expanduser()
    if not path.exists():
        return None

    try:
        payload = json.loads(path.read_text())
    except Exception:
        return None

    remote_context = payload.get("remoteAgentContext") if isinstance(payload, dict) else None
    if not isinstance(remote_context, dict):
        return None

    refreshed_at = remote_context.get("refreshedAt")
    if max_age_seconds >= 0:
        if not isinstance(refreshed_at, str):
            return None
        try:
            refreshed_dt = datetime.fromisoformat(refreshed_at.replace("Z", "+00:00"))
        except ValueError:
            return None
        age_seconds = (datetime.now(timezone.utc) - refreshed_dt).total_seconds()
        if age_seconds > max_age_seconds:
            return None

    return payload


def write_cache(cache_path: str, payload: dict[str, Any]) -> None:
    path = Path(cache_path).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", dir=path.parent, delete=False) as tmp:
        json.dump(payload, tmp, indent=2)
        tmp.write("\n")
        tmp_path = Path(tmp.name)
    tmp_path.replace(path)


def _default_configuration(agent_id: str, profile: str) -> dict[str, Any]:
    return {
        "agentId": agent_id,
        "profile": profile,
        "displayName": None,
        "enabled": None,
        "configurationUpdated": None,
        "instructionsUpdated": None,
        "raw": {},
    }


def _default_instructions() -> dict[str, Any]:
    return {
        "instructions": "",
        "format": None,
        "updated": None,
        "raw": {},
    }


def fetch_remote_agent_context(
    *,
    agent_id: str,
    profile: str,
    wrapper_path: str,
    cache_path: str,
    source: str,
    event_type: str | None = None,
    event_timestamp: str | None = None,
) -> dict[str, Any]:
    configuration_raw = call_wrapper_tool(profile, wrapper_path, "get_agent_configuration", {})
    instructions_raw = call_wrapper_tool(profile, wrapper_path, "get_agent_instructions", {})

    configuration = normalize_configuration(configuration_raw, agent_id=agent_id, profile=profile)
    resolved_agent_id = str(configuration.get("agentId") or agent_id)
    instructions = normalize_instructions(instructions_raw)

    payload = build_payload(
        agent_id=resolved_agent_id,
        profile=profile,
        configuration=configuration,
        instructions=instructions,
        source=source,
        event_type=event_type,
        event_timestamp=event_timestamp,
    )
    write_cache(cache_path, payload)
    return payload["remoteAgentContext"]


def get_remote_agent_context(
    *,
    agent_id: str,
    profile: str,
    wrapper_path: str,
    cache_path: str,
    max_age_seconds: int = -1,
    force_refresh: bool = False,
) -> dict[str, Any]:
    if not force_refresh:
        cached = read_cache(cache_path, max_age_seconds=max_age_seconds)
        if cached and isinstance(cached.get("remoteAgentContext"), dict):
            return cached["remoteAgentContext"]

    return fetch_remote_agent_context(
        agent_id=agent_id,
        profile=profile,
        wrapper_path=wrapper_path,
        cache_path=cache_path,
        source="bootstrap_fetch" if not force_refresh else "forced_refresh",
    )


def refresh_remote_agent_context_from_webhook_payload(
    *,
    payload: dict[str, Any],
    agent_id: str,
    profile: str,
    wrapper_path: str,
    cache_path: str,
) -> dict[str, Any]:
    event_type = None
    event_timestamp = None
    if isinstance(payload, dict):
        events = payload.get("events")
        if isinstance(events, list) and events and isinstance(events[0], dict):
            event_type = events[0].get("event")
            event_timestamp = events[0].get("timestamp")

    return fetch_remote_agent_context(
        agent_id=agent_id,
        profile=profile,
        wrapper_path=wrapper_path,
        cache_path=cache_path,
        source="webhook_refresh",
        event_type=event_type,
        event_timestamp=event_timestamp,
    )


def update_remote_agent_context_from_webhook_payload(
    *,
    payload: dict[str, Any],
    agent_id: str,
    profile: str,
    cache_path: str,
) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise RuntimeError("Webhook payload must be a JSON object")

    events = payload.get("events")
    if not isinstance(events, list) or not events or not isinstance(events[0], dict):
        raise RuntimeError("Webhook payload missing events[0]")

    event = events[0]
    event_type = event.get("event")
    event_timestamp = event.get("timestamp")
    data = event.get("data") if isinstance(event.get("data"), dict) else None
    if data is None:
        raise RuntimeError(f"Webhook payload missing dict data for event {event_type!r}")

    cached_payload = read_cache(cache_path, max_age_seconds=-1) or {}
    cached_context = cached_payload.get("remoteAgentContext") if isinstance(cached_payload, dict) else {}
    if not isinstance(cached_context, dict):
        cached_context = {}

    configuration = cached_context.get("configuration") if isinstance(cached_context.get("configuration"), dict) else _default_configuration(agent_id, profile)
    instructions = cached_context.get("instructions") if isinstance(cached_context.get("instructions"), dict) else _default_instructions()

    if event_type == "basicops.agent_configuration.updated":
        configuration = normalize_configuration(data, agent_id=agent_id, profile=profile)
        if configuration.get("instructionsUpdated") is not None and instructions.get("updated") is None:
            instructions = dict(instructions)
            instructions["updated"] = configuration.get("instructionsUpdated")
    elif event_type == "basicops.agent_instructions.updated":
        instructions = normalize_instructions(data)
        configuration = dict(configuration)
        if instructions.get("updated") is not None:
            configuration["instructionsUpdated"] = instructions.get("updated")
    else:
        raise RuntimeError(f"Unsupported remote-agent webhook event: {event_type!r}")

    resolved_agent_id = str(configuration.get("agentId") or agent_id)
    payload_to_write = build_payload(
        agent_id=resolved_agent_id,
        profile=profile,
        configuration=configuration,
        instructions=instructions,
        source="webhook_payload",
        event_type=event_type,
        event_timestamp=event_timestamp,
    )
    write_cache(cache_path, payload_to_write)
    return payload_to_write["remoteAgentContext"]
