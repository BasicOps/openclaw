import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';

const DRIVER_PATH = path.join(os.homedir(), 'basicops-agent-bundle', 'scripts', 'basicops_fast_driver.py');
const LOG_PATH = path.join(os.tmpdir(), "meriam-hook.log");
const AGENT_ID = "meriam";
const PROFILE = "meriam";

function sanitizeToken(value) {
  return String(value ?? 'unknown').replace(/[^a-zA-Z0-9._-]+/g, '_');
}

function buildSessionScope(context) {
  if (context?.taskId != null) return `task-${context.taskId}`;
  if (context?.chatId != null) return `chat-${context.chatId}`;
  if (context?.projectId != null) return `project-${context.projectId}`;
  if (context?.groupChatId != null) return `groupchat-${context.groupChatId}`;
  if (context?.groupchatId != null) return `groupchat-${context.groupchatId}`;
  if (context?.channelId != null) return `channel-${context.channelId}`;
  const entityId = context?.replyId ?? context?.messageId ?? context?.id ?? context?.Id ?? 'no-entity';
  return `entity-${entityId}`;
}

export default async function transform(ctx) {
  const payload = ctx?.payload ?? null;
  const eventType = payload?.event ?? payload?.events?.[0]?.event ?? 'unknown-event';
  const context = payload?.context ?? payload?.events?.[0]?.data ?? {};
  const scope = buildSessionScope(context);
  const fileToken = sanitizeToken(`${eventType}-${scope}-${Date.now()}`);
  const payloadPath = path.join(os.tmpdir(), `${AGENT_ID}-hook-${fileToken}.json`);
  const sessionKey = `agent:${AGENT_ID}:explicit:basicops-fast-${sanitizeToken(scope)}`;
  fs.writeFileSync(payloadPath, JSON.stringify(payload, null, 2), 'utf8');

  const fd = fs.openSync(LOG_PATH, 'a');
  fs.writeSync(fd, `
=== ${new Date().toISOString()} event=${eventType} scope=${scope} sessionKey=${sessionKey} ===
`);
  fs.writeSync(fd, `payload=${payloadPath}
`);

  const isSyntheticHookSmoke = Boolean(
    payload &&
    typeof payload === 'object' &&
    !Array.isArray(payload) &&
    (payload.openclawInstallSmokeTest === true || Object.keys(payload).length === 0)
  );
  if (isSyntheticHookSmoke) {
    fs.writeSync(fd, 'syntheticSmokeBypassedWorker=1\n');
    fs.closeSync(fd);
    return null;
  }

  const child = spawn('python3', [
    DRIVER_PATH,
    payloadPath,
    '--execute',
    '--profile',
    PROFILE,
    '--agent-id',
    AGENT_ID,
    '--runtime-session-key',
    sessionKey,
  ], {
    detached: true,
    stdio: ['ignore', fd, fd],
  });
  child.unref();
  fs.closeSync(fd);

  return null;
}
