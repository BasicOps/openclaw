#!/usr/bin/env python3
from __future__ import annotations

from typing import Any

REPLY_EVENT_TYPES = {
    "basicops.task.reply.created",
    "basicops.task.reply.updated",
    "basicops.project.reply.created",
    "basicops.project.reply.updated",
    "basicops.chat.reply.created",
    "basicops.chat.reply.updated",
    "basicops.groupchat.reply.created",
    "basicops.groupchat.reply.updated",
    "basicops.channel.reply.created",
    "basicops.channel.reply.updated",
}


def _as_dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _first_present(*values: Any) -> Any:
    for value in values:
        if value is None:
            continue
        if isinstance(value, str) and value == "":
            continue
        return value
    return None


def coerce_primary_event(payload: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValueError("payload must be a dict")

    events = payload.get("events")
    if isinstance(events, list) and events and isinstance(events[0], dict):
        return events[0]

    context = _as_dict(payload.get("context"))
    raw_data = payload.get("data")
    if context:
        data = dict(context)
    elif isinstance(raw_data, dict):
        data = dict(raw_data)
    else:
        data = {}

    event_type = _first_present(context.get("event"), payload.get("event"))
    if not isinstance(event_type, str) or not event_type.strip():
        raise ValueError("payload.events[0] missing or invalid")

    if isinstance(payload.get("request"), str) and not data.get("message") and not data.get("Message"):
        data["message"] = payload.get("request")

    if "groupChatId" in data and "groupchatId" not in data:
        data["groupchatId"] = data.get("groupChatId")

    reply_id = _first_present(
        data.get("replyId"),
        data.get("ReplyId"),
        data.get("id"),
        data.get("Id"),
    )
    message_id = _first_present(data.get("messageId"), data.get("MessageId"))
    primary_id = _first_present(
        reply_id,
        data.get("id"),
        data.get("Id"),
        message_id,
        data.get("taskId"),
        data.get("projectId"),
        data.get("chatId"),
        data.get("groupChatId"),
        data.get("groupchatId"),
        data.get("channelId"),
    )
    if primary_id is not None:
        data.setdefault("id", primary_id)

    if event_type in REPLY_EVENT_TYPES and message_id is not None:
        data.setdefault("messageId", message_id)

    user_id = _first_present(
        data.get("userId"),
        data.get("UserId"),
        context.get("userId"),
        context.get("UserId"),
    )

    event = {
        "event": event_type,
        "timestamp": payload.get("timestamp"),
        "companyId": payload.get("companyId"),
        "webhookId": payload.get("webhookId"),
        "updates": payload.get("updates"),
        "data": data,
    }
    if user_id is not None:
        event["user"] = {"id": user_id}
    if isinstance(payload.get("instructions"), str):
        event["instructions"] = payload.get("instructions")
    if isinstance(payload.get("agentInstructions"), str):
        event["agentInstructions"] = payload.get("agentInstructions")
    return event


def normalize_payload_for_openclaw(payload: Any) -> Any:
    if not isinstance(payload, dict):
        return payload

    events = payload.get("events")
    if isinstance(events, list) and events and isinstance(events[0], dict):
        return payload

    normalized = dict(payload)
    normalized["events"] = [coerce_primary_event(payload)]
    normalized.setdefault("_basicopsOriginalShape", "top-level")
    return normalized
