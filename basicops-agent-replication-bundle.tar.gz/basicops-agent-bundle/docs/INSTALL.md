# Install a BasicOps Agent from This Bundle

This bundle is meant to be copied to another server and used as a manual replication kit.

Important: the broader OpenClaw CLI is cross-platform. In this bundle, the generated agent handoff now supports both Linux user services via `systemctl --user` and macOS user agents via `launchctl`. This manual guide still shows the Linux-flavored commands more often, so when in doubt prefer the generated `NEXT-STEPS.md` for the target machine.

## Bundle location expected by this guide

This guide assumes the bundle has already been unpacked on the target machine at:

```bash
~/basicops-agent-bundle
```

If that directory does not exist yet, package and unpack the bundle first.

## What this bundle contains

- `templates/` - placeholder files you edit or copy into final locations
- `scripts/` - helper scripts for rendering and validating hook config
- `docs/` - setup instructions
- `examples/` - sample values to guide configuration

This handoff bundle intentionally does not ship with `generated/` outputs. Generate fresh agent-specific files on the target machine with the scaffolder or guided setup helper.

## Before you start

Make sure the target server already has:
- OpenClaw installed and running
- `mcporter` installed and available on PATH
- the BasicOps MCP wrapper available somewhere on disk
- the pre-ack webhook shim available somewhere on disk
- a valid BasicOps profile configured for the intended agent, or a fresh API key ready so you can configure one
- access to `~/.openclaw/openclaw.json`
- access to `systemctl --user`

Recommended quick preflight:

```bash
openclaw status
python3 --version
mcporter --version
systemctl --user status --no-pager
```

If any of those fail, fix that first before trying to install the replicated agent.

If `mcporter --version` fails, install it with:

```bash
sudo npm install -g mcporter
```

If you want the common beginner setup with Codex, a practical starting point is:

```bash
sudo npm install -g mcporter
npm install -g @openai/codex
mcporter --version
codex --version
```

If `codex --version` works but Codex still needs login/auth, complete that before continuing.

Dependency notes:
- `python3` is required for the scaffolder, guided helper, hook renderer, BasicOps MCP wrapper, and pre-ack webhook shim
- `mcporter` should be installed and reachable on PATH because the BasicOps wrapper depends on it in the target environment
- the generated env file should include a PATH that can actually find `mcporter`
- the target machine should also have the intended runtime/agent binary installed if the operator expects to use a specific agent setup, for example Codex, Claude Code, Pi, OpenCode, or Gemini CLI

### Runtime choice guidance

This bundle helps replicate the BasicOps/OpenClaw side, but the operator should still decide which coding/runtime agent they want available on the machine.

Common examples:
- **Codex**: install the `codex` CLI, for example `npm install -g @openai/codex`, and verify it is on PATH
- **Claude Code**: install the `claude` CLI and verify it is on PATH
- **Pi**: install the `pi` CLI and verify it is on PATH
- **OpenCode**: install the `opencode` CLI and verify it is on PATH
- **Gemini CLI**: install the `gemini` CLI and verify it is on PATH

The exact installation method depends on that tool. This bundle does not install those runtimes for you.

Minimum expectation before live setup:
- the chosen runtime is installed
- the runtime command works from a normal shell
- any required login/auth step has already been completed

### New user runtime guidance

If the operator has not set up an AI runtime yet, make the choice explicit early.

This bundle supports multiple runtime choices. Codex is a good default example, but it is not required.

Common runtime choices:
- Codex
- Claude Code
- Pi
- OpenCode
- Gemini CLI

Recommended beginner path:
1. choose one runtime first
2. install it from its official instructions
3. verify the CLI command works on the target machine
4. complete any required login/auth
5. only then continue with the bundle setup flow

If the operator is unsure, starting with Codex is reasonable because the bundle examples already use `--runtime codex`.

Simple verification example for Codex:

```bash
codex --version
codex --help
```

Equivalent checks apply to other runtimes, for example `claude --version` or `gemini --help`.

### Runtime install guidance, short version

Use the official install instructions for the chosen runtime. This bundle should not invent alternative install methods.

Recommended operator pattern:
1. install the runtime using its official method
2. verify the CLI binary is on PATH
3. complete any required login/auth flow
4. run a simple version/help check

Examples:

**Codex**
```bash
npm install -g @openai/codex
codex --version
codex --help
```

**Claude Code**
```bash
claude --version
claude --help
```

**Pi**
```bash
pi --version
pi --help
```

**OpenCode**
```bash
opencode --version
opencode --help
```

**Gemini CLI**
```bash
gemini --version
gemini --help
```

If the runtime is installed but the command is not found, fix PATH before continuing.
If the runtime opens but is not authenticated, complete that login step before live setup.

## BasicOps profile setup for a new agent

If you want a genuinely new BasicOps-backed agent persona, for example `helper`, do this before trying to generate self-context or apply hook mappings.

### Part A, manual steps in BasicOps

These steps happen in BasicOps itself and are manual:

1. log in to BasicOps
2. create the new agent user if it does not already exist
3. create an API key for that agent user
4. copy the API key and keep it available for the machine setup steps below

The bundle cannot do those browser-side BasicOps steps for you.

### Part B, configure the local MCP profile after you have the API key

Once you have the API key, you need a matching BasicOps persona/profile entry on the target machine.

In this setup, the first file to update is typically:

```bash
~/.config/basicops-agents/basicops-personas.json
```

Create the directory first if needed:

```bash
mkdir -p ~/.config/basicops-agents
```

You can start from the example bundled at:

```bash
~/basicops-agent-bundle/examples/basicops-personas.example.json
```

Recommended structure:

```json
{
  "personas": {
    "helper": {
      "headers": {
        "Authorization": "Bearer YOUR_BASICOPS_API_KEY"
      }
    }
  }
}
```

The bundled wrapper also accepts a simpler top-level form like `{ "helper": { ... } }`, but the wrapped `personas` form is the recommended shape.

If `~/.config/basicops-agents/basicops-personas.json` does not exist yet, create it from the bundled example before running `get-self-context`:

```bash
mkdir -p ~/.config/basicops-agents
cp ~/basicops-agent-bundle/examples/basicops-personas.example.json ~/.config/basicops-agents/basicops-personas.json
```

Practical insertion pattern:
1. open `~/.config/basicops-agents/basicops-personas.json`
2. find the top-level `personas` object
3. add a new entry using your chosen profile name, for example `helper`
4. set `Authorization` to `Bearer YOUR_BASICOPS_API_KEY`
5. save the file carefully without breaking JSON syntax

If the machine already has entries like `worker`, `ops`, or `inbox`, follow that same pattern.

Recommended profile naming:
- BasicOps profile name in bundle commands: `helper`
- persona key in `basicops-personas.json`: `helper`

That keeps the naming aligned across the wrapper and bundle steps.

### Part C, configure the MCP or wrapper side if your setup uses one

Some setups also keep a related MCP server entry in `~/.openclaw/openclaw.json`.

The exact config shape depends on how your OpenClaw and BasicOps MCP wrapper are already set up, but the important requirement is this:

- the profile name you plan to use in the bundle, for example `helper`
- must map to a real BasicOps MCP auth configuration on the machine

In the common direct-header pattern, this means adding a new entry under `mcp.servers` in `~/.openclaw/openclaw.json`.

You can use this bundle example as a starting point:
- `examples/basicops-mcp-server.example.json`

Example pattern:

```json
{
  "mcp": {
    "servers": {
      "basicops-helper": {
        "url": "https://app.basicops.com/mcp",
        "headers": {
          "Authorization": "Bearer YOUR_BASICOPS_API_KEY"
        }
      }
    }
  }
}
```

Use the real API key value in place of `YOUR_BASICOPS_API_KEY`.

Practical insertion pattern:
1. open `~/.openclaw/openclaw.json`
2. find the existing `mcp.servers` object
3. copy the example block from `examples/basicops-mcp-server.example.json`
4. rename `basicops-YOUR_AGENT_ID` to something like `basicops-helper`
5. replace `YOUR_BASICOPS_API_KEY` with the real API key
6. save the file carefully without breaking JSON syntax

If the machine already has entries like `basicops-worker` or `basicops-ops`, follow that same naming pattern.

Recommended profile naming:
- BasicOps profile name in bundle commands: `helper`
- MCP server entry in OpenClaw config: `basicops-helper`

That keeps the naming consistent with existing patterns like `worker` -> `basicops-worker`.

### Part D, verify the new profile before going further

After updating the local config, verify the new persona/profile can answer a self-context request.

Example:

```bash
python3 /path/to/basicops_mcp.py \
  --as helper \
  get-self-context \
  --agent-id helper \
  --cache-path /home/myuser/.cache/basicops-agents/helper-self.json \
  --refresh
```

If that works and returns values like `userId`, `displayName`, `email`, `timeZone`, `dateFormat`, and `timeFormat`, the BasicOps profile is wired correctly.

Hard stop check: make sure the resolved `displayName` and `email` belong to the intended BasicOps agent user for this setup, not a previous agent user or some other person whose API key was reused by mistake.

If the identity is wrong, stop there, fix the API key in `basicops-personas.json`, refresh self-context again, and only continue once the resolved user is correct.

If it fails, stop there and fix the profile/config first before trying to apply hook mappings or start services.

### Part E, register the OpenClaw agent before applying any hook mapping

The hook mapping is only half of the route. The target OpenClaw agent must also exist in `agents.list` in:

```bash
~/.openclaw/openclaw.json
```

At minimum, add an object like this under `agents.list` for your new agent:

```json
{
  "id": "helper",
  "name": "Helper Agent",
  "workspace": "/home/myuser/.openclaw/workspace-helper",
  "identity": {
    "name": "Helper"
  },
  "tools": {
    "profile": "coding"
  },
  "runtime": {
    "type": "acp",
    "acp": {
      "agent": "codex",
      "backend": "acpx",
      "mode": "persistent",
      "cwd": "/home/myuser/.openclaw/workspace-helper"
    }
  }
}
```

If you use the bundle scaffolder, it generates this snippet for you as `AGENT_ID.openclaw-agent.json` inside the output folder.

Important:
- the `id` must match the bundle `--agent-id`
- the workspace path must exist or be created by you
- the runtime `cwd` should match that workspace
- save `openclaw.json` cleanly before rendering or applying hook mappings

The hook renderer now validates this. If the agent is missing from `agents.list`, apply mode will stop instead of silently creating a broken route.

### Important note

This bundle can help with:
- naming the profile consistently
- generating the OpenClaw-side files
- showing you where the new profile is used

But it does not create the BasicOps user or API key for you.

## Suggested copy locations on the target server

You can unpack the bundle anywhere, but a simple pattern is:

- bundle root: `~/basicops-agent-bundle/`
- env files: `~/.config/basicops-agents/`
- systemd unit: `~/.config/systemd/user/`
- OpenClaw config: `~/.openclaw/openclaw.json`

## About OPENCLAW_HOOKS_TOKEN

The generated env file includes:

```text
OPENCLAW_HOOKS_TOKEN=...
```

That value must match the hooks auth token used by the local OpenClaw instance.

Important:
- do not leave it as `REPLACE_ME`
- do not put a real token into the shared bundle archive
- use the real token from the target machine's OpenClaw setup

The guided setup and preflight scripts now try to discover the token from the target machine's OpenClaw config automatically.
They also check gateway systemd drop-ins under `~/.config/systemd/user/openclaw-gateway.service.d/` for `OPENCLAW_HOOKS_TOKEN`.

If discovery fails during interactive guided setup, the novice-friendly default is now to generate a strong random hooks token for that setup and scaffold a matching gateway drop-in file.

If discovery fails, provide it explicitly when running guided setup:

```bash
python3 ~/basicops-agent-bundle/scripts/guided_setup_agent.py \
  --agent-id helper \
  --runtime codex \
  --hooks-token YOUR_REAL_HOOKS_TOKEN
```

`guided_setup_agent.py`, `preflight_replication_bundle.py`, and `scaffold_agent_from_bundle.py` now default `--target-home` to the current user's home directory. Only add `--target-home` when you intentionally want to install for a different Unix account.

If the token still resolves to `REPLACE_ME`, preflight should warn and explain that this is okay at preflight time, because guided setup or scaffold should supply the real value later via `--hooks-token` before live setup.

## Step 1, unpack the bundle

Example:

```bash
mkdir -p ~/basicops-agent-bundle
cd ~
unzip basicops-agent-bundle.zip -d ~/basicops-agent-bundle
```

Or if distributed as tar.gz:

```bash
mkdir -p ~/basicops-agent-bundle
tar -xzf basicops-agent-bundle.tar.gz -C ~/basicops-agent-bundle --strip-components=1
```

## Step 2, choose your values

Use `examples/worker-values.example.env` as a checklist and replace values for your real agent.

At minimum decide:
- agent id, for example `worker`
- display name, for example `WorkerAgent`
- BasicOps profile, for example `worker`
- hook path, for example `basicops-worker`
- shim port, for example `18891`
- OpenClaw hook port, often `18789`
- wrapper path
- pre-ack shim path and workdir
- self-context cache path
- OpenClaw hooks token

### Optional shortcut, scaffold a named agent first

Instead of manually copying the templates one by one, you can generate a starter folder for a specific agent:

```bash
python3 ~/basicops-agent-bundle/scripts/scaffold_agent_from_bundle.py \
  --output-dir ~/basicops-agent-bundle/generated/ops \
  --agent-id ops \
  --display-name OpsAgent \
  --basicops-profile ops \
  --hook-path basicops-ops \
  --shim-port 18892
```

That creates a fresh `generated/ops/` folder on the target machine containing:
- `ops.env`
- `basicops-preack@.service`
- `ops.values.env`
- `NEXT-STEPS.md`

You can then review and copy those files into their final locations.

### Optional preflight checker

Before doing any live setup, you can run the bundle preflight checker:

```bash
python3 ~/basicops-agent-bundle/scripts/preflight_replication_bundle.py \
  --runtime codex
```

That checks:
- required binaries like `python3`, `mcporter`, and `openclaw`
- wrapper and pre-ack shim file presence
- OpenClaw config presence
- self-context directory presence
- selected runtime availability on PATH

For machine-readable output:

```bash
python3 ~/basicops-agent-bundle/scripts/preflight_replication_bundle.py \
  --runtime codex \
  --json
```

The JSON output includes:
- overall `ok`
- `requiredFailures`
- `warnings`
- per-check results with label, severity, status, and detail

### Optional guided setup helper

If you want a more hand-held flow, use:

```bash
python3 ~/basicops-agent-bundle/scripts/guided_setup_agent.py \
  --agent-id helper
```

That is the recommended interactive pattern. Give the helper the agent id up front, then let it suggest the display name, BasicOps profile, hook path, and shim port.

The helper asks for the key values, runs preflight by default, and then runs the scaffolder for you.

If preflight fails, the helper stops before scaffolding so the operator can fix the machine first.
Use `--skip-preflight` only when you intentionally want to scaffold anyway.

For a non-interactive preview that only shows what it would do:

```bash
python3 ~/basicops-agent-bundle/scripts/guided_setup_agent.py \
  --agent-id qa \
  --display-name QaAgent \
  --basicops-profile qa \
  --hook-path basicops-qa \
  --shim-port 18893 \
  --non-interactive \
  --dry-run
```

## Step 3, create the agent env file

Create the destination directory:

```bash
mkdir -p ~/.config/basicops-agents
```

Copy `templates/env/agent.env.template` to:

```bash
~/.config/basicops-agents/<agent-id>.env
```

Replace all placeholders.

## Step 4, create the systemd user service

Create:

```bash
mkdir -p ~/.config/systemd/user
cp ~/basicops-agent-bundle/templates/systemd/basicops-preack@.service.template ~/.config/systemd/user/basicops-preack@.service
```

Edit the copied service file and replace:
- `{{PREACK_WEBHOOK_PATH}}`
- `{{PREACK_WORKDIR}}`

Then reload systemd:

```bash
systemctl --user daemon-reload
```

## Step 5, make sure your reverse proxy routes the webhook to the correct shim

This is easy to miss.

### Request flow at a glance

Before editing anything, write these three values down together for the agent you are installing:
- public webhook path, for example `/webhooks/basicops-helper`
- local shim target, for example `127.0.0.1:18894`
- OpenClaw hook target, for example `127.0.0.1:18789/hooks/basicops-helper`

If those three do not line up cleanly, stop and fix them before going further.

For a webhook-driven agent, the path usually looks like this:

```text
BasicOps or sender
  -> public webhook URL
  -> reverse proxy, for example Caddy
  -> local pre-ack shim on 127.0.0.1:<shim-port>
  -> OpenClaw hook URL on 127.0.0.1:<openclaw-port>/hooks/<hook-path>
  -> target agent
```

Example:

```text
BasicOps
  -> https://YOUR_HOST_NAME/webhooks/basicops-helper
  -> Caddy route for /webhooks/basicops-helper
  -> 127.0.0.1:18894
  -> http://127.0.0.1:18789/hooks/basicops-helper
  -> helper agent
```

The generated pre-ack service listens on a local host and port, for example:
- host: `127.0.0.1`
- port: `18894`

That local shim is not enough by itself. Your public webhook traffic still needs to be forwarded to that local shim.

In practice there are two hops:

1. public webhook endpoint -> local pre-ack shim
2. local pre-ack shim -> OpenClaw hook URL

The second hop is already represented in the generated env file, for example:

```env
OPENCLAW_FORWARD_URL=http://127.0.0.1:18789/hooks/basicops-helper
```

But you still need to configure the first hop in your reverse proxy.

Prerequisite: you need some public reverse proxy in front of the shim. If Caddy is not installed yet, either install it first, for example `sudo apt update && sudo apt install -y caddy`, or adapt the route in your existing proxy such as nginx, Traefik, or HAProxy. The examples below use Caddy, but Caddy is not required.

### Caddy example

If you use Caddy as the reverse proxy, add a route for the public webhook path that should feed this agent.

Example for a `helper` agent using shim port `18894`:

```caddyfile
YOUR_HOST_NAME {
    handle_path /webhooks/basicops-helper* {
        reverse_proxy 127.0.0.1:18894
    }
}
```

Adjust these values for your real deployment:
- `YOUR_HOST_NAME` -> your real hostname
- `/webhooks/basicops-helper` -> your chosen public webhook path
- `18894` -> the generated shim port for that agent

If you have multiple agents, each agent should have:
- its own public webhook path
- its own local shim port

Example with more than one agent:

```caddyfile
YOUR_HOST_NAME {
    handle_path /webhooks/basicops-worker* {
        reverse_proxy 127.0.0.1:18891
    }

    handle_path /webhooks/basicops-helper* {
        reverse_proxy 127.0.0.1:18894
    }
}
```

### Reverse-proxy validation checklist

Fast operator rule: treat the public webhook path and shim port as a pair. If you change one, review the other immediately.

Before going live, verify these line up correctly:

1. public webhook path in BasicOps or the external sender
2. reverse proxy route path
3. local shim host and port
4. OpenClaw hook path inside `OPENCLAW_FORWARD_URL`

Common safe pattern:
- public path: `/webhooks/basicops-helper`
- local shim: `127.0.0.1:18894`
- OpenClaw hook path: `/hooks/basicops-helper`

### After editing Caddy

Typical flow:

```bash
caddy validate --config /etc/caddy/Caddyfile
sudo systemctl reload caddy
```

Use the correct config path for your machine.

Short operator checklist:
- replace the example hostname with your real hostname
- make sure the public webhook path is unique for this agent
- point that path at the correct local shim port
- confirm the generated `OPENCLAW_FORWARD_URL` still points at the matching `/hooks/<hook-path>` target
- update the webhook sender in BasicOps or your external source to use the same public path

If your reverse proxy is not Caddy, apply the same idea in that system: route the chosen public webhook path to the agent's local shim port.

## Step 6, create or refresh self-context

Before rendering the OpenClaw hook mapping, create the self-context cache for the agent.

Replace `/home/myuser` below with the actual home directory on the target server.

Create the cache directory first if needed:

```bash
mkdir -p /home/myuser/.cache/basicops-agents
```

Example:

```bash
python3 /path/to/basicops_mcp.py \
  --as <basicops-profile> \
  get-self-context \
  --agent-id <agent-id> \
  --cache-path /home/myuser/.cache/basicops-agents/<agent-id>-self.json \
  --refresh
```

Expected output should include:
- `userId`
- `timeZone`
- `dateFormat`
- `timeFormat`

## Step 7, preview the OpenClaw hook mapping diff

Use the renderer from the unpacked bundle.

Before render or apply, note that the renderer now tries to auto-discover the hooks token from `hooks.token` in the OpenClaw config, the standard gateway systemd drop-in, or `OPENCLAW_HOOKS_TOKEN` in your current shell. You still need `OPENCLAW_HOOKS_TOKEN` in your shell for the later local curl smoke test. If you want to load it manually from the standard systemd drop-in, you can do that like this:

```bash
export OPENCLAW_HOOKS_TOKEN="$(awk -F= '/OPENCLAW_HOOKS_TOKEN=/{gsub(/^"|"$/, "", $NF); print $NF}' ~/.config/systemd/user/openclaw-gateway.service.d/70-basicops-hooks-token.conf)"
printf '%s\n' "${OPENCLAW_HOOKS_TOKEN:+token_loaded}"
```

Start with the compact summary first:

```bash
python3 ~/basicops-agent-bundle/scripts/render_basicops_hook_config.py \
  --template ~/basicops-agent-bundle/templates/prompts/basicops-worker-policy.template.md \
  --openclaw-config ~/.openclaw/openclaw.json \
  --self-context-cache /home/myuser/.cache/basicops-agents/<agent-id>-self.json \
  --agent-id <agent-id> \
  --basicops-profile <basicops-profile> \
  --hook-path <hook-path> \
  --display-name <agent-display-name> \
  --mapping-name "BasicOps <agent-display-name> Hook" \
  --wrapper-path /path/to/basicops_mcp.py \
  --mode render \
  --stdout summary
```

Safe checklist for new operators:
- `hookPath` should be the intended webhook path
- `hooksPath` should normally stay `/hooks`
- `agentId` should be the intended agent
- `mappingName` should match the intended hook name
- `basicopsProfile` should be the intended outgoing BasicOps persona/profile
- `hooksEnabledAfterApply` should be `true`
- `hooksTokenConfigured` should be `true`
- `action` should be `create` for a new hook or `update` only if you intentionally want to replace an existing hook on that path
- `warnings` should be empty, or clearly understood before you continue
- if `model` is non-empty, run a direct test with that same `--model` before you trust the webhook path
- you do not need to read the full `messageTemplate`; long policy text is expected

If the summary looks right, optionally inspect the full diff:

```bash
python3 ~/basicops-agent-bundle/scripts/render_basicops_hook_config.py \
  --template ~/basicops-agent-bundle/templates/prompts/basicops-worker-policy.template.md \
  --openclaw-config ~/.openclaw/openclaw.json \
  --self-context-cache /home/myuser/.cache/basicops-agents/<agent-id>-self.json \
  --agent-id <agent-id> \
  --basicops-profile <basicops-profile> \
  --hook-path <hook-path> \
  --display-name <agent-display-name> \
  --mapping-name "BasicOps <agent-display-name> Hook" \
  --wrapper-path /path/to/basicops_mcp.py \
  --mode render \
  --stdout diff
```

Review the diff only for those key fields and confirm the change affects only the intended hook mapping.

## Step 8, apply the OpenClaw hook mapping

When the preview looks correct:

```bash
python3 ~/basicops-agent-bundle/scripts/render_basicops_hook_config.py \
  --template ~/basicops-agent-bundle/templates/prompts/basicops-worker-policy.template.md \
  --openclaw-config ~/.openclaw/openclaw.json \
  --self-context-cache /home/myuser/.cache/basicops-agents/<agent-id>-self.json \
  --agent-id <agent-id> \
  --basicops-profile <basicops-profile> \
  --hook-path <hook-path> \
  --display-name <agent-display-name> \
  --mapping-name "BasicOps <agent-display-name> Hook" \
  --wrapper-path /path/to/basicops_mcp.py \
  --mode apply \
  --backup
```

## Step 9, start the shim service

```bash
systemctl --user start basicops-preack@<agent-id>.service
systemctl --user enable basicops-preack@<agent-id>.service
```

If `systemctl --user` complains about the user instance or D-Bus session, fix that before continuing. The replicated agent depends on user services working correctly.

## Step 10, check logs

```bash
journalctl --user -u basicops-preack@<agent-id>.service -n 50 --no-pager
```

You want to see:
- self-context loaded
- listening on the expected host/port
- no path/token errors

## Step 11, verify or register the BasicOps agent connection through MCP

Do this only after the public route is working.

Do not prefer a raw API-key curl command here if the BasicOps MCP profile is already configured for the agent. It is safer to reuse the same profile/API key already stored in `basicops-personas.json`.

Check identity and current webhook state first:

```bash
python3 ~/basicops-agent-bundle/scripts/ensure_basicops_webhook.py \
  --profile <basicops-profile> \
  --agent-id <agent-id> \
  --public-webhook-url https://YOUR_HOST_NAME/webhooks/<hook-path> \
  --wrapper-path /path/to/basicops_mcp.py
```

This check should:

- call `get_current_user`
- call `list_webhooks`
- verify that any exact matching webhook uses the same `UserId` as `get_current_user.id`
- warn if the BasicOps `firstName` looks unrelated to the intended agent id

If you get a warning like "we are setting up agent Odin, but the BasicOps user firstName looks like Thor", pause there and resolve the identity question before you create anything.

If no exact connect_agent registration exists yet, register and verify it in one step:

```bash
python3 ~/basicops-agent-bundle/scripts/ensure_basicops_webhook.py \
  --profile <basicops-profile> \
  --agent-id <agent-id> \
  --public-webhook-url https://YOUR_HOST_NAME/webhooks/<hook-path> \
  --wrapper-path /path/to/basicops_mcp.py \
  --create-if-missing
```

The helper is intentionally conservative. If the same URL already exists with a different user id, it stops for review. If the same URL already exists under the current user but with the wrong event set, `--create-if-missing` now refreshes it through `connect_agent` instead of creating a duplicate.

## Step 12, trigger a real test event

Use a real BasicOps message or reply event and then inspect logs again.

Do not rely on fake ids for the final end-to-end replay. Synthetic payloads can prove that OpenClaw session creation works, but reply posting can still fail later with `Message not found` unless the event came from a real BasicOps object.

## Common friction points

If setup stalls, check these first:
- `mcporter` is missing from PATH, install it with `sudo npm install -g mcporter`
- wrapper path is wrong or not executable with `python3`
- pre-ack webhook path or workdir is wrong in the service file
- `~/.config/basicops-agents/basicops-personas.json` is missing, so `get-self-context` cannot run
- self-context cache directory does not exist
- hook path collides with an existing OpenClaw hook mapping
- shim port is already in use by another service
- `OPENCLAW_HOOKS_TOKEN` is missing or wrong
- `hooks.enabled` is not `true`, so `/hooks/<hook-path>` never becomes active
- `OPENCLAW_HOOKS_TOKEN` matches the gateway auth token, so the gateway refuses to start
- stale systemd drop-in files are still setting an older `OPENCLAW_HOOKS_TOKEN`
- `systemctl --user` is unavailable in the current shell/session
- the target server does not actually have the prerequisite BasicOps profile configured

## Validation checklist

- env file created
- systemd service file created and placeholders replaced
- self-context cache created
- hook mapping preview looks correct
- hook mapping applied with backup
- reverse proxy path points to the expected shim port
- BasicOps agent connection exists for the intended public URL
- BasicOps webhook `UserId` matches `get_current_user.id`
- service starts
- logs show listening
- live event reaches the shim
- shim sets `working`
- OpenClaw worker handles the request
- worker finishes with `done`

## If another operator uses OpenClaw to guide setup

A less experienced operator should still be able to use this bundle if they ask OpenClaw something like:

> I want to set up a BasicOps agent from this bundle. Use agent id `ops`, display name `OpsAgent`, hook path `basicops-ops`, and profile `ops`. Walk me through it step by step and stop before making live changes.

That gives OpenClaw a clear human-supervised setup path.
