# Manual Install

Use this only if you want to perform the setup yourself.

Recommended order:

1. `QUICKSTART.md`
2. `docs/INSTALL.md`

If you are a novice user, use `INSTALL-WITH-OPENCLAW.md` instead.
That path is shorter and is designed to let the local OpenClaw assistant validate each step for you.
