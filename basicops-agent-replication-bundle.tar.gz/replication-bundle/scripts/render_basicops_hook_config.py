#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import difflib
import json
from datetime import datetime, timezone
import os
from pathlib import Path
import sys

from agent_naming import default_display_name, validate_agent_id


REQUIRED_MAPPING_KEYS = ("match", "action", "name", "agentId", "messageTemplate", "deliver")


def parse_bool_flag(value: str | bool | None, *, name: str) -> bool:
    if isinstance(value, bool):
        return value
    normalized = str(value or "").strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    raise SystemExit(f"{name} must be one of: true, false, yes, no, on, off, 1, 0")


def load_text(path: Path) -> str:
    return path.read_text()


def load_json(path: Path) -> dict:
    return json.loads(path.read_text())


def load_self_context(cache_path: Path) -> dict:
    data = load_json(cache_path)
    self_context = data.get("selfContext")
    if not isinstance(self_context, dict):
        raise SystemExit(f"Missing selfContext object in cache: {cache_path}")
    if self_context.get("userId") is None:
        raise SystemExit(f"Missing selfContext.userId in cache: {cache_path}")
    return self_context


def render_template(template_text: str, values: dict[str, str]) -> str:
    rendered = template_text
    for key, value in values.items():
        rendered = rendered.replace("{{" + key + "}}", str(value))
    return rendered


def validate_template_placeholders(template_text: str) -> None:
    required = [
        "{{AGENT_ID}}",
        "{{AGENT_DISPLAY_NAME}}",
        "{{SELF_USER_ID}}",
        "{{BASICOPS_MCP_WRAPPER}}",
        "{{BASICOPS_PROFILE}}",
    ]
    missing = [token for token in required if token not in template_text]
    if missing:
        raise SystemExit(f"Template is missing required placeholders: {', '.join(missing)}")


def configured_agent(config: dict, agent_id: str) -> dict | None:
    for agent in config.get("agents", {}).get("list", []):
        if isinstance(agent, dict) and str(agent.get("id", "")).strip() == agent_id:
            return agent
    return None


def resolve_hook_model(args: argparse.Namespace, config: dict) -> str | None:
    explicit = getattr(args, "hook_model", None)
    if isinstance(explicit, str) and explicit.strip():
        return explicit.strip()

    return None


def build_mapping(args: argparse.Namespace, template_text: str, self_context: dict, config: dict) -> dict:
    display_name = args.display_name or default_display_name(args.agent_id)
    mapping_name = args.mapping_name or f"BasicOps {display_name} Hook"

    if args.message_template_file:
        message_template = load_text(Path(args.message_template_file).expanduser())
    elif args.message_template is not None:
        message_template = args.message_template
    else:
        values = {
            "AGENT_ID": args.agent_id,
            "AGENT_DISPLAY_NAME": display_name,
            "SELF_USER_ID": str(self_context["userId"]),
            "BASICOPS_MCP_WRAPPER": args.wrapper_path,
            "BASICOPS_PROFILE": args.basicops_profile,
        }
        message_template = render_template(template_text, values)

    mapping = {
        "match": {
            "path": args.hook_path,
        },
        "action": "agent",
        "name": mapping_name,
        "agentId": args.agent_id,
        "messageTemplate": message_template,
        "deliver": parse_bool_flag(args.deliver, name="--deliver"),
    }

    if args.timeout_seconds is not None:
        mapping["timeoutSeconds"] = args.timeout_seconds
    if args.session_key:
        mapping["sessionKey"] = args.session_key
    if args.thinking:
        mapping["thinking"] = args.thinking
    if args.transform_module:
        mapping["transform"] = {
            "module": args.transform_module,
        }

    hook_model = resolve_hook_model(args, config)
    if hook_model:
        mapping["model"] = hook_model

    return mapping


def validate_args(args: argparse.Namespace) -> None:
    args.agent_id = validate_agent_id(args.agent_id)
    if not args.basicops_profile.strip():
        raise SystemExit("--basicops-profile must not be empty")
    if not args.hook_path.strip():
        raise SystemExit("--hook-path must not be empty")
    if "/" in args.hook_path:
        raise SystemExit("--hook-path must be a bare hook path segment, not a full URL or slash path")
    if not args.hooks_path.strip():
        raise SystemExit("--hooks-path must not be empty")
    if not args.hooks_path.strip().startswith("/"):
        raise SystemExit("--hooks-path must start with /")


def normalize_hooks_path(raw: str) -> str:
    path = raw.strip()
    if not path.startswith("/"):
        raise SystemExit("--hooks-path must start with /")
    normalized = path.rstrip("/")
    return normalized or "/"


def normalize_token(raw: object) -> str | None:
    if not isinstance(raw, str):
        return None
    token = raw.strip()
    if not token or token == "REPLACE_ME":
        return None
    return token


def discover_hooks_token_from_dropins(target_home: Path) -> tuple[str | None, str | None, str | None]:
    dropin_dir = target_home.expanduser() / ".config/systemd/user/openclaw-gateway.service.d"
    if not dropin_dir.is_dir():
        return None, None, None

    sources: list[tuple[str, str]] = []
    for path in sorted(dropin_dir.glob("*.conf")):
        try:
            for raw_line in path.read_text().splitlines():
                line = raw_line.strip()
                if "OPENCLAW_HOOKS_TOKEN=" not in line:
                    continue
                token = line.split("OPENCLAW_HOOKS_TOKEN=", 1)[1].strip().strip('"')
                if token and token != "REPLACE_ME":
                    sources.append((path.name, token))
        except Exception as exc:
            return None, None, f"failed reading {path}: {exc}"

    if not sources:
        return None, None, None

    distinct_tokens = {token for _, token in sources}
    source_files = ", ".join(name for name, _ in sources)
    if len(distinct_tokens) > 1:
        return None, None, f"conflicting OPENCLAW_HOOKS_TOKEN values found across: {source_files}"
    return sources[0][1], f"gateway systemd drop-in ({source_files})", None


def resolve_target_home(config_path: Path, explicit_target_home: str | None) -> Path:
    if isinstance(explicit_target_home, str) and explicit_target_home.strip():
        return Path(explicit_target_home).expanduser()
    expanded = config_path.expanduser()
    return expanded.parent.parent


def resolve_hooks_token(
    config: dict,
    cli_token: str | None,
    config_path: Path,
    explicit_target_home: str | None,
) -> tuple[str | None, str | None, str | None]:
    cli = normalize_token(cli_token)
    if cli:
        return cli, "--hooks-token", None
    hooks = config.get("hooks")
    if isinstance(hooks, dict):
        existing = normalize_token(hooks.get("token"))
        if existing:
            return existing, "openclaw config hooks.token", None
    target_home = resolve_target_home(config_path, explicit_target_home)
    token, source, warning = discover_hooks_token_from_dropins(target_home)
    if token:
        return token, source, warning
    env_token = normalize_token(os.environ.get("OPENCLAW_HOOKS_TOKEN"))
    if env_token:
        return env_token, "current shell environment OPENCLAW_HOOKS_TOKEN", warning
    return None, None, warning



def validate_paths(template_path: Path, config_path: Path, cache_path: Path, wrapper_path: Path, *, require_template: bool) -> None:
    if require_template and not template_path.is_file():
        raise SystemExit(f"Template file not found: {template_path}")
    if not config_path.is_file():
        raise SystemExit(f"OpenClaw config not found: {config_path}")
    if not cache_path.is_file():
        raise SystemExit(f"Self-context cache not found: {cache_path}")
    if not wrapper_path.is_file():
        raise SystemExit(f"BasicOps MCP wrapper not found: {wrapper_path}")



def validate_rendered_mapping(mapping: dict) -> None:
    missing = [key for key in REQUIRED_MAPPING_KEYS if key not in mapping]
    if missing:
        raise SystemExit(f"Rendered mapping missing keys: {', '.join(missing)}")
    path = mapping.get("match", {}).get("path")
    if not path:
        raise SystemExit("Rendered mapping missing match.path")
    message_template = mapping.get("messageTemplate", "")
    unresolved = [
        token
        for token in [
            "{{AGENT_DISPLAY_NAME}}",
            "{{SELF_USER_ID}}",
            "{{BASICOPS_MCP_WRAPPER}}",
            "{{BASICOPS_PROFILE}}",
        ]
        if token in message_template
    ]
    if unresolved:
        raise SystemExit(f"Rendered mapping still contains unresolved placeholders: {', '.join(unresolved)}")
    if not mapping.get("agentId"):
        raise SystemExit("Rendered mapping has empty agentId")



def validate_openclaw_config(config: dict) -> None:
    if not isinstance(config, dict):
        raise SystemExit("OpenClaw config is not a JSON object")
    agents = config.get("agents")
    if agents is None or not isinstance(agents, dict):
        raise SystemExit("OpenClaw config is missing an agents object")
    agent_list = agents.get("list")
    if agent_list is None or not isinstance(agent_list, list):
        raise SystemExit("OpenClaw config is missing agents.list")
    hooks = config.get("hooks")
    if hooks is None:
        return
    if not isinstance(hooks, dict):
        raise SystemExit("OpenClaw config has a hooks value, but it is not an object")
    hook_path = hooks.get("path")
    if hook_path is not None and not isinstance(hook_path, str):
        raise SystemExit("OpenClaw config has hooks.path, but it is not a string")
    allowed_agent_ids = hooks.get("allowedAgentIds")
    if allowed_agent_ids is not None:
        if not isinstance(allowed_agent_ids, list) or not all(isinstance(item, str) for item in allowed_agent_ids):
            raise SystemExit("OpenClaw config has hooks.allowedAgentIds, but it is not a string list")
    mappings = hooks.get("mappings")
    if mappings is not None and not isinstance(mappings, list):
        raise SystemExit("OpenClaw config has hooks.mappings, but it is not a list")


def configured_agent_ids(config: dict) -> set[str]:
    agent_ids: set[str] = set()
    for agent in config.get("agents", {}).get("list", []):
        agent_id = agent.get("id")
        if isinstance(agent_id, str) and agent_id.strip():
            agent_ids.add(agent_id)
    return agent_ids



def upsert_mapping(config: dict, mapping: dict, hooks_token: str | None, hooks_path: str) -> tuple[dict, str]:
    hooks = config.setdefault("hooks", {})
    hooks["enabled"] = True
    hooks["path"] = hooks_path
    if hooks_token is not None:
        hooks["token"] = hooks_token
    agent_id = mapping.get("agentId")
    if isinstance(agent_id, str) and agent_id.strip():
        allowed_agent_ids = hooks.setdefault("allowedAgentIds", [])
        if agent_id not in allowed_agent_ids:
            allowed_agent_ids.append(agent_id)
    mappings = hooks.setdefault("mappings", [])
    target_path = mapping.get("match", {}).get("path")
    for index, existing in enumerate(mappings):
        if existing.get("match", {}).get("path") == target_path:
            mappings[index] = mapping
            return config, "updated"
    mappings.append(mapping)
    return config, "created"



def summarize_mapping(
    args: argparse.Namespace,
    mapping: dict,
    config: dict,
    wrapper_path: Path,
    self_context: dict,
    hooks_token: str | None,
    hooks_token_source: str | None,
) -> dict:
    hook_path = mapping.get("match", {}).get("path")
    action = "create"
    for existing in config.get("hooks", {}).get("mappings", []):
        if existing.get("match", {}).get("path") == hook_path:
            action = "update"
            break
    agent_ids = configured_agent_ids(config)
    return {
        "hookPath": hook_path,
        "hooksPath": args.hooks_path,
        "agentId": mapping.get("agentId"),
        "agentRegistered": args.agent_id in agent_ids,
        "mappingName": mapping.get("name"),
        "model": mapping.get("model"),
        "thinking": mapping.get("thinking"),
        "sessionKey": mapping.get("sessionKey"),
        "timeoutSeconds": mapping.get("timeoutSeconds"),
        "transform": mapping.get("transform"),
        "basicopsProfile": args.basicops_profile,
        "wrapperPath": str(wrapper_path),
        "selfUserId": str(self_context.get("userId")),
        "action": action,
        "deliver": bool(mapping.get("deliver")),
        "hooksEnabledAfterApply": True,
        "hooksTokenConfigured": hooks_token is not None,
        "hooksTokenSource": hooks_token_source,
    }



def collect_warnings(
    args: argparse.Namespace,
    mapping: dict,
    config: dict,
    wrapper_path: Path,
    hooks_token: str | None,
    hooks_token_discovery_warning: str | None,
) -> list[str]:
    warnings: list[str] = []
    hook_path = mapping.get("match", {}).get("path")
    agent_ids = configured_agent_ids(config)
    hooks = config.get("hooks") if isinstance(config.get("hooks"), dict) else {}
    for existing in config.get("hooks", {}).get("mappings", []):
        existing_path = existing.get("match", {}).get("path")
        if existing_path != hook_path:
            continue
        existing_agent_id = existing.get("agentId")
        if existing_agent_id != args.agent_id:
            warnings.append(
                f"Hook path '{hook_path}' already exists for agentId '{existing_agent_id}' and would be replaced by '{args.agent_id}'."
            )
        break
    if args.agent_id not in agent_ids:
        warnings.append(
            f"agent-id '{args.agent_id}' is not present in agents.list. Register the agent in ~/.openclaw/openclaw.json before applying this hook."
        )
    if args.basicops_profile != args.agent_id:
        warnings.append(
            f"basicops-profile '{args.basicops_profile}' does not match agent-id '{args.agent_id}'. This can be intentional, but double-check it."
        )
    hook_model = mapping.get("model")
    if isinstance(hook_model, str) and hook_model.strip():
        warnings.append(
            f"Hook model override '{hook_model}' is set. Before you trust the webhook path, run a direct authorization check with: openclaw agent --agent {args.agent_id} --message \"reply OK\" --model {hook_model} --json --timeout 120 . Unauthorized provider/model overrides can look silent from the webhook path."
        )
    if not wrapper_path.is_file():
        warnings.append(f"Wrapper path does not exist: {wrapper_path}")
    existing_hooks_path = hooks.get("path") if isinstance(hooks, dict) else None
    if isinstance(existing_hooks_path, str) and existing_hooks_path.strip() and existing_hooks_path != args.hooks_path:
        warnings.append(
            f"hooks.path is currently '{existing_hooks_path}' and render/apply would change it to '{args.hooks_path}'."
        )
    if hooks_token is None:
        warnings.append(
            "No real hooks token is available via --hooks-token, openclaw config hooks.token, the standard gateway drop-in, or OPENCLAW_HOOKS_TOKEN in the current shell. Apply mode will fail until you provide one."
        )
    if hooks_token_discovery_warning:
        warnings.append(f"hooks token discovery warning: {hooks_token_discovery_warning}")
    return warnings



def json_text(data: dict) -> str:
    return json.dumps(data, indent=2) + "\n"



def make_diff(old_text: str, new_text: str, from_name: str, to_name: str) -> str:
    return "".join(
        difflib.unified_diff(
            old_text.splitlines(keepends=True),
            new_text.splitlines(keepends=True),
            fromfile=from_name,
            tofile=to_name,
        )
    )



def backup_path_for(config_path: Path, backup_dir: Path | None) -> Path:
    target_dir = backup_dir if backup_dir is not None else config_path.parent
    target_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return target_dir / f"{config_path.name}.bak.{stamp}"



def main() -> int:
    script_dir = Path(__file__).resolve().parent
    default_bundle_root = script_dir.parent
    default_template = default_bundle_root / "templates" / "prompts" / "basicops-worker-policy.template.md"

    parser = argparse.ArgumentParser(description="Render or apply BasicOps OpenClaw hook mappings")
    parser.add_argument("--template", default=str(default_template))
    parser.add_argument("--openclaw-config", default="~/.openclaw/openclaw.json")
    parser.add_argument("--self-context-cache", required=True)
    parser.add_argument("--agent-id", required=True)
    parser.add_argument("--basicops-profile", required=True)
    parser.add_argument("--hook-path", required=True)
    parser.add_argument("--hooks-path", default="/hooks")
    parser.add_argument("--hooks-token")
    parser.add_argument("--target-home", help="Optional target home directory used to look for standard OpenClaw gateway drop-ins")
    parser.add_argument("--display-name")
    parser.add_argument("--mapping-name")
    parser.add_argument("--hook-model", help="Optional explicit model override for the hook mapping, only when you intentionally want to force a specific route, for example openai-codex/gpt-5.4")
    parser.add_argument("--message-template", help="Optional literal messageTemplate to use instead of rendering the default template")
    parser.add_argument("--message-template-file", help="Optional file to use as the messageTemplate instead of rendering the default template")
    parser.add_argument("--deliver", default="true", help="Whether the hook should deliver its base action result, default true")
    parser.add_argument("--thinking", help="Optional hook thinking override")
    parser.add_argument("--session-key", help="Optional hook sessionKey template")
    parser.add_argument("--timeout-seconds", type=int, help="Optional hook timeoutSeconds override")
    parser.add_argument("--transform-module", help="Optional transform module name under ~/.openclaw/hooks/transforms")
    parser.add_argument("--wrapper-path", default=str((Path(__file__).resolve().parent / "basicops_mcp.py").resolve()))
    parser.add_argument("--mode", choices=["render", "apply"], default="render")
    parser.add_argument("--stdout", choices=["mapping", "config", "diff", "summary"], default="mapping")
    parser.add_argument("--backup", action="store_true", help="Create a timestamped backup before apply")
    parser.add_argument("--backup-dir", help="Optional directory for backup files")
    args = parser.parse_args()

    template_path = Path(args.template).expanduser()
    config_path = Path(args.openclaw_config).expanduser()
    cache_path = Path(args.self_context_cache).expanduser()
    wrapper_path = Path(args.wrapper_path).expanduser()
    backup_dir = Path(args.backup_dir).expanduser() if args.backup_dir else None

    validate_args(args)
    args.hooks_path = normalize_hooks_path(args.hooks_path)
    require_template = not args.message_template and not args.message_template_file
    validate_paths(template_path, config_path, cache_path, wrapper_path, require_template=require_template)

    template_text = load_text(template_path) if require_template else ""
    if require_template:
        validate_template_placeholders(template_text)

    config = load_json(config_path)
    validate_openclaw_config(config)
    hooks_token, hooks_token_source, hooks_token_discovery_warning = resolve_hooks_token(config, args.hooks_token, config_path, args.target_home)

    self_context = load_self_context(cache_path)
    mapping = build_mapping(args, template_text, self_context, config)
    validate_rendered_mapping(mapping)
    summary = summarize_mapping(args, mapping, config, wrapper_path, self_context, hooks_token, hooks_token_source)
    warnings = collect_warnings(args, mapping, config, wrapper_path, hooks_token, hooks_token_discovery_warning)

    if args.mode == "render":
        if args.stdout == "summary":
            print(json.dumps({
                "ok": True,
                "summary": summary,
                "warnings": warnings,
                "checklist": [
                    f"hookPath should be '{args.hook_path}'",
                    f"hooksPath should be '{args.hooks_path}'",
                    f"agentId should be '{args.agent_id}'",
                    "agentRegistered should be true before apply",
                    f"mappingName should be '{mapping.get('name')}'",
                    "hooksEnabledAfterApply should be true",
                    "hooksTokenConfigured should be true before apply succeeds",
                    f"wrapper should use BasicOps profile '{args.basicops_profile}'",
                    "the change should affect only the intended hook mapping",
                    *([f"run a direct authorization check for explicit hook model override '{mapping.get('model')}' before relying on the webhook path"] if isinstance(mapping.get('model'), str) and mapping.get('model').strip() else []),
                ],
                "note": "You do not need to read the full messageTemplate. Long policy text is expected.",
            }, indent=2))
            return 0
        if args.stdout == "mapping":
            print(json.dumps(mapping, indent=2))
            return 0
        old_text = json_text(config)
        rendered_config = copy.deepcopy(config)
        rendered_config, _ = upsert_mapping(rendered_config, mapping, hooks_token, args.hooks_path)
        new_text = json_text(rendered_config)
        if args.stdout == "config":
            print(new_text, end="")
        else:
            print(make_diff(old_text, new_text, str(config_path), str(config_path) + " (rendered)"), end="")
        return 0

    old_text = json_text(config)
    if args.agent_id not in configured_agent_ids(config):
        raise SystemExit(
            f"Agent '{args.agent_id}' is not present in agents.list in {config_path}. Register the agent first, then apply the hook mapping."
        )
    if hooks_token is None:
        raise SystemExit(
            "Apply mode requires a real hooks token. Pass --hooks-token or set hooks.token in the OpenClaw config first."
        )
    rendered_config = copy.deepcopy(config)
    rendered_config, action = upsert_mapping(rendered_config, mapping, hooks_token, args.hooks_path)
    new_text = json_text(rendered_config)
    diff_text = make_diff(old_text, new_text, str(config_path), str(config_path) + " (updated)")

    backup_path = None
    if args.backup:
        backup_path = backup_path_for(config_path, backup_dir)
        backup_path.write_text(load_text(config_path))

    config_path.write_text(new_text)
    print(json.dumps({
        "ok": True,
        "action": action,
        "path": str(config_path),
        "hookPath": args.hook_path,
        "agentId": args.agent_id,
        "selfUserId": self_context["userId"],
        "backupPath": str(backup_path) if backup_path else None,
        "changed": old_text != new_text,
        "diff": diff_text,
        "validation": {
            "template": str(template_path),
            "config": str(config_path),
            "selfContextCache": str(cache_path),
            "wrapperPath": str(wrapper_path),
        },
        "summary": summary,
        "warnings": warnings,
    }, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
