# Clean Bundle Checklist

Use this before shipping `basicops-agent-replication-bundle.tar.gz` or `.zip`.

## 1. Clean the source tree

These should return nothing:

```bash
find replication-bundle/generated -type f
find replication-bundle \( -type d -name '__pycache__' -o -type f -name '*.pyc' \)
find replication-bundle -type f \( \
  -name 'openclaw-gateway-hooks-token.conf' -o \
  -name 'basicops-personas.json' -o \
  -name 'mcporter.json' -o \
  \( -name '*.basicops-personas.json' ! -name '*.example.json' \) \
\)
```

## 2. Use the guarded packaging script

Verification only:

```bash
bash replication-bundle/scripts/scaffold_bundle.sh --verify-only
```

Create a clean tarball:

```bash
bash replication-bundle/scripts/scaffold_bundle.sh --tar
```

Create both tarball and zip:

```bash
bash replication-bundle/scripts/scaffold_bundle.sh --tar --zip
```

The script refuses to continue if it finds:
- stale `generated/` output
- Python bytecode caches
- likely secret-bearing files like `openclaw-gateway-hooks-token.conf`, `basicops-personas.json`, `mcporter.json`, or non-example `*.basicops-personas.json`

## 3. Inspect the produced archive

These should return nothing:

```bash
tar -tzf basicops-agent-replication-bundle.tar.gz | grep '/generated/' || true
tar -tzf basicops-agent-replication-bundle.tar.gz | grep 'openclaw-gateway-hooks-token.conf' || true
tar -tzf basicops-agent-replication-bundle.tar.gz | grep -E '(basicops-personas\.json|mcporter\.json)' || true
```

If you created a zip too:

```bash
zipinfo -1 basicops-agent-replication-bundle.zip | grep '/generated/' || true
zipinfo -1 basicops-agent-replication-bundle.zip | grep 'openclaw-gateway-hooks-token.conf' || true
zipinfo -1 basicops-agent-replication-bundle.zip | grep -E '(basicops-personas\.json|mcporter\.json)' || true
```

## 4. Treat failures as a hard stop

If any of the checks above print anything unexpected:
- do not ship the archive
- clean the tree
- rebuild the archive from scratch
- re-run the checks
