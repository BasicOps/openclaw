#!/usr/bin/env python3
import argparse
import json
import re
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from basicops_event_normalizer import normalize_basicops_skill_payload
from basicops_agent_context import get_remote_agent_context
from basicops_self_context import get_self_context
from json_schema_helper import load_json_file
from openclaw_agent_runner_client import RunnerClientError, invoke_agent_runner

SCRIPT_DIR = Path(__file__).resolve().parent
BUNDLE_ROOT = SCRIPT_DIR.parent
DEFAULT_PROMPT_PATH = BUNDLE_ROOT / "templates" / "structured-runtime" / "BASICOPS-STRUCTURED-SKILL-PROMPT.md"
DEFAULT_WRAPPER_PATH = SCRIPT_DIR / "basicops_mcp.py"
DEFAULT_AGENT_RUNNER_PATH = SCRIPT_DIR / "basicops_structured_agent_runner.mjs"
DEFAULT_CACHE_DIR = Path.home() / ".cache" / "basicops-agents"
DEFAULT_SELF_CONTEXT_CACHE_TTL_SECONDS = 21600


def default_agent_workspace(agent_id: str) -> Path:
    return Path.home() / ".openclaw" / f"workspace-{(agent_id or 'thor').strip() or 'thor'}"

NO_REPLY_EVENT_TYPES = {
    "basicops.agent_instructions.updated",
    "basicops.agent_configuration.updated",
}


class RuntimeErrorWithContext(RuntimeError):
    pass


def load_cached_runtime_context(*, agent_id: str, profile: str, wrapper_path: Path) -> tuple[dict[str, Any] | None, dict[str, Any] | None, list[str]]:
    warnings: list[str] = []
    self_context = None
    remote_agent_context = None

    try:
        self_context = get_self_context(
            agent_id=agent_id,
            profile=profile,
            wrapper_path=str(wrapper_path),
            cache_path=str(DEFAULT_CACHE_DIR / f"{agent_id}-self.json"),
            max_age_seconds=DEFAULT_SELF_CONTEXT_CACHE_TTL_SECONDS,
            force_refresh=False,
        )
    except Exception as exc:
        warnings.append(f"self_context_unavailable: {exc}")

    try:
        remote_agent_context = get_remote_agent_context(
            agent_id=agent_id,
            profile=profile,
            wrapper_path=str(wrapper_path),
            cache_path=str(DEFAULT_CACHE_DIR / f"{agent_id}-agent-context.json"),
            max_age_seconds=-1,
            force_refresh=False,
        )
    except Exception as exc:
        warnings.append(f"remote_agent_context_unavailable: {exc}")

    return self_context, remote_agent_context, warnings


def load_json_source(path: str | None, *, allow_stdin: bool, label: str) -> Any:
    if path and path != "-":
        return load_json_file(path)
    if allow_stdin:
        return json.load(sys.stdin)
    raise RuntimeErrorWithContext(f"{label} source not provided")


def load_text_file(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def compact_json(value: Any) -> str:
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False)


def _normalize_text_file_content(value: str) -> str:
    if value.endswith("\n"):
        return value
    return f"{value}\n"


def persist_text_if_present(path: Path, value: Any) -> bool:
    if not isinstance(value, str):
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_normalize_text_file_content(value), encoding="utf-8")
    return True


def load_optional_text(path: Path) -> str | None:
    if not path.exists():
        return None
    return path.read_text(encoding="utf-8")


def build_prompt_payload(
    *,
    prompt_text: str,
    skill_payload: dict[str, Any],
    wrapper_path: Path,
    persona: str,
    agent_id: str,
    base_instructions: str | None,
    custom_instructions: str | None,
    base_instructions_path: Path,
    custom_instructions_path: Path,
    user_prefs_path: Path,
) -> dict[str, Any]:
    return {
        "prompt": prompt_text.strip(),
        "skillPayload": skill_payload,
        "runtimeTooling": {
            "wrapperPath": str(wrapper_path),
            "persona": persona,
            "agentId": agent_id,
            "baseInstructionsPath": str(base_instructions_path),
            "customInstructionsPath": str(custom_instructions_path),
            "userPrefsPath": str(user_prefs_path),
        },
        "activeInstructionCaches": {
            "base": base_instructions,
            "custom": custom_instructions,
        },
    }


def build_runtime_tooling_notes(
    *,
    wrapper_path: Path,
    persona: str,
    base_instructions_path: Path,
    custom_instructions_path: Path,
    user_prefs_path: Path,
) -> str:
    wrapper = str(wrapper_path)
    return "\n".join(
        [
            "Runtime tooling notes:",
            f"- Active base instruction cache path: {base_instructions_path}",
            f"- Active custom instruction cache path: {custom_instructions_path}",
            f"- User prefs cache path: {user_prefs_path}",
        ]
    )


def build_runtime_invocation_message(
    *,
    prompt_text: str,
    skill_payload: dict[str, Any],
    tooling_notes: str,
    agent_id: str,
    base_instructions: str | None,
    custom_instructions: str | None,
    self_context: dict[str, Any] | None,
    remote_agent_context: dict[str, Any] | None,
    context_warnings: list[str] | None = None,
) -> str:
    sections = [
        "BasicOps structured skill-style runtime invocation.",
        f"Target agent id: {agent_id}",
        prompt_text.strip(),
        tooling_notes.strip(),
    ]
    if context_warnings:
        sections.extend(["Context bootstrap warnings:", "\n".join(f"- {item}" for item in context_warnings if item)])
    if isinstance(self_context, dict) and self_context:
        sections.extend([
            "Cached self context JSON:",
            compact_json({
                "userId": self_context.get("userId"),
                "displayName": self_context.get("displayName"),
                "timeZone": self_context.get("timeZone"),
                "dateFormat": self_context.get("dateFormat"),
                "timeFormat": self_context.get("timeFormat"),
            }),
            "Time rule: for current-time, current-day, and unsuffixed schedule language, use the cached self context timezone and formats. Do not default to UTC unless self context is missing or unusable.",
        ])
    if isinstance(remote_agent_context, dict) and remote_agent_context:
        configuration = remote_agent_context.get("configuration") if isinstance(remote_agent_context.get("configuration"), dict) else {}
        instructions_block = remote_agent_context.get("instructions") if isinstance(remote_agent_context.get("instructions"), dict) else {}
        sections.extend([
            "Cached remote BasicOps agent configuration JSON:",
            compact_json({
                "agentId": remote_agent_context.get("agentId"),
                "displayName": configuration.get("displayName"),
                "enabled": configuration.get("enabled"),
                "configurationUpdated": configuration.get("configurationUpdated"),
                "instructionsUpdated": configuration.get("instructionsUpdated"),
                "source": remote_agent_context.get("source"),
            }),
        ])
        if isinstance(instructions_block.get("instructions"), str) and instructions_block.get("instructions").strip():
            sections.extend(["Cached remote BasicOps agent instructions:", instructions_block.get("instructions").strip()])
        if configuration.get("enabled") is False:
            sections.append("Hard rule: the cached remote BasicOps agent configuration says this agent is disabled. Return an empty string.")
    if base_instructions is not None:
        sections.extend(["Active BASICOPS.md content:", base_instructions.strip()])
    if custom_instructions is not None:
        sections.extend(["Active BASICOPS_CUSTOM.md content:", custom_instructions.strip()])
    sections.extend(
        [
            "Runtime payload JSON:",
            compact_json(skill_payload),
            "Return only the final HTML string result. If no visible reply is needed, return an empty string.",
        ]
    )
    return "\n\n".join(section for section in sections if section is not None and section != "")


def _compact_output_excerpt(text: str, *, limit: int = 1200) -> str:
    value = text.strip()
    if len(value) <= limit:
        return value
    return f"{value[:limit]}... [truncated {len(value) - limit} chars]"


def _extract_visible_text(invocation_result: dict[str, Any]) -> str:
    result = invocation_result.get("result", {}) if isinstance(invocation_result, dict) else {}
    payloads = result.get("payloads")
    if isinstance(payloads, list):
        for payload in payloads:
            if not isinstance(payload, dict):
                continue
            if "text" in payload and isinstance(payload.get("text"), str):
                return payload.get("text") or ""
    turn = result.get("turn") if isinstance(result, dict) else None
    if isinstance(turn, dict) and isinstance(turn.get("finalAssistantVisibleText"), str):
        return turn.get("finalAssistantVisibleText") or ""
    return ""


def _normalize_html_output(text: str) -> str:
    stripped = (text or "").strip()
    if stripped.startswith("```"):
        lines = stripped.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        stripped = "\n".join(lines).strip()
    if stripped in {'""', "''", "__EMPTY__", "<empty>"}:
        return ""
    return stripped


def _extract_last_json_line(text: str) -> str | None:
    for line in reversed((text or "").splitlines()):
        candidate = line.strip()
        if candidate.startswith("{") and candidate.endswith("}"):
            return candidate
    return None


def _normalize_agent_token(value: str | None) -> str:
    trimmed = (value or "").strip().lower()
    normalized = re.sub(r"[^a-z0-9_-]+", "-", trimmed).strip("-")
    return normalized or "main"


def build_isolated_session_key(agent_id: str) -> str:
    return f"agent:{_normalize_agent_token(agent_id)}:explicit:basicops-structured-{uuid.uuid4()}"


def resolve_session_key(agent_id: str, explicit_session_key: str | None) -> str:
    if isinstance(explicit_session_key, str) and explicit_session_key.strip():
        return explicit_session_key.strip()
    return build_isolated_session_key(agent_id)


def invoke_agent_via_openclaw(
    *,
    openclaw_bin: str,
    agent_id: str,
    timeout_seconds: int,
    thinking: str | None,
    model: str | None,
    message: str,
    session_key: str | None = None,
) -> tuple[dict[str, Any], str]:
    session_key = resolve_session_key(agent_id, session_key)
    runner_request = {
        "agentId": agent_id,
        "sessionKey": session_key,
        "message": message,
        "timeoutSeconds": timeout_seconds,
        "thinking": thinking,
        "model": model,
        "openclawBin": openclaw_bin,
    }

    try:
        invocation_result = invoke_agent_runner(
            runner_request=runner_request,
            runner_path=DEFAULT_AGENT_RUNNER_PATH,
        )
    except RunnerClientError as exc:
        raise RuntimeErrorWithContext(str(exc)) from exc

    meta = invocation_result.get("result", {}).get("meta")
    if isinstance(meta, dict):
        system_prompt_report = meta.get("systemPromptReport")
        if isinstance(system_prompt_report, dict) and not system_prompt_report.get("sessionKey"):
            system_prompt_report["sessionKey"] = session_key
    return invocation_result, _normalize_html_output(_extract_visible_text(invocation_result))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Standalone BasicOps structured skill-style runtime harness")
    parser.add_argument("payload", nargs="?", help="BasicOps webhook payload JSON path. Defaults to stdin.")
    parser.add_argument("--payload-stdin", action="store_true", help="Read payload JSON from stdin.")
    parser.add_argument("--agent-id", default="thor")
    parser.add_argument("--profile", default="thor", help="BasicOps persona/profile for basicops_mcp.py")
    parser.add_argument("--prompt-path", default=str(DEFAULT_PROMPT_PATH))
    parser.add_argument("--wrapper-path", default=str(DEFAULT_WRAPPER_PATH))
    parser.add_argument("--openclaw-bin", default="openclaw")
    parser.add_argument("--runtime-timeout-seconds", "--thor-timeout-seconds", dest="runtime_timeout_seconds", type=int, default=180)
    parser.add_argument("--runtime-thinking", "--thor-thinking", dest="runtime_thinking", help="Optional thinking override passed to `openclaw agent`")
    parser.add_argument("--runtime-model", "--thor-model", dest="runtime_model", help="Optional model override passed to `openclaw agent`")
    parser.add_argument("--runtime-session-key", "--thor-session-key", dest="runtime_session_key", help="Optional explicit session key to reuse instead of creating a fresh isolated session")
    parser.add_argument("--base-instructions-path")
    parser.add_argument("--custom-instructions-path")
    parser.add_argument("--user-prefs-path")
    parser.add_argument("--print-prompt-only", action="store_true", help="Only print the prompt payload.")
    parser.add_argument("--pretty", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    if args.payload_stdin and args.payload:
        raise SystemExit("provide either a payload path or --payload-stdin, not both")

    payload = load_json_source(args.payload, allow_stdin=args.payload_stdin or not args.payload, label="payload")
    skill_payload = normalize_basicops_skill_payload(payload)
    self_context, remote_agent_context, context_warnings = load_cached_runtime_context(
        agent_id=args.agent_id,
        profile=args.profile,
        wrapper_path=Path(args.wrapper_path),
    )

    workspace_root = default_agent_workspace(args.agent_id)
    base_instructions_path = Path(args.base_instructions_path) if args.base_instructions_path else workspace_root / "BASICOPS.md"
    custom_instructions_path = Path(args.custom_instructions_path) if args.custom_instructions_path else workspace_root / "BASICOPS_CUSTOM.md"
    user_prefs_path = Path(args.user_prefs_path) if args.user_prefs_path else workspace_root / "user-prefs.json"

    base_updated = persist_text_if_present(base_instructions_path, skill_payload.get("instructions"))
    custom_updated = persist_text_if_present(custom_instructions_path, skill_payload.get("agentInstructions"))
    base_instructions = load_optional_text(base_instructions_path)
    custom_instructions = load_optional_text(custom_instructions_path)

    prompt_text = load_text_file(Path(args.prompt_path))
    prompt_payload = build_prompt_payload(
        prompt_text=prompt_text,
        skill_payload=skill_payload,
        wrapper_path=Path(args.wrapper_path),
        persona=args.profile,
        agent_id=args.agent_id,
        base_instructions=base_instructions,
        custom_instructions=custom_instructions,
        base_instructions_path=base_instructions_path,
        custom_instructions_path=custom_instructions_path,
        user_prefs_path=user_prefs_path,
    )
    tooling_notes = build_runtime_tooling_notes(
        wrapper_path=Path(args.wrapper_path),
        persona=args.profile,
        base_instructions_path=base_instructions_path,
        custom_instructions_path=custom_instructions_path,
        user_prefs_path=user_prefs_path,
    )
    runtime_message = build_runtime_invocation_message(
        prompt_text=prompt_text,
        skill_payload=skill_payload,
        tooling_notes=tooling_notes,
        agent_id=args.agent_id,
        base_instructions=base_instructions,
        custom_instructions=custom_instructions,
        self_context=self_context,
        remote_agent_context=remote_agent_context,
        context_warnings=context_warnings,
    )

    if args.print_prompt_only:
        print(json.dumps(prompt_payload, indent=2 if args.pretty else None))
        return 0

    output: dict[str, Any] = {
        "mode": "skill_html",
        "skillPayload": skill_payload,
        "cachedSelfContext": self_context,
        "cachedRemoteAgentContext": remote_agent_context,
        "contextLoadWarnings": context_warnings,
        "instructionCache": {
            "base": {
                "path": str(base_instructions_path),
                "updated": base_updated,
                "present": base_instructions is not None,
            },
            "custom": {
                "path": str(custom_instructions_path),
                "updated": custom_updated,
                "present": custom_instructions is not None,
            },
            "userPrefs": {
                "path": str(user_prefs_path),
                "present": user_prefs_path.exists(),
            },
        },
        "promptPayload": prompt_payload,
        "runtimeRequest": {
            "agentId": args.agent_id,
            "timeoutSeconds": args.runtime_timeout_seconds,
            "thinking": args.runtime_thinking,
            "model": args.runtime_model,
            "message": runtime_message,
            "sessionKey": args.runtime_session_key,
            "sessionIsolation": "explicit-reused-session-key" if args.runtime_session_key else "per-invocation-session-key",
        },
        "runtimeInvocation": None,
        "htmlOutput": "",
        "htmlWasEmpty": True,
    }

    event_type = skill_payload.get("context", {}).get("event") if isinstance(skill_payload.get("context"), dict) else None
    if event_type in NO_REPLY_EVENT_TYPES:
        output["shortCircuitReason"] = f"empty-string contract for {event_type}"
        print(json.dumps(output, indent=2 if args.pretty else None))
        return 0

    invocation_result, html_output = invoke_agent_via_openclaw(
        openclaw_bin=args.openclaw_bin,
        agent_id=args.agent_id,
        timeout_seconds=args.runtime_timeout_seconds,
        thinking=args.runtime_thinking,
        model=args.runtime_model,
        message=runtime_message,
        session_key=args.runtime_session_key,
    )

    meta = invocation_result.get("result", {}).get("meta", {})
    agent_meta = meta.get("agentMeta", {}) if isinstance(meta, dict) else {}
    system_prompt_report = meta.get("systemPromptReport", {}) if isinstance(meta, dict) else {}
    payloads = invocation_result.get("result", {}).get("payloads")
    first_payload_text = None
    if isinstance(payloads, list) and payloads and isinstance(payloads[0], dict):
        first_payload_text = payloads[0].get("text")

    output["runtimeInvocation"] = {
        "invokedAt": datetime.now(timezone.utc).isoformat(),
        "runId": invocation_result.get("runId"),
        "status": invocation_result.get("status"),
        "summary": invocation_result.get("summary"),
        "sessionId": agent_meta.get("sessionId"),
        "sessionKey": system_prompt_report.get("sessionKey"),
        "workspaceDir": system_prompt_report.get("workspaceDir"),
        "provider": agent_meta.get("provider"),
        "model": agent_meta.get("model"),
        "durationMs": meta.get("durationMs") if isinstance(meta, dict) else None,
        "runnerTiming": invocation_result.get("runnerTiming"),
        "runnerTransport": invocation_result.get("runnerTransport"),
        "assistantText": first_payload_text,
    }
    output["htmlOutput"] = html_output
    output["htmlWasEmpty"] = html_output == ""

    print(json.dumps(output, indent=2 if args.pretty else None))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except RuntimeErrorWithContext as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(3)
