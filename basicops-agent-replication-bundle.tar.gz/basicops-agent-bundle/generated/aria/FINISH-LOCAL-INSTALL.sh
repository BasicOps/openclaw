#!/usr/bin/env bash
set -euo pipefail

echo 'TARGET AGENT: aria'
echo 'READ ONLY: /home/hjhlarsen/basicops-agent-bundle/generated/aria/NEXT-STEPS.md'
echo 'Finishing local install for aria...'

/usr/bin/python3 /home/hjhlarsen/basicops-agent-bundle/scripts/basicops_mcp.py --as aria get-self-context --agent-id aria --cache-path /home/hjhlarsen/.cache/basicops-agents/aria-self.json --refresh

/usr/bin/python3 /home/hjhlarsen/basicops-agent-bundle/scripts/render_basicops_hook_config.py --template /home/hjhlarsen/basicops-agent-bundle/templates/prompts/basicops-worker-policy.template.md --openclaw-config /home/hjhlarsen/.openclaw/openclaw.json --self-context-cache /home/hjhlarsen/.cache/basicops-agents/aria-self.json --agent-id aria --basicops-profile aria --hook-path basicops-aria --display-name Aria --mapping-name "BasicOps Aria Hook" --wrapper-path /home/hjhlarsen/basicops-agent-bundle/scripts/basicops_mcp.py --mode render --stdout summary

/usr/bin/python3 /home/hjhlarsen/basicops-agent-bundle/scripts/render_basicops_hook_config.py --template /home/hjhlarsen/basicops-agent-bundle/templates/prompts/basicops-worker-policy.template.md --openclaw-config /home/hjhlarsen/.openclaw/openclaw.json --self-context-cache /home/hjhlarsen/.cache/basicops-agents/aria-self.json --agent-id aria --basicops-profile aria --hook-path basicops-aria --display-name Aria --mapping-name "BasicOps Aria Hook" --wrapper-path /home/hjhlarsen/basicops-agent-bundle/scripts/basicops_mcp.py --hooks-token 082533d9f6b900e05ed9884ac8c655db6715370ee5909a40 --mode apply --backup

openclaw gateway restart
openclaw gateway status

systemctl --user daemon-reload
systemctl --user enable --now basicops-preack@aria.service
systemctl --user status basicops-preack@aria.service --no-pager

export OPENCLAW_HOOKS_TOKEN="$(/usr/bin/python3 - <<'PY'
import json
from pathlib import Path
cfg = json.loads(Path("/home/hjhlarsen/.openclaw/openclaw.json").expanduser().read_text())
hooks = cfg.get('hooks') if isinstance(cfg.get('hooks'), dict) else {}
value = hooks.get('token') if isinstance(hooks.get('token'), str) else ''
print(value.strip())
PY
)"
curl -i -sS http://127.0.0.1:18789/hooks/basicops-aria -H "Authorization: Bearer ${OPENCLAW_HOOKS_TOKEN:?set OPENCLAW_HOOKS_TOKEN first}" -H 'Content-Type: application/json' --data-binary '{}'
