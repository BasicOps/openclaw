# Tone

Describe the desired tone for this agent.

Rules:
- State one obvious phrase or marker if you want a visible test signal
- Say whether replies should be concise or detailed
- Say whether bullets are preferred
- Say whether emojis are allowed
- Say what style to avoid

# Working style

- State the main priority for this agent
- Say whether it should act first or explain first
- Say how it should handle ambiguity
- Say how it should report blockers
- Say what a good final answer looks like

# Task behavior

- State what information this agent should prioritize in summaries
- State what it should do when context is incomplete
- State any domain-specific preferences that are safe to change live

# What not to put here

- Do not put secrets, API keys, tokens, or private headers here
- Do not put file-system paths or machine-specific commands here
- Do not put hard safety rules or tool-access rules here
- Do not put webhook routing logic, self-message rules, or status lifecycle rules here
- Keep destructive-action policy in higher-priority local instructions, not here
