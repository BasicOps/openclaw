# Recipient Note

This bundle is meant to help you replicate a BasicOps-backed OpenClaw agent on another machine.

## Recommended starting point

Start with:
- `HANDOFF.md`
- `QUICKSTART.md`

If you want the safest path, use:
- preflight first
- then guided setup

Recommended first command:

Important: this helper does not install prerequisites for you. The target machine still needs `openclaw`, `mcporter`, and the runtime path you intentionally choose.

Recommended beginner setup example:

```bash
sudo npm install -g mcporter
mcporter --version
python3 ~/basicops-agent-bundle/scripts/guided_setup_agent.py \
  --agent-id helper \
  --runtime same-as-main
```

Only for an explicit Codex path, install and verify Codex separately first:

```bash
npm install -g @openai/codex
codex --version
codex login status
```

That is the recommended interactive pattern. Set the agent id up front, then let the script suggest the rest.
`--target-home` now defaults to the current user's home automatically, so only add it when you intentionally want to install for a different Unix account.

Recommended default runtime choice: `same-as-main`, which reuses the model/runtime already working for the machine's existing `main` agent.

## Before live setup

Make sure the target machine already has:
- `python3`
- `mcporter`
- `openclaw`
- either a working OpenClaw default runtime already configured, or an explicit runtime CLI you intentionally plan to use
- the BasicOps wrapper on disk
- the pre-ack webhook shim on disk
- a valid BasicOps profile configured

## What this bundle does not do

This bundle does not automatically install:
- OpenClaw
- Codex, Claude Code, Pi, OpenCode, or Gemini CLI
- BasicOps credentials or profiles
- live tokens or secrets

## Main files

- `QUICKSTART.md` for the fastest safe path
- `docs/INSTALL.md` for the full manual procedure
- `scripts/preflight_replication_bundle.py` for readiness checks
- `scripts/guided_setup_agent.py` for guided scaffolding
- `scripts/scaffold_agent_from_bundle.py` for direct named-agent generation
