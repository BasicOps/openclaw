#!/usr/bin/env python3
import argparse
import json
import re
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from basicops_event_normalizer import normalize_basicops_event
from json_schema_helper import SchemaValidationError, load_json_file, validate_json
from openclaw_agent_runner_client import RunnerClientError, invoke_agent_runner

SCRIPT_DIR = Path(__file__).resolve().parent
BUNDLE_ROOT = SCRIPT_DIR.parent
DEFAULT_PROMPT_PATH = BUNDLE_ROOT / "templates" / "structured-runtime" / "BASICOPS-STRUCTURED-PROMPT.md"
DEFAULT_INPUT_SCHEMA_PATH = BUNDLE_ROOT / "templates" / "structured-runtime" / "BASICOPS-STRUCTURED-INPUT-SCHEMA.json"
DEFAULT_ACTION_SCHEMA_PATH = BUNDLE_ROOT / "templates" / "structured-runtime" / "BASICOPS-STRUCTURED-ACTION-SCHEMA.json"
DEFAULT_WRAPPER_PATH = SCRIPT_DIR / "basicops_mcp.py"
DEFAULT_AGENT_RUNNER_PATH = SCRIPT_DIR / "basicops_structured_agent_runner.mjs"

COMMON_READ_TOOLS = [
    "get_task",
    "get_project",
    "get_message",
    "list_messages_in_task",
    "list_messages_in_project",
    "list_messages_in_chat",
    "list_replies_in_message",
    "list_task_dependencies",
    "list_tasks_in_project",
    "list_notes_in_project",
    "list_users",
    "get_user",
]


class RuntimeErrorWithContext(RuntimeError):
    pass


def load_json_source(path: str | None, *, allow_stdin: bool, label: str) -> Any:
    if path and path != "-":
        return load_json_file(path)
    if allow_stdin:
        return json.load(sys.stdin)
    raise RuntimeErrorWithContext(f"{label} source not provided")


def load_text_file(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def compact_json(value: Any) -> str:
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False)


def build_prompt_payload(
    *,
    prompt_text: str,
    input_schema: dict[str, Any],
    action_schema: dict[str, Any],
    normalized_input: dict[str, Any],
    wrapper_path: Path,
    persona: str,
) -> dict[str, Any]:
    return {
        "prompt": prompt_text.strip(),
        "inputSchemaId": input_schema.get("$id"),
        "actionSchemaId": action_schema.get("$id"),
        "normalizedInput": normalized_input,
        "runtimeTooling": {
            "wrapperPath": str(wrapper_path),
            "persona": persona,
            "commonReadTools": COMMON_READ_TOOLS,
            "writesHandledByRuntime": True,
        },
    }


def build_runtime_tooling_notes(*, wrapper_path: Path, persona: str) -> str:
    wrapper = str(wrapper_path)
    common_tools = ", ".join(COMMON_READ_TOOLS)
    return "\n".join(
        [
            "Runtime tooling notes:",
            "- The normalized input is only the starting context. If you need more facts, fetch them.",
            f"- For BasicOps context reads, use exec with: python3 {wrapper} --as {persona} call --tool TOOL_NAME --args 'JSON'",
            f"- If you need to inspect available BasicOps tools first, run: python3 {wrapper} --as {persona} list-tools",
            f"- Common read tools: {common_tools}",
            "- Use targeted reads. Do not shotgun-fetch broad context unless the request needs it.",
            "- Do not use first-class basicops-* tools directly in this v2 path.",
            "- Do not perform BasicOps writes or set_agent_status through exec in this v2 path. Return the final JSON action for the runtime to execute.",
        ]
    )


def build_runtime_invocation_message(
    *,
    prompt_text: str,
    action_schema: dict[str, Any],
    normalized_input: dict[str, Any],
    tooling_notes: str,
) -> str:
    agent = normalized_input.get("agent") if isinstance(normalized_input.get("agent"), dict) else {}
    agent_id = agent.get("id") or "unknown"
    agent_name = agent.get("name") or agent_id
    return "\n\n".join(
        [
            "BasicOps structured runtime invocation.",
            f"Target agent: {agent_name} ({agent_id})",
            prompt_text.strip(),
            tooling_notes.strip(),
            "Action schema JSON:",
            compact_json(action_schema),
            "Normalized input JSON:",
            compact_json(normalized_input),
            "Return exactly one JSON object matching the action schema. No markdown fences. No surrounding commentary.",
        ]
    )


def _compact_output_excerpt(text: str, *, limit: int = 1200) -> str:
    value = text.strip()
    if len(value) <= limit:
        return value
    return f"{value[:limit]}... [truncated {len(value) - limit} chars]"


def _extract_json_object_text(text: str) -> str:
    stripped = text.strip()
    if stripped.startswith("```"):
        lines = stripped.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        stripped = "\n".join(lines).strip()

    if stripped.startswith("{") and stripped.endswith("}"):
        return stripped

    start = stripped.find("{")
    end = stripped.rfind("}")
    if start == -1 or end == -1 or end < start:
        raise RuntimeErrorWithContext("Runtime reply did not contain a JSON object")
    return stripped[start : end + 1]


def _extract_last_json_line(text: str) -> str | None:
    for line in reversed((text or "").splitlines()):
        candidate = line.strip()
        if candidate.startswith("{") and candidate.endswith("}"):
            return candidate
    return None


def _normalize_agent_token(value: str | None) -> str:
    trimmed = (value or "").strip().lower()
    normalized = re.sub(r"[^a-z0-9_-]+", "-", trimmed).strip("-")
    return normalized or "main"


def build_isolated_session_key(agent_id: str) -> str:
    return f"agent:{_normalize_agent_token(agent_id)}:explicit:basicops-structured-{uuid.uuid4()}"


def resolve_session_key(agent_id: str, explicit_session_key: str | None) -> str:
    if isinstance(explicit_session_key, str) and explicit_session_key.strip():
        return explicit_session_key.strip()
    return build_isolated_session_key(agent_id)


def invoke_agent_via_openclaw(
    *,
    openclaw_bin: str,
    agent_id: str,
    timeout_seconds: int,
    thinking: str | None,
    model: str | None,
    message: str,
    session_key: str | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    session_key = resolve_session_key(agent_id, session_key)
    runner_request = {
        "agentId": agent_id,
        "sessionKey": session_key,
        "message": message,
        "timeoutSeconds": timeout_seconds,
        "thinking": thinking,
        "model": model,
        "openclawBin": openclaw_bin,
    }

    try:
        invocation_result = invoke_agent_runner(
            runner_request=runner_request,
            runner_path=DEFAULT_AGENT_RUNNER_PATH,
        )
    except RunnerClientError as exc:
        raise RuntimeErrorWithContext(str(exc)) from exc

    meta = invocation_result.get("result", {}).get("meta")
    if isinstance(meta, dict):
        system_prompt_report = meta.get("systemPromptReport")
        if isinstance(system_prompt_report, dict) and not system_prompt_report.get("sessionKey"):
            system_prompt_report["sessionKey"] = session_key

    reply_text = ""
    payloads = invocation_result.get("result", {}).get("payloads")
    if isinstance(payloads, list):
        for payload in payloads:
            if isinstance(payload, dict) and isinstance(payload.get("text"), str) and payload["text"].strip():
                reply_text = payload["text"]
                break
    if not reply_text:
        reply_text = invocation_result.get("result", {}).get("turn", {}).get("finalAssistantVisibleText", "")
    if not isinstance(reply_text, str) or not reply_text.strip():
        raise RuntimeErrorWithContext("Runtime invocation returned no assistant text")

    action_text = _extract_json_object_text(reply_text)
    try:
        action = json.loads(action_text)
    except json.JSONDecodeError as exc:
        raise RuntimeErrorWithContext(f"Runtime assistant text was not valid JSON: {exc}") from exc

    return invocation_result, action


def _first_present(*values: Any) -> Any:
    for value in values:
        if value is None:
            continue
        if isinstance(value, str) and value == "":
            continue
        return value
    return None


def extract_surface_targets(payload: dict[str, Any], normalized: dict[str, Any]) -> dict[str, Any]:
    events = payload.get("events")
    if isinstance(events, list) and events and isinstance(events[0], dict):
        data = events[0].get("data")
        data_dict = data if isinstance(data, dict) else {}
    else:
        data_dict = payload.get("context") if isinstance(payload.get("context"), dict) else {}

    return {
        "taskId": normalized["trigger"].get("taskId"),
        "projectId": normalized["trigger"].get("projectId"),
        "chatId": _first_present(data_dict.get("chatId"), data_dict.get("ChatId"), normalized["trigger"].get("chatId")),
        "groupchatId": _first_present(
            data_dict.get("groupChatId"),
            data_dict.get("GroupChatId"),
            data_dict.get("groupchatId"),
            data_dict.get("GroupchatId"),
            normalized["trigger"].get("groupChatId"),
        ),
        "channelId": _first_present(data_dict.get("channelId"), data_dict.get("ChannelId"), normalized["trigger"].get("channelId")),
        "replyTargetMessageId": normalized["trigger"].get("replyTargetMessageId") or normalized["trigger"].get("messageEntityId"),
        "messageEntityId": normalized["trigger"].get("messageEntityId"),
        "surface": normalized["event"]["surface"],
        "eventType": normalized["event"]["type"],
        "triggerId": normalized["trigger"].get("originalId") or normalized["trigger"].get("originalIdFallback"),
    }


def wrapper_call(
    *,
    wrapper_path: Path,
    persona: str,
    tool: str,
    args: dict[str, Any],
) -> dict[str, Any]:
    cmd = [
        sys.executable,
        str(wrapper_path),
        "--as",
        persona,
        "call",
        "--tool",
        tool,
        "--args",
        json.dumps(args),
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeErrorWithContext(
            f"{tool} failed with exit {proc.returncode}: {(proc.stderr or proc.stdout).strip()}"
        )
    try:
        return json.loads(proc.stdout or "{}")
    except json.JSONDecodeError as exc:
        raise RuntimeErrorWithContext(f"{tool} returned invalid JSON: {exc}") from exc


def wrapper_set_status_async(
    *,
    wrapper_path: Path,
    persona: str,
    event_type: str,
    trigger_id: str | int,
    status: str,
    message: str | None = None,
) -> dict[str, Any]:
    cmd = [
        sys.executable,
        str(wrapper_path),
        "--as",
        persona,
        "set-status-async",
        "--event",
        str(event_type),
        "--id",
        str(trigger_id),
        "--status",
        status,
    ]
    if message:
        cmd.extend(["--message", message])
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeErrorWithContext(
            f"set-status-async failed with exit {proc.returncode}: {(proc.stderr or proc.stdout).strip()}"
        )
    try:
        return json.loads(proc.stdout or "{}")
    except json.JSONDecodeError as exc:
        raise RuntimeErrorWithContext(f"set-status-async returned invalid JSON: {exc}") from exc


def pick_reply_transport(reply: dict[str, Any], normalized: dict[str, Any], targets: dict[str, Any]) -> dict[str, Any]:
    preference = reply["preference"]
    capabilities = normalized["capabilities"]
    surface = targets["surface"]

    if preference == "reply_if_possible" and capabilities.get("canReplyInMessage") and targets.get("replyTargetMessageId"):
        return {
            "kind": "tool_call",
            "tool": "create_reply_in_message",
            "args": {
                "messageId": targets["replyTargetMessageId"],
                "message": reply["html"],
            },
        }

    if surface in {"task_message", "task_reply"} and targets.get("taskId") is not None:
        return {
            "kind": "tool_call",
            "tool": "create_message_in_task",
            "args": {
                "taskId": targets["taskId"],
                "message": reply["html"],
            },
        }

    if surface == "project_message" and targets.get("projectId") is not None:
        return {
            "kind": "tool_call",
            "tool": "create_message_in_project",
            "args": {
                "projectId": targets["projectId"],
                "message": reply["html"],
            },
        }

    if surface == "chat_message" and targets.get("chatId") is not None:
        return {
            "kind": "tool_call",
            "tool": "create_message_in_chat",
            "args": {
                "chatId": targets["chatId"],
                "message": reply["html"],
            },
        }

    if surface == "groupchat_message" and targets.get("groupchatId") is not None:
        return {
            "kind": "tool_call",
            "tool": "create_message_in_groupchat",
            "args": {
                "groupchatId": targets["groupchatId"],
                "message": reply["html"],
            },
        }

    if surface == "channel_message" and targets.get("channelId") is not None:
        return {
            "kind": "tool_call",
            "tool": "create_message_in_channel",
            "args": {
                "channelId": targets["channelId"],
                "message": reply["html"],
            },
        }

    raise RuntimeErrorWithContext(
        f"no supported reply transport for surface={surface} with available targets={json.dumps(targets, default=str)}"
    )


def build_execution_plan(action: dict[str, Any], normalized: dict[str, Any], targets: dict[str, Any]) -> list[dict[str, Any]]:
    plan: list[dict[str, Any]] = []

    reply = action.get("reply")
    if isinstance(reply, dict):
        plan.append(pick_reply_transport(reply, normalized, targets))

    for write in action.get("writes", []):
        if write["type"] == "update_task":
            plan.append({
                "kind": "tool_call",
                "tool": "update_task",
                "args": {
                    "taskId": write["taskId"],
                    **write["fields"],
                },
            })
            continue
        if write["type"] == "request_review":
            step_args: dict[str, Any] = {
                "taskId": write["taskId"],
                "reviewers": write["reviewers"],
            }
            if write.get("message"):
                step_args["message"] = write["message"]
            plan.append({
                "kind": "tool_call",
                "tool": "request_review",
                "args": step_args,
            })
            continue
        raise RuntimeErrorWithContext(f"unsupported write type in initial runtime: {write['type']}")

    if action.get("status", {}).get("markDone"):
        plan.append({
            "kind": "async_status",
            "tool": "set-status-async",
            "args": {
                "event": targets["eventType"],
                "id": targets["triggerId"],
                "status": "done",
            },
        })

    return plan


def execute_plan(plan: list[dict[str, Any]], *, wrapper_path: Path, persona: str) -> list[dict[str, Any]]:
    results = []
    for step in plan:
        if step["kind"] == "tool_call":
            result = wrapper_call(
                wrapper_path=wrapper_path,
                persona=persona,
                tool=step["tool"],
                args=step["args"],
            )
        elif step["kind"] == "async_status":
            result = wrapper_set_status_async(
                wrapper_path=wrapper_path,
                persona=persona,
                event_type=step["args"]["event"],
                trigger_id=step["args"]["id"],
                status=step["args"]["status"],
            )
        else:
            raise RuntimeErrorWithContext(f"unknown plan step kind: {step['kind']}")
        results.append({
            "step": step,
            "result": result,
        })
    return results


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Standalone BasicOps structured runtime harness")
    parser.add_argument("payload", nargs="?", help="BasicOps webhook payload JSON path. Defaults to stdin.")
    parser.add_argument("--action-file", help="Structured runtime action JSON path. Use '-' to read from stdin.")
    parser.add_argument("--payload-stdin", action="store_true", help="Read payload JSON from stdin.")
    parser.add_argument("--action-stdin", action="store_true", help="Read action JSON from stdin.")
    parser.add_argument("--agent-id", default="thor")
    parser.add_argument("--agent-name")
    parser.add_argument("--self-user-id", type=int)
    parser.add_argument("--mention-term", action="append", default=[])
    parser.add_argument("--other-agent-term", action="append", default=[])
    parser.add_argument("--profile", default="thor", help="BasicOps persona/profile for basicops_mcp.py")
    parser.add_argument("--wrapper-path", default=str(DEFAULT_WRAPPER_PATH))
    parser.add_argument("--prompt-path", default=str(DEFAULT_PROMPT_PATH))
    parser.add_argument("--input-schema-path", default=str(DEFAULT_INPUT_SCHEMA_PATH))
    parser.add_argument("--action-schema-path", default=str(DEFAULT_ACTION_SCHEMA_PATH))
    parser.add_argument("--openclaw-bin", default="openclaw")
    parser.add_argument("--runtime-timeout-seconds", "--thor-timeout-seconds", dest="runtime_timeout_seconds", type=int, default=180)
    parser.add_argument("--runtime-thinking", "--thor-thinking", dest="runtime_thinking", help="Optional thinking override passed to `openclaw agent`")
    parser.add_argument("--runtime-model", "--thor-model", dest="runtime_model", help="Optional model override passed to `openclaw agent`")
    parser.add_argument("--runtime-session-key", "--thor-session-key", dest="runtime_session_key", help="Optional explicit session key to reuse instead of creating a fresh isolated session")
    parser.add_argument("--print-prompt-only", action="store_true", help="Only print the compact prompt payload.")
    parser.add_argument("--execute", action="store_true", help="Execute validated actions through basicops_mcp.py")
    parser.add_argument("--pretty", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    if args.payload_stdin and args.payload:
        raise SystemExit("provide either a payload path or --payload-stdin, not both")
    if args.action_stdin and args.action_file:
        raise SystemExit("provide either --action-file or --action-stdin, not both")
    if args.payload_stdin and args.action_stdin:
        raise SystemExit("payload and action cannot both be read from stdin")

    payload = load_json_source(args.payload, allow_stdin=args.payload_stdin or not args.payload, label="payload")

    prompt_text = load_text_file(Path(args.prompt_path))
    input_schema = load_json_file(args.input_schema_path)
    action_schema = load_json_file(args.action_schema_path)

    normalized = normalize_basicops_event(
        payload,
        agent_id=args.agent_id,
        agent_name=args.agent_name,
        self_user_id=args.self_user_id,
        mention_terms=args.mention_term,
        other_agent_terms=args.other_agent_term,
    )
    validate_json(normalized, input_schema, label="normalized input")

    prompt_payload = build_prompt_payload(
        prompt_text=prompt_text,
        input_schema=input_schema,
        action_schema=action_schema,
        normalized_input=normalized,
        wrapper_path=Path(args.wrapper_path),
        persona=args.profile,
    )
    tooling_notes = build_runtime_tooling_notes(
        wrapper_path=Path(args.wrapper_path),
        persona=args.profile,
    )
    runtime_message = build_runtime_invocation_message(
        prompt_text=prompt_text,
        action_schema=action_schema,
        normalized_input=normalized,
        tooling_notes=tooling_notes,
    )

    if args.print_prompt_only and not args.action_file and not args.action_stdin:
        print(json.dumps(prompt_payload, indent=2 if args.pretty else None))
        return 0

    action = None
    runtime_invocation = None
    if args.action_file or args.action_stdin:
        action = load_json_source(args.action_file, allow_stdin=args.action_stdin, label="action")
        validate_json(action, action_schema, label="action")
    else:
        invocation_result, action = invoke_agent_via_openclaw(
            openclaw_bin=args.openclaw_bin,
            agent_id=args.agent_id,
            timeout_seconds=args.runtime_timeout_seconds,
            thinking=args.runtime_thinking,
            model=args.runtime_model,
            message=runtime_message,
            session_key=args.runtime_session_key,
        )
        validate_json(action, action_schema, label="action")
        meta = invocation_result.get("result", {}).get("meta", {})
        agent_meta = meta.get("agentMeta", {}) if isinstance(meta, dict) else {}
        system_prompt_report = meta.get("systemPromptReport", {}) if isinstance(meta, dict) else {}
        payloads = invocation_result.get("result", {}).get("payloads")
        first_payload_text = None
        if isinstance(payloads, list) and payloads and isinstance(payloads[0], dict):
            first_payload_text = payloads[0].get("text")
        runtime_invocation = {
            "invokedAt": datetime.now(timezone.utc).isoformat(),
            "runId": invocation_result.get("runId"),
            "status": invocation_result.get("status"),
            "summary": invocation_result.get("summary"),
            "sessionId": agent_meta.get("sessionId"),
            "sessionKey": system_prompt_report.get("sessionKey"),
            "workspaceDir": system_prompt_report.get("workspaceDir"),
            "provider": agent_meta.get("provider"),
            "model": agent_meta.get("model"),
            "durationMs": meta.get("durationMs") if isinstance(meta, dict) else None,
            "runnerTransport": invocation_result.get("runnerTransport"),
            "assistantText": first_payload_text,
        }

    targets = extract_surface_targets(payload, normalized)
    plan = build_execution_plan(action, normalized, targets) if action is not None else []

    output: dict[str, Any] = {
        "mode": "execute" if args.execute else "dry_run",
        "normalizedInput": normalized,
        "promptPayload": prompt_payload,
        "runtimeRequest": {
            "agentId": args.agent_id,
            "timeoutSeconds": args.runtime_timeout_seconds,
            "thinking": args.runtime_thinking,
            "model": args.runtime_model,
            "message": runtime_message,
            "sessionKey": args.runtime_session_key,
            "sessionIsolation": "explicit-reused-session-key" if args.runtime_session_key else "per-invocation-session-key",
        },
        "runtimeInvocation": runtime_invocation,
        "action": action,
        "executionPlan": plan,
    }

    if args.execute:
        output["executionResults"] = execute_plan(
            plan,
            wrapper_path=Path(args.wrapper_path),
            persona=args.profile,
        )

    print(json.dumps(output, indent=2 if args.pretty else None))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SchemaValidationError as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(2)
    except RuntimeErrorWithContext as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(3)
