#!/usr/bin/env python3
import json
from pathlib import Path
from typing import Any

import jsonschema


class SchemaValidationError(ValueError):
    pass


def load_json_file(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def validate_json(instance: Any, schema: dict[str, Any], *, label: str) -> None:
    validator = jsonschema.Draft202012Validator(schema)
    errors = sorted(validator.iter_errors(instance), key=lambda err: list(err.absolute_path))
    if not errors:
        return

    first = errors[0]
    path = ".".join(str(part) for part in first.absolute_path) or "$"
    raise SchemaValidationError(f"{label} failed schema validation at {path}: {first.message}")
