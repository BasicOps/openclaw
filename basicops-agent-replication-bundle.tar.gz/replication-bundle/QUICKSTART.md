# Quick Start

This is now the **manual quickstart**.

If the target machine already has OpenClaw running and the operator is not comfortable with Linux setup, use these files instead:

- `START-HERE.md`
- `INSTALL-WITH-OPENCLAW.md`

Use this document when you want the fastest manual path to get the bundle onto a target machine, scaffold an agent, and hand the operator a clean `NEXT-STEPS.md` to finish from.

This bundle supports both common local service managers used in this flow:

- **Linux**: `systemctl --user`
- **macOS**: `launchd` / `launchctl`

OpenClaw commands like `openclaw gateway status` are the same on both platforms.

## Fast path

1. unpack the bundle on the target machine
2. make sure the machine has the required tools
3. run guided setup
4. restart the gateway if guided setup changed `agents.list`
5. open the generated `NEXT-STEPS.md` and follow it in order

## 1. Unpack the bundle

```bash
mkdir -p ~/basicops-agent-bundle
tar -xzf basicops-agent-replication-bundle.tar.gz -C ~/basicops-agent-bundle --strip-components=1
```

## 2. Make sure the machine has the basics

Before guided setup can succeed, the target machine should already have:

- `python3`
- `openclaw`
- `mcporter`
- one runtime CLI, for example `codex`, `claude`, or `gemini`

Check first:

```bash
python3 --version
openclaw status
mcporter --version
codex --version
```

If `python3` is missing, install it first.

Examples:

- Debian or Ubuntu:

```bash
sudo apt update
sudo apt install -y python3
```

- macOS with Homebrew:

```bash
brew install python
```

Example setup with Codex if `mcporter` or `codex` is still missing:

```bash
sudo npm install -g mcporter
npm install -g @openai/codex
mcporter --version
codex --version
```

If the Codex install fails with a permissions error, retry with:

```bash
sudo npm install -g @openai/codex
codex --version
```

After installing anything, rerun the original checks:

```bash
python3 --version
openclaw status
mcporter --version
codex --version
```

If the runtime CLI installs successfully but prompts you to sign in the first time you run it, finish that login step before continuing.

## 3. Run guided setup

Recommended path:

```bash
python3 ~/basicops-agent-bundle/scripts/guided_setup_agent.py \
  --runtime codex
```

The script now asks for the agent ID up front. If you just press Enter, the default is `helper`.

What guided setup does:

1. runs preflight checks
2. asks for the key values first, including agent ID, display name, profile, hook path, and shim port
3. scaffolds the agent-specific files
4. can add the agent to `agents.list`
5. writes a generated `NEXT-STEPS.md`

On a fresh OpenClaw install, if guided setup registers the first explicit non-main agent, it also seeds a safe default `main` agent so the web control panel keeps working.
By default, if guided setup updates `~/.openclaw/openclaw.json`, it creates a timestamped backup first.
For Codex-backed ACP agents, the generated hook mapping now also pins `openai-codex/gpt-5.4` so webhook runs use Codex OAuth on the target machine.

If guided setup updates `agents.list`, restart the gateway before live testing:

```bash
openclaw gateway restart
openclaw gateway status
```

## 4. Finish setup using the generated handoff

Open the generated file for your agent, for example:

- `~/basicops-agent-bundle/generated/helper/NEXT-STEPS.md`

Guided setup prints the exact path it wrote. Once that file exists, the rest of the setup should be done by following that document.

That file is the real handoff. It contains the agent-specific values and the final steps for:

- making the generated files live
- finishing BasicOps persona setup
- applying the OpenClaw hook mapping
- starting the local shim service
- configuring the reverse proxy
- testing locally first, then externally, then in BasicOps

If this is a brand new BasicOps-backed identity, the operator still needs to create the BasicOps user and API key manually. The bundle only handles the local-machine and OpenClaw side.

## Other entry points

### Preflight only

```bash
python3 ~/basicops-agent-bundle/scripts/preflight_replication_bundle.py \
  --runtime codex
```

JSON mode:

```bash
python3 ~/basicops-agent-bundle/scripts/preflight_replication_bundle.py \
  --runtime codex \
  --json
```

### Scaffold directly if you already know the values

```bash
python3 ~/basicops-agent-bundle/scripts/scaffold_agent_from_bundle.py \
  --output-dir ~/basicops-agent-bundle/generated/ops \
  --agent-id ops \
  --display-name OpsAgent \
  --basicops-profile ops \
  --hook-path basicops-ops \
  --shim-port 18892 \
  --register-agent
```

Then open:

- `~/basicops-agent-bundle/generated/ops/NEXT-STEPS.md`

### Full manual guide

If you want the detailed path:

- `docs/INSTALL.md`

## What matters most

For a new operator, the important values are just these three:

- the generated hook path
- the generated local shim port
- the public webhook path used in BasicOps

Those three values must line up.

## Main files

- quickstart: `QUICKSTART.md`
- full manual guide: `docs/INSTALL.md`
- guided setup: `scripts/guided_setup_agent.py`
- preflight: `scripts/preflight_replication_bundle.py`
- scaffolder: `scripts/scaffold_agent_from_bundle.py`
- bundle overview: `README.md`
