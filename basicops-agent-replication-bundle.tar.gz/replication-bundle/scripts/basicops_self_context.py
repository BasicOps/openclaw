#!/usr/bin/env python3
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional


PYTHON_BIN = sys.executable or "python3"


def _display_name(first_name: Optional[str], last_name: Optional[str], email: Optional[str]) -> Optional[str]:
    parts = [part for part in [first_name, last_name] if part]
    if parts:
        return " ".join(parts)
    return email or None


def run_get_current_user(profile: str, wrapper_path: str) -> dict[str, Any]:
    proc = subprocess.run(
        [
            PYTHON_BIN,
            wrapper_path,
            "--as",
            profile,
            "call",
            "--tool",
            "get_current_user",
            "--args",
            "{}",
        ],
        text=True,
        capture_output=True,
        check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"get_current_user failed rc={proc.returncode} stdout={proc.stdout!r} stderr={proc.stderr!r}"
        )

    stdout = (proc.stdout or "").strip()
    if not stdout:
        raise RuntimeError("get_current_user returned empty stdout")

    try:
        parsed = json.loads(stdout)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"get_current_user returned non-JSON output: {stdout!r}") from exc

    if isinstance(parsed, dict) and "data" in parsed and isinstance(parsed["data"], dict):
        return parsed["data"]
    if isinstance(parsed, dict):
        return parsed
    raise RuntimeError(f"get_current_user returned unexpected payload type: {type(parsed).__name__}")


def normalize_self_context(raw: dict[str, Any], agent_id: str, profile: str) -> dict[str, Any]:
    user_id = raw.get("id")
    if user_id is None:
        raise RuntimeError(f"get_current_user missing id: {raw!r}")

    first_name = raw.get("firstName")
    last_name = raw.get("lastName")
    email = raw.get("email")

    return {
        "agentId": agent_id,
        "profile": profile,
        "userId": user_id,
        "firstName": first_name,
        "lastName": last_name,
        "displayName": _display_name(first_name, last_name, email),
        "email": email,
        "timeZone": raw.get("timeZone"),
        "dateFormat": raw.get("dateFormat"),
        "timeFormat": raw.get("timeFormat"),
        "picture": raw.get("picture"),
        "fetchedAt": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "source": "get_current_user",
    }


def read_cache(cache_path: str, max_age_seconds: int) -> Optional[dict[str, Any]]:
    path = Path(cache_path).expanduser()
    if not path.exists():
        return None

    try:
        payload = json.loads(path.read_text())
    except Exception:
        return None

    self_context = payload.get("selfContext") if isinstance(payload, dict) else None
    if not isinstance(self_context, dict):
        return None

    fetched_at = self_context.get("fetchedAt")
    if not isinstance(fetched_at, str):
        return None

    try:
        fetched_dt = datetime.fromisoformat(fetched_at.replace("Z", "+00:00"))
    except ValueError:
        return None

    age_seconds = (datetime.now(timezone.utc) - fetched_dt).total_seconds()
    if max_age_seconds >= 0 and age_seconds > max_age_seconds:
        return None

    return payload


def write_cache(cache_path: str, payload: dict[str, Any]) -> None:
    path = Path(cache_path).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", dir=path.parent, delete=False) as tmp:
        json.dump(payload, tmp, indent=2)
        tmp.write("\n")
        tmp_path = Path(tmp.name)
    tmp_path.replace(path)


def get_self_context(
    agent_id: str,
    profile: str,
    wrapper_path: str,
    cache_path: str,
    max_age_seconds: int,
    force_refresh: bool = False,
) -> dict[str, Any]:
    if not force_refresh:
        cached = read_cache(cache_path, max_age_seconds)
        if cached and isinstance(cached.get("selfContext"), dict):
            return cached["selfContext"]

    raw = run_get_current_user(profile, wrapper_path)
    self_context = normalize_self_context(raw, agent_id=agent_id, profile=profile)
    payload = {
        "version": 1,
        "selfContext": self_context,
        "raw": raw,
    }
    write_cache(cache_path, payload)
    return self_context
