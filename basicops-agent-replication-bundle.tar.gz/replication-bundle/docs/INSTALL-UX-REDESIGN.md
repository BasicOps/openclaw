# BasicOps Replication Bundle, novice-first redesign

## Recommendation

Make **AI-assisted installation the primary path**.
Keep **manual installation** as the fallback path for advanced operators.

This bundle currently assumes too much Linux and reverse-proxy literacy for a novice operator.
The local OpenClaw AI is better suited to:

- validating command output
- catching wrong hostnames, ports, and hook paths
- adapting when package names or service managers differ
- assisting with reverse-proxy setup
- deciding when a checkpoint passed vs failed

## Product shape

Ship two distinct operator paths.

### Path 1, default: install with local OpenClaw

Audience:
- novice operators
- users who already have OpenClaw running locally

Goal:
- minimize Linux reasoning
- minimize free-form troubleshooting
- bias toward copy/paste and AI validation

### Path 2, fallback: manual install

Audience:
- advanced operators
- environments where local OpenClaw cannot assist

Goal:
- preserve the full explicit workflow
- keep the current detailed install/reference material

## Proposed file layout

### Top-level docs

- `START-HERE.md`
  - single landing page
  - asks one question: "Do you want to install with your local OpenClaw assistant?"
  - points to the right path

- `INSTALL-WITH-OPENCLAW.md`
  - novice-first
  - short copy/paste flow
  - almost no conceptual explanation

- `INSTALL-MANUAL.md`
  - advanced human fallback
  - can replace or alias the current `docs/INSTALL.md`

- `AI-OPERATOR-GUIDE.md`
  - written for OpenClaw or a remote helper
  - includes validation logic, failure branches, checkpoints, expected outputs

- `TROUBLESHOOTING-CHECKPOINTS.md`
  - compact map of common failure signatures
  - grouped by stage: prerequisites, hook config, shim, proxy, public webhook

### Keep, but simplify their roles

- `README.md`
  - overview only
  - architecture and bundle contents
  - not install-first

- `HANDOFF.md`
  - handoff expectations and bundle contents
  - not the main install path

- `QUICKSTART.md`
  - can be retired or turned into a short pointer to `START-HERE.md`

## Proposed novice flow

The novice document should be short enough that a user can complete the whole thing while barely understanding Linux.

### `INSTALL-WITH-OPENCLAW.md`

Recommended structure:

1. **Install a few required tools**
   - exact commands only
   - separate Debian/Ubuntu and macOS sections
   - no extra prose beyond "copy and paste this"

2. **Unpack the bundle**
   - one command block

3. **Run guided setup**
   - one command block

4. **Paste this exact message to your local OpenClaw assistant**
   - example:
     - "Please help me finish installing this BasicOps agent bundle on this machine. Validate each step, run the safe commands for me when possible, and stop to ask before any risky or external change. Read `AI-OPERATOR-GUIDE.md` inside the bundle first."

5. **Approve actions when OpenClaw asks**
   - short explanation only

6. **If something fails, paste the output back to OpenClaw**
   - one sentence

### Writing rules for the novice doc

- prefer command blocks over prose
- one command block per step
- each step ends with either:
  - "If this worked, continue"
  - "If this failed, paste the output to OpenClaw"
- avoid terms like:
  - reverse proxy
  - hook mapping
  - systemd drop-in
  - TLS policy
  unless the user must paste them literally
- do not ask novices to infer paths, ports, or hostnames from earlier sections
- surface the exact generated file path to open next

## Proposed AI-assisted flow

### `AI-OPERATOR-GUIDE.md`

This should be the authoritative procedure for an OpenClaw agent.

Recommended sections:

1. **Intent of the guide**
   - the human is a novice
   - prefer doing safe actions directly
   - prefer validation over explanation

2. **Inputs to collect**
   - agent id
   - BasicOps profile
   - public hostname
   - desired webhook path
   - chosen runtime

3. **Validation checkpoints**
   - prerequisites installed
   - OpenClaw healthy
   - guided setup completed
   - generated files exist
   - `agents.list` contains the agent
   - local hooks config applied correctly
   - shim service active and listening
   - reverse proxy active on 80/443
   - local smoke test passes
   - public smoke test passes

4. **Failure branches**
   - wrong hostname in Caddy or Traefik
   - wrong shim port
   - wrong `OPENCLAW_FORWARD_URL`
   - hook path mismatch
   - missing `hooks.enabled/path/token`
   - DNS resolves to wrong IP
   - TLS certificate not issued

5. **Command policy**
   - do safe reads/checks directly
   - ask before destructive edits or public-facing changes
   - preserve exact commands in approval requests

6. **Expected output signatures**
   - what success looks like for:
     - `openclaw status`
     - local shim curl
     - public webhook curl
     - Caddy logs
     - Traefik logs

7. **Stop conditions**
   - when to ask the human for a decision
   - when to escalate to a manual helper

## Suggested bundle/script changes

### 1. Generate an AI handoff prompt automatically

After guided setup, also write:

- `generated/<agent>/OPENCLAW-INSTALL-PROMPT.txt`

Contents:
- brief explanation of what the user should ask their local OpenClaw assistant to do
- path to the generated `NEXT-STEPS.md`
- key values already filled in

This removes guesswork from the human.

### 2. Generate a compact machine-readable status file

After guided setup, write something like:

- `generated/<agent>/install-context.json`

Include:
- agent id
- profile
- hook path
- shim port
- expected local hook URL
- expected public webhook URL
- generated file paths

This gives OpenClaw structured inputs instead of forcing it to scrape prose.

### 3. Add a checkpoint validator script

Add a script like:

- `scripts/validate_install_checkpoints.py`

It should test:
- required files exist
- configured values align
- local port is listening
- local smoke test response shape
- optional public hostname checks

This would greatly reduce AI guesswork.

### 4. Add a "copy/paste mode" output option

The guided setup helper could emit:

- `NEXT-STEPS-NOVICE.md`
  - command blocks only
  - minimal commentary

and

- `NEXT-STEPS-AI.md`
  - same steps but with validation notes and likely failure meanings

### 5. Make reverse-proxy setup more opinionated

For novices, pick one default.

Recommendation:
- default to **Caddy** on Debian/Ubuntu unless the machine is already clearly using Traefik

The docs should stop presenting proxy setup as an abstract choice too early.

## Suggested writing style changes

Current docs are good reference material, but they mix:
- conceptual explanation
- operator policy
- commands
- troubleshooting

For novice UX, split those apart.

### Good pattern

- short sentence
- one code block
- one expected outcome
- one fallback sentence

Example:

```md
## Start the shim service

Copy and paste this:

```bash
systemctl --user restart basicops-preack@helper.service
systemctl --user status basicops-preack@helper.service --no-pager
```

If you see `active (running)`, continue.
If not, paste the output to OpenClaw.
```

## Rollout order

1. Add `START-HERE.md`
2. Add `INSTALL-WITH-OPENCLAW.md`
3. Add `AI-OPERATOR-GUIDE.md`
4. Add generated `OPENCLAW-INSTALL-PROMPT.txt`
5. Add `install-context.json`
6. Add checkpoint validator script
7. Demote current `QUICKSTART.md` into advanced/reference status

## Opinionated conclusion

The biggest improvement is not "better explanations".
The biggest improvement is:

- fewer decisions for the novice
- shorter copy/paste steps
- stronger AI-facing validation artifacts

In other words:

- **humans get a tiny script-like guide**
- **OpenClaw gets the real playbook**
