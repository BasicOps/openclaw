#!/usr/bin/env bash
set -euo pipefail

DRY_RUN=0
for arg in "$@"; do
  case "$arg" in
    --dry-run) DRY_RUN=1 ;;
    *) echo "Unknown arg: $arg" >&2; exit 2 ;;
  esac
done
run() {
  printf '+ %s
' "$*"
  if (( DRY_RUN == 1 )); then
    return 0
  fi
  eval "$*"
}

echo 'TARGET AGENT: meriam'
echo 'Applying local files for meriam...'
echo 'This script copies files into place only. It does not restart the gateway, start services, or hit live hooks.'
run "mkdir -p ~/.config/basicops-agents ~/.config/systemd/user /home/hjhlarsen/.cache/basicops-agents /home/hjhlarsen/.config/systemd/user/openclaw-gateway.service.d /home/hjhlarsen/.openclaw/hooks/transforms"
run "install -m 0644 /home/hjhlarsen/basicops-agent-bundle/generated/meriam/meriam.env /home/hjhlarsen/.config/basicops-agents/meriam.env"
run "install -m 0644 /home/hjhlarsen/basicops-agent-bundle/generated/meriam/basicops-preack@.service /home/hjhlarsen/.config/systemd/user/basicops-preack@.service"
run "install -m 0644 /home/hjhlarsen/basicops-agent-bundle/generated/meriam/meriam-fast-hook.js /home/hjhlarsen/.openclaw/hooks/transforms/meriam-fast-hook.js"
run "systemctl --user daemon-reload"
if (( DRY_RUN == 1 )); then
  echo 'DRY RUN: file copy commands were printed only, so live-path verification is skipped.'
  exit 0
fi
test -f /home/hjhlarsen/.config/basicops-agents/meriam.env && echo 'PASS live env exists: /home/hjhlarsen/.config/basicops-agents/meriam.env' || (echo 'FAIL live env missing: /home/hjhlarsen/.config/basicops-agents/meriam.env' && exit 1)
test -f /home/hjhlarsen/.config/systemd/user/basicops-preack@.service && echo 'PASS live service exists: /home/hjhlarsen/.config/systemd/user/basicops-preack@.service' || (echo 'FAIL live service missing: /home/hjhlarsen/.config/systemd/user/basicops-preack@.service' && exit 1)
test -f /home/hjhlarsen/.openclaw/hooks/transforms/meriam-fast-hook.js && echo 'PASS live transform exists: /home/hjhlarsen/.openclaw/hooks/transforms/meriam-fast-hook.js' || (echo 'FAIL live transform missing: /home/hjhlarsen/.openclaw/hooks/transforms/meriam-fast-hook.js' && exit 1)
