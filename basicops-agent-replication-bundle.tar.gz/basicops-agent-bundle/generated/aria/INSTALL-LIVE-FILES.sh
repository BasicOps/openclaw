#!/usr/bin/env bash
set -euo pipefail

echo 'TARGET AGENT: aria'
echo 'Installing live files for aria...'
mkdir -p ~/.config/basicops-agents ~/.config/systemd/user /home/hjhlarsen/.cache/basicops-agents /home/hjhlarsen/.config/systemd/user/openclaw-gateway.service.d
install -m 0644 /home/hjhlarsen/basicops-agent-bundle/generated/aria/aria.env /home/hjhlarsen/.config/basicops-agents/aria.env
install -m 0644 /home/hjhlarsen/basicops-agent-bundle/generated/aria/basicops-preack@.service /home/hjhlarsen/.config/systemd/user/basicops-preack@.service
systemctl --user daemon-reload
test -f /home/hjhlarsen/.config/basicops-agents/aria.env && echo 'PASS live env exists: /home/hjhlarsen/.config/basicops-agents/aria.env' || (echo 'FAIL live env missing: /home/hjhlarsen/.config/basicops-agents/aria.env' && exit 1)
test -f /home/hjhlarsen/.config/systemd/user/basicops-preack@.service && echo 'PASS live service exists: /home/hjhlarsen/.config/systemd/user/basicops-preack@.service' || (echo 'FAIL live service missing: /home/hjhlarsen/.config/systemd/user/basicops-preack@.service' && exit 1)
