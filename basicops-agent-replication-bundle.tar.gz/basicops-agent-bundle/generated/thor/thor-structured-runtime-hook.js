import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';

const RUNTIME_PATH = path.join(os.homedir(), 'basicops-agent-bundle', 'scripts', 'basicops_structured_runtime.py');
const SELF_CONTEXT_PATH = "/home/hjhlarsen/.cache/basicops-agents/thor-self.json";
const LOG_PATH = path.join(os.tmpdir(), "thor-structured-runtime-hook.log");
const AGENT_ID = "thor";
const AGENT_NAME = "Thor";
const PROFILE = "thor";

function loadSelfUserId() {
  try {
    const raw = JSON.parse(fs.readFileSync(SELF_CONTEXT_PATH, 'utf8'));
    const value = raw?.selfContext?.userId ?? raw?.userId ?? null;
    if (value === null || value === undefined || value === '') return null;
    return String(value);
  } catch {
    return null;
  }
}

export default async function transform(ctx) {
  const payload = ctx?.payload ?? null;
  const eventType = payload?.event ?? payload?.events?.[0]?.event ?? 'unknown-event';
  const context = payload?.context ?? payload?.events?.[0]?.data ?? {};
  const currentEntityId = context?.replyId ?? context?.id ?? context?.Id ?? context?.messageId ?? context?.taskId ?? context?.projectId ?? context?.chatId ?? context?.groupChatId ?? context?.groupchatId ?? context?.channelId ?? 'no-entity';
  const fileToken = `${eventType}-${currentEntityId}-${Date.now()}`.replace(/[^a-zA-Z0-9._-]+/g, '_');
  const payloadPath = path.join(os.tmpdir(), `${AGENT_ID}-hook-${fileToken}.json`);
  fs.writeFileSync(payloadPath, JSON.stringify(payload, null, 2), 'utf8');

  const fd = fs.openSync(LOG_PATH, 'a');
  fs.writeSync(fd, `
=== ${new Date().toISOString()} event=${eventType} entity=${currentEntityId} ===
`);
  fs.writeSync(fd, `payload=${payloadPath}
`);

  const args = [RUNTIME_PATH, payloadPath, '--execute', '--agent-id', AGENT_ID, '--agent-name', AGENT_NAME, '--profile', PROFILE];
  const selfUserId = loadSelfUserId();
  if (selfUserId) {
    args.push('--self-user-id', selfUserId);
  }

  const child = spawn('python3', args, {
    detached: true,
    stdio: ['ignore', fd, fd],
  });
  child.unref();
  fs.closeSync(fd);

  return null;
}
