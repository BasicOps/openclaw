#!/usr/bin/env bash
set -euo pipefail

status=0
pass(){ printf '[PASS] %s\n' "$1"; }
fail(){ printf '[FAIL] %s\n' "$1"; status=1; }
warn(){ printf '[WARN] %s\n' "$1"; }

echo 'TARGET AGENT: meriam'
echo 'READ ONLY: /home/hjhlarsen/basicops-agent-bundle/generated/meriam/NEXT-STEPS.md'

PERSONAS="/home/hjhlarsen/.config/basicops-agents/basicops-personas.json"
PROFILE="meriam"
LIVE_ENV="/home/hjhlarsen/.config/basicops-agents/meriam.env"
LIVE_SERVICE="/home/hjhlarsen/.config/systemd/user/basicops-preack@.service"
OPENCLAW_CONFIG="/home/hjhlarsen/.openclaw/openclaw.json"
EXPECTED_AGENT="meriam"
EXPECTED_WORKSPACE="/home/hjhlarsen/.openclaw/workspace-meriam"
EXPECTED_HOOK="basicops-meriam"
LOCAL_HOOK_URL="http://127.0.0.1:18789/hooks/basicops-meriam"
EXPECTED_TRANSFORM="meriam-fast-hook.js"
LIVE_TRANSFORM="/home/hjhlarsen/.openclaw/hooks/transforms/meriam-fast-hook.js"

export PERSONAS PROFILE LIVE_ENV LIVE_SERVICE OPENCLAW_CONFIG EXPECTED_AGENT EXPECTED_WORKSPACE EXPECTED_HOOK LOCAL_HOOK_URL EXPECTED_TRANSFORM LIVE_TRANSFORM

[[ -f "$PERSONAS" ]] && pass "personas file exists: $PERSONAS" || fail "personas file missing: $PERSONAS"
/usr/bin/python3 - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ['PERSONAS']).expanduser()
profile = os.environ['PROFILE']
if not path.is_file():
    raise SystemExit(0)
try:
    data = json.loads(path.read_text())
except Exception as exc:
    print(f'[FAIL] personas file is not valid JSON: {exc}')
    raise SystemExit(2)
personas = data.get('personas') if isinstance(data, dict) else None
if isinstance(personas, dict) and profile in personas:
    print(f'[PASS] target persona profile exists: {profile}')
else:
    print(f'[FAIL] target persona profile missing: {profile}')
    raise SystemExit(1)
PY
rc=$?
if [[ $rc -eq 1 || $rc -eq 2 ]]; then status=1; fi
[[ -f "$LIVE_ENV" ]] && pass "live env copied: $LIVE_ENV" || fail "live env missing: $LIVE_ENV"
[[ -f "$LIVE_SERVICE" ]] && pass "live service copied: $LIVE_SERVICE" || fail "live service missing: $LIVE_SERVICE"
if [[ -n "$EXPECTED_TRANSFORM" ]]; then
  [[ -f "$LIVE_TRANSFORM" ]] && pass "live transform copied: $LIVE_TRANSFORM" || fail "live transform missing: $LIVE_TRANSFORM"
fi
/usr/bin/python3 - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ['OPENCLAW_CONFIG']).expanduser()
agent_id = os.environ['EXPECTED_AGENT']
expected_workspace = os.environ['EXPECTED_WORKSPACE']
if not path.is_file():
    print(f'[FAIL] OpenClaw config missing: {path}')
    raise SystemExit(1)
try:
    data = json.loads(path.read_text())
except Exception as exc:
    print(f'[FAIL] OpenClaw config is not valid JSON: {exc}')
    raise SystemExit(1)
agent_list = data.get('agents', {}).get('list', []) if isinstance(data, dict) else []
agent = None
for item in agent_list:
    if isinstance(item, dict) and item.get('id') == agent_id:
        agent = item
        break
if not agent:
    print(f'[FAIL] agent not registered in agents.list: {agent_id}')
    raise SystemExit(1)
runtime = agent.get('runtime') if isinstance(agent.get('runtime'), dict) else {}
acp = runtime.get('acp') if isinstance(runtime.get('acp'), dict) else {}
if runtime.get('type') != 'acp':
    print(f'[FAIL] runtime.type is not acp for agent: {agent_id}')
    raise SystemExit(1)
if agent.get('workspace') != expected_workspace:
    print(f'[FAIL] workspace mismatch for agent: expected {expected_workspace}, found {agent.get("workspace")}')
    raise SystemExit(1)
if runtime.get('cwd'):
    print('[FAIL] runtime.cwd is set. For ACP agents, cwd must live under runtime.acp.cwd, not runtime.cwd.')
    raise SystemExit(1)
if acp.get('cwd') != expected_workspace:
    print(f'[FAIL] runtime.acp.cwd mismatch: expected {expected_workspace}, found {acp.get("cwd")}')
    raise SystemExit(1)
print(f'[PASS] agent registered with valid ACP runtime block: {agent_id}')
PY
rc=$?
if [[ $rc -ne 0 ]]; then status=1; fi
/usr/bin/python3 - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ['OPENCLAW_CONFIG']).expanduser()
hook_path = os.environ['EXPECTED_HOOK']
agent_id = os.environ['EXPECTED_AGENT']
expected_transform = os.environ.get('EXPECTED_TRANSFORM', '').strip()
if not path.is_file():
    raise SystemExit(0)
data = json.loads(path.read_text())
mappings = data.get('hooks', {}).get('mappings', []) if isinstance(data, dict) else []
found = False
transform_ok = not expected_transform
for item in mappings:
    if not isinstance(item, dict):
        continue
    match = item.get('match') if isinstance(item.get('match'), dict) else {}
    if match.get('path') == hook_path and item.get('agentId') == agent_id:
        found = True
        transform = item.get('transform') if isinstance(item.get('transform'), dict) else {}
        if expected_transform:
            transform_ok = transform.get('module') == expected_transform
        break
if found:
    print(f'[PASS] hook mapping present for {agent_id} at /hooks/{hook_path}')
else:
    print(f'[FAIL] hook mapping missing for {agent_id} at /hooks/{hook_path}')
    raise SystemExit(1)
if expected_transform:
    if transform_ok:
        print(f'[PASS] hook mapping transform.module matches expected value: {expected_transform}')
    else:
        print(f'[FAIL] hook mapping transform.module mismatch for {agent_id}: expected {expected_transform}')
        raise SystemExit(1)
PY
rc=$?
if [[ $rc -ne 0 ]]; then status=1; fi
HOOK_TOKEN="$(/usr/bin/python3 - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ['OPENCLAW_CONFIG']).expanduser()
if not path.is_file():
    print('')
    raise SystemExit(0)
data = json.loads(path.read_text())
hooks = data.get('hooks') if isinstance(data.get('hooks'), dict) else {}
value = hooks.get('token') if isinstance(hooks.get('token'), str) else ''
print(value.strip())
PY
)"
if [[ -z "$HOOK_TOKEN" ]]; then
  fail "hooks.token missing in OpenClaw config"
else
  pass "hooks.token present in OpenClaw config"
fi

STATUS_OUT=/tmp/basicops-readonly-status.$$
if openclaw status --all >"$STATUS_OUT" 2>&1; then
  pass 'openclaw status --all completed'
  STATUS_OUT="$STATUS_OUT" /usr/bin/python3 - <<'PY'
import os, re, sys
from pathlib import Path
agent_id = os.environ['EXPECTED_AGENT']
text = Path(os.environ['STATUS_OUT']).read_text()
pattern = re.compile(rf"^│\s*{re.escape(agent_id)}\b.*│\s*(ABSENT|PRESENT)\s*│", re.M)
match = pattern.search(text)
if not match:
    print(f"[WARN] agent row not found in openclaw status --all: {agent_id}")
    raise SystemExit(0)
state = match.group(1)
if state == 'ABSENT':
    print(f"[PASS] bootstrap file absent according to openclaw status: {agent_id}")
else:
    print(f"[WARN] bootstrap file still present according to openclaw status: {agent_id}. Treat service and routing checks as separate from worker readiness.")
PY
else
  warn 'openclaw status --all failed'
fi
rm -f "$STATUS_OUT"

echo 'NOTE: CHECK-READONLY.sh validates config and local wiring only. It does not prove shim routing, worker readiness, or public webhook readiness.'
if [[ $status -eq 0 ]]; then
  echo 'RESULT: PASS. Read-only config checks passed.'
else
  echo 'RESULT: FAIL. Fix the failed config checks above before moving on.'
fi
exit $status
