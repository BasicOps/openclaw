# Validated State

This note captures the known-good state that was validated before this bundle was handed off.

## What was validated

- Worker and Helper are both functioning as separate BasicOps-backed OpenClaw agents.
- Both agents use their own local pre-ack shim service.
- Both agents successfully respond after webhook delivery is routed to the correct public `/webhooks/...` path.
- The stricter message/reply policy is in place so generated agents default to explicit mention behavior on message/reply surfaces.
- The replication bundle was cleaned up to be template-first and no longer ships stale generated agent output.

## Important routing lesson

A major failure mode was caused by mismatched public webhook paths.

Working pattern:
- public webhook path: `/webhooks/basicops-<agent>`
- reverse proxy route: `/webhooks/basicops-<agent>` -> `127.0.0.1:<shim-port>`
- local shim forward target: `http://127.0.0.1:18789/hooks/basicops-<agent>`

If the public webhook sender uses `/hooks/...` while the reverse proxy expects `/webhooks/...`, the agent may receive no shim traffic at all.

## Known-good examples

Example public webhook paths:
- `/webhooks/basicops-worker`
- `/webhooks/basicops-helper`

Example local shim ports used in the validated setup:
- worker -> `18891`
- helper -> `18893`

## Operator guidance

When setting up another agent:
- choose a fresh shim port
- choose a fresh public `/webhooks/basicops-<agent>` path
- keep agent id, BasicOps profile, hook path, and reverse-proxy route aligned
- verify the webhook sender path matches the reverse-proxy path exactly
- verify the shim receives POSTs before debugging agent prompt behavior

## Bundle state

At handoff time, this bundle is intended to be:
- template-first
- free of live secrets
- free of stale `generated/` outputs
- suitable for guided setup or manual setup on a different machine
