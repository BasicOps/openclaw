# Recipient Note

This bundle is meant to help you replicate a BasicOps-backed OpenClaw agent on another machine.

## Recommended starting point

Start with:
- `HANDOFF.md`
- `QUICKSTART.md`

If you want the safest path, use:
- preflight first
- then guided setup

Recommended first command:

Important: this helper does not install prerequisites for you. The target machine still needs `openclaw`, `mcporter`, and the chosen runtime CLI, for example `codex`, installed first.

Common beginner setup example:

```bash
sudo npm install -g mcporter
npm install -g @openai/codex
mcporter --version
codex --version
```

If the Codex install fails with a permissions error, retry with:

```bash
sudo npm install -g @openai/codex
codex --version
```

If `codex --version` works but Codex still needs login/auth, finish that before continuing.

```bash
python3 ~/basicops-agent-bundle/scripts/guided_setup_agent.py \
  --agent-id helper \
  --runtime codex
```

That is the recommended interactive pattern. Set the agent id up front, then let the script suggest the rest.
`--target-home` now defaults to the current user's home automatically, so only add it when you intentionally want to install for a different Unix account.

Replace:
- `codex` with the runtime you actually plan to use

## Before live setup

Make sure the target machine already has:
- `python3`
- `mcporter`
- `openclaw`
- your chosen runtime CLI
- the BasicOps wrapper on disk
- the pre-ack webhook shim on disk
- a valid BasicOps profile configured

## What this bundle does not do

This bundle does not automatically install:
- OpenClaw
- Codex, Claude Code, Pi, OpenCode, or Gemini CLI
- BasicOps credentials or profiles
- live tokens or secrets

## Main files

- `QUICKSTART.md` for the fastest safe path
- `docs/INSTALL.md` for the full manual procedure
- `scripts/preflight_replication_bundle.py` for readiness checks
- `scripts/guided_setup_agent.py` for guided scaffolding
- `scripts/scaffold_agent_from_bundle.py` for direct named-agent generation
