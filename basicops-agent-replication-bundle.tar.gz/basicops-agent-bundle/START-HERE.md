# Start Here

Before you choose an install path, make sure you already created the BasicOps agent user and API key you plan to use.
If you came here from the public GitHub README, that is the same API key from the BasicOps setup steps there.

This bundle now has two install paths.

## Recommended for most people

If the target machine already has a working OpenClaw install, use:

- `INSTALL-WITH-OPENCLAW.md`

This is the best path for novice users.
It keeps the human steps short and lets the local OpenClaw assistant validate outputs and help with reverse-proxy setup.

## Fallback for advanced operators

If you want to do everything yourself, use:

- `QUICKSTART.md`
- `INSTALL-MANUAL.md`
- `docs/INSTALL.md`

## Which path should I choose?

Choose **Install with OpenClaw** if any of these are true:

- you are not comfortable with Linux services
- you do not want to debug Caddy or Traefik manually
- you want the local OpenClaw assistant to validate each checkpoint
- you want a shorter copy/paste flow

Choose **Manual install** only if you are already comfortable with:

- shell commands
- service managers like `systemctl --user`
- editing config files
- reverse proxy setup

## Short answer

- novice user: `INSTALL-WITH-OPENCLAW.md`
- advanced operator: `QUICKSTART.md`

If you are a novice, the intended flow is now:
1. GitHub README
2. `UNPACK-FIRST.md`
3. `START-HERE.md`
4. `INSTALL-WITH-OPENCLAW.md`
