#!/usr/bin/env python3
import argparse
import json
import subprocess
import time
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
RUNTIME_PATH = SCRIPT_DIR / 'arla_fast_runtime.py'
WRAPPER_PATH = SCRIPT_DIR / 'basicops_mcp.py'


class DriverError(RuntimeError):
    pass


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description='Run Arla fast path against one webhook payload')
    parser.add_argument('payload', help='Webhook payload JSON file')
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--execute', action='store_true', help='Execute the Arla fast runtime result')
    mode.add_argument('--dry-run', action='store_true', help='Only build the Arla fast runtime result')
    parser.add_argument('--profile', default='arla')
    parser.add_argument('--arla-session-key', help='Optional explicit Arla session key to reuse for latency tests')
    return parser.parse_args()


def _compact(text: str, limit: int = 240) -> str:
    value = (text or '').strip().replace('\n', ' ')
    if len(value) <= limit:
        return value
    return f"{value[:limit]}..."


def _run_json_command(cmd: list[str]) -> dict[str, Any]:
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        detail = (proc.stderr or proc.stdout).strip() or f'exit {proc.returncode}'
        raise DriverError(detail)
    try:
        return json.loads(proc.stdout)
    except json.JSONDecodeError as exc:
        raise DriverError(f'runtime returned invalid JSON: {exc}') from exc


def _wrapper_call(*, profile: str, tool: str, args: dict[str, Any]) -> tuple[dict[str, Any], int]:
    started = time.perf_counter()
    cmd = [
        'python3',
        str(WRAPPER_PATH),
        '--as',
        profile,
        'call',
        '--tool',
        tool,
        '--args',
        json.dumps(args),
    ]
    result = _run_json_command(cmd)
    duration_ms = int((time.perf_counter() - started) * 1000)
    return result, duration_ms


def _status_done_async(*, profile: str, event: str | None, event_id: Any) -> None:
    if not isinstance(event, str) or not event.strip() or event_id in (None, ''):
        return
    cmd = [
        'python3',
        str(WRAPPER_PATH),
        '--as',
        profile,
        'set-status-async',
        '--event',
        event,
        '--id',
        str(event_id),
        '--status',
        'done',
    ]
    subprocess.run(cmd, capture_output=True, text=True)


def _extract_event_and_context(payload: Any) -> tuple[str | None, dict[str, Any]]:
    if not isinstance(payload, dict):
        return None, {}
    events = payload.get('events')
    if isinstance(events, list) and events and isinstance(events[0], dict):
        event = events[0]
        data = event.get('data') if isinstance(event.get('data'), dict) else {}
        return event.get('event'), data
    raw_context = payload.get('context')
    raw_data = payload.get('data')
    if isinstance(raw_context, dict):
        data = dict(raw_context)
    elif isinstance(raw_data, dict):
        data = dict(raw_data)
    else:
        data = {}
    return payload.get('event'), data


def _reply_transport_candidates(context: dict[str, Any], html_output: str) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    reply_target_message_id = context.get('messageId') or context.get('replyTargetMessageId')
    current_entity_message_id = context.get('id') or context.get('Id') or context.get('replyId')

    seen_message_ids: set[str] = set()
    for message_id in (reply_target_message_id, current_entity_message_id):
        if message_id is None:
            continue
        message_key = str(message_id)
        if message_key in seen_message_ids:
            continue
        seen_message_ids.add(message_key)
        candidates.append(
            {
                'tool': 'create_reply_in_message',
                'args': {
                    'messageId': message_id,
                    'message': html_output,
                },
            }
        )

    if context.get('taskId') is not None:
        candidates.append({'tool': 'create_message_in_task', 'args': {'taskId': context['taskId'], 'message': html_output}})
    if context.get('projectId') is not None:
        candidates.append({'tool': 'create_message_in_project', 'args': {'projectId': context['projectId'], 'message': html_output}})
    if context.get('chatId') is not None:
        candidates.append({'tool': 'create_message_in_chat', 'args': {'chatId': context['chatId'], 'message': html_output}})
    groupchat_id = context.get('groupChatId') if context.get('groupChatId') is not None else context.get('groupchatId')
    if groupchat_id is not None:
        candidates.append({'tool': 'create_message_in_groupchat', 'args': {'groupchatId': groupchat_id, 'message': html_output}})
    if context.get('channelId') is not None:
        candidates.append({'tool': 'create_message_in_channel', 'args': {'channelId': context['channelId'], 'message': html_output}})
    return candidates


def _run_runtime(payload_path: Path, *, profile: str, execute: bool, arla_session_key: str | None = None) -> dict[str, Any]:
    started = time.perf_counter()
    cmd = ['python3', str(RUNTIME_PATH), str(payload_path)]
    if arla_session_key:
        cmd.extend(['--arla-session-key', arla_session_key])
    data = _run_json_command(cmd)

    payload = json.loads(payload_path.read_text())
    event_type, context = _extract_event_and_context(payload)
    html_output = data.get('htmlOutput') if isinstance(data, dict) else ''
    if not isinstance(html_output, str):
        html_output = ''

    transports = _reply_transport_candidates(context, html_output) if html_output else []
    results: list[dict[str, Any]] = []
    applied_tool = None
    post_duration_ms = 0
    last_error = None
    if execute and transports:
        for transport in transports:
            try:
                post_result, post_duration_ms = _wrapper_call(profile=profile, tool=transport['tool'], args=transport['args'])
                results.append({'tool': transport['tool'], 'result': post_result})
                applied_tool = transport['tool']
                last_error = None
                break
            except DriverError as exc:
                last_error = str(exc)
        if applied_tool is None and last_error:
            raise DriverError(last_error)

    original_trigger_id = context.get('id') or context.get('Id') or context.get('replyId') or context.get('messageId')
    if execute:
        _status_done_async(profile=profile, event=event_type, event_id=original_trigger_id)

    invocation = data.get('arlaInvocation') if isinstance(data, dict) else {}
    total_duration_ms = int((time.perf_counter() - started) * 1000)
    return {
        'status': 'executed' if execute else 'planned',
        'event': event_type,
        'decision': 'no_reply' if not html_output else 'reply',
        'steps': [applied_tool] if applied_tool else ([transports[0]['tool']] if transports else []),
        'applied': len(results),
        'arlaSessionKey': invocation.get('sessionKey') if isinstance(invocation, dict) else None,
        'arlaSessionId': invocation.get('sessionId') if isinstance(invocation, dict) else None,
        'arlaDurationMs': invocation.get('durationMs') if isinstance(invocation, dict) else None,
        'runnerTiming': invocation.get('runnerTiming') if isinstance(invocation, dict) else None,
        'runnerTransport': invocation.get('runnerTransport') if isinstance(invocation, dict) else None,
        'postDurationMs': post_duration_ms,
        'totalDurationMs': total_duration_ms,
        'reply': _compact(html_output, 120) or 'none',
    }


def main() -> int:
    args = parse_args()
    payload_path = Path(args.payload)

    try:
        summary = _run_runtime(payload_path, profile=args.profile, execute=args.execute, arla_session_key=args.arla_session_key)
    except DriverError as exc:
        print(f'arla-fast error: {exc}')
        return 3

    print(
        ' | '.join(
            [
                f"arla-fast {summary['status']}",
                f"event={summary['event']}",
                f"decision={summary['decision']}",
                f"steps={','.join(summary['steps']) if summary['steps'] else 'none'}",
                f"applied={summary['applied']}",
                f"arlaSessionKey={summary['arlaSessionKey']}",
                f"arlaSessionId={summary['arlaSessionId']}",
                f"arlaDurationMs={summary.get('arlaDurationMs')}",
                f"runnerAgentCommandMs={(summary.get('runnerTiming') or {}).get('agentCommandDurationMs') if isinstance(summary.get('runnerTiming'), dict) else None}",
                f"runnerTotalMs={(summary.get('runnerTiming') or {}).get('totalDurationMs') if isinstance(summary.get('runnerTiming'), dict) else None}",
                f"runnerTransportMode={(summary.get('runnerTransport') or {}).get('mode') if isinstance(summary.get('runnerTransport'), dict) else None}",
                f"postDurationMs={summary.get('postDurationMs')}",
                f"totalDurationMs={summary.get('totalDurationMs')}",
                f"reply={summary['reply']}",
            ]
        )
    )
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
