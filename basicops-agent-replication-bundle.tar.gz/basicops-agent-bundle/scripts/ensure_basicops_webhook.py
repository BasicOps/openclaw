#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

PYTHON_BIN = sys.executable or "python3"
EXPECTED_KIND = "openclaw"
# Server-filtered event set currently returned by BasicOps connect_agent(kind="openclaw").
EXPECTED_EVENTS = [
    "basicops.task.message.created",
    "basicops.task.reply.created",
    "basicops.project.message.created",
    "basicops.project.reply.created",
    "basicops.chat.message.created",
    "basicops.chat.reply.created",
    "basicops.groupchat.message.created",
    "basicops.groupchat.reply.created",
    "basicops.channel.message.created",
    "basicops.channel.reply.created",
    "basicops.agent_instructions.updated",
]
EXPECTED_EVENT_SET = set(EXPECTED_EVENTS)


def call_wrapper(wrapper_path: str, profile: str, tool: str, args: dict[str, Any]) -> Any:
    proc = subprocess.run(
        [
            PYTHON_BIN,
            wrapper_path,
            "--as",
            profile,
            "call",
            "--tool",
            tool,
            "--args",
            json.dumps(args),
        ],
        text=True,
        capture_output=True,
        check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"{tool} failed rc={proc.returncode} stdout={proc.stdout!r} stderr={proc.stderr!r}"
        )
    stdout = (proc.stdout or "").strip()
    if not stdout:
        raise RuntimeError(f"{tool} returned empty stdout")
    parsed = json.loads(stdout)
    if isinstance(parsed, dict) and "data" in parsed:
        return parsed["data"]
    return parsed


def normalize_name(value: str | None) -> str:
    if not value:
        return ""
    return re.sub(r"[^a-z0-9]", "", value.lower())


def looks_similar(agent_id: str, first_name: str | None) -> bool:
    a = normalize_name(agent_id)
    b = normalize_name(first_name)
    if not a or not b:
        return False
    return a == b or a in b or b in a


def normalize_events(value: Any) -> set[str]:
    if isinstance(value, str):
        return {item.strip() for item in value.split(",") if item.strip()}
    if isinstance(value, list):
        return {str(item).strip() for item in value if str(item).strip()}
    return set()


def parsed_path(url: str) -> str:
    try:
        return urlparse(url).path or ""
    except Exception:
        return ""


def summarize_webhook(item: dict[str, Any]) -> dict[str, Any]:
    return {
        "webhookId": item.get("webhookId") or item.get("id"),
        "userId": item.get("UserId") or item.get("userId"),
        "url": item.get("url"),
        "path": parsed_path(str(item.get("url") or "")),
        "events": sorted(normalize_events(item.get("events"))),
    }


def exact_webhooks_for_current_user(
    webhooks: list[dict[str, Any]],
    public_webhook_url: str,
    current_user_id: Any,
) -> list[dict[str, Any]]:
    return [
        item
        for item in webhooks
        if str(item.get("url") or "") == public_webhook_url
        and (item.get("UserId") or item.get("userId")) == current_user_id
        and normalize_events(item.get("events")) == EXPECTED_EVENT_SET
    ]


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Verify or register a BasicOps agent connection using the configured MCP profile"
    )
    default_wrapper = str((Path(__file__).resolve().parent / "basicops_mcp.py").resolve())
    parser.add_argument("--profile", required=True, help="BasicOps persona/profile name")
    parser.add_argument("--agent-id", required=True, help="Intended OpenClaw agent id")
    parser.add_argument("--public-webhook-url", required=True)
    parser.add_argument("--wrapper-path", default=default_wrapper)
    parser.add_argument("--create-if-missing", action="store_true")
    parser.add_argument("--ignore-name-warning", action="store_true")
    parser.add_argument("--kind", default=EXPECTED_KIND)
    parser.add_argument("--signing", choices=["none", "generate", "provided"], default="none")
    parser.add_argument("--secret")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    current_user = call_wrapper(args.wrapper_path, args.profile, "get_current_user", {})
    if not isinstance(current_user, dict):
        raise RuntimeError(f"get_current_user returned unexpected payload: {current_user!r}")

    current_user_id = current_user.get("id")
    first_name = current_user.get("firstName")
    name_warning = bool(first_name) and not looks_similar(args.agent_id, first_name)

    webhooks = call_wrapper(args.wrapper_path, args.profile, "list_webhooks", {})
    if not isinstance(webhooks, list):
        raise RuntimeError(f"list_webhooks returned unexpected payload: {webhooks!r}")

    same_url = [item for item in webhooks if str(item.get("url") or "") == args.public_webhook_url]
    exact_current = [
        item
        for item in same_url
        if (item.get("UserId") or item.get("userId")) == current_user_id
        and normalize_events(item.get("events")) == EXPECTED_EVENT_SET
    ]
    exact_other_user = [
        item
        for item in same_url
        if (item.get("UserId") or item.get("userId")) != current_user_id
        and normalize_events(item.get("events")) == EXPECTED_EVENT_SET
    ]
    same_url_current_user_mismatch = [
        item
        for item in same_url
        if (item.get("UserId") or item.get("userId")) == current_user_id
        and normalize_events(item.get("events")) != EXPECTED_EVENT_SET
    ]
    same_url_other_user = [
        item
        for item in same_url
        if (item.get("UserId") or item.get("userId")) != current_user_id
    ]

    result: dict[str, Any] = {
        "status": "check",
        "profile": args.profile,
        "agentId": args.agent_id,
        "publicWebhookUrl": args.public_webhook_url,
        "expectedPath": parsed_path(args.public_webhook_url),
        "expectedKind": args.kind,
        "expectedEvents": EXPECTED_EVENTS,
        "currentUser": {
            "id": current_user_id,
            "firstName": first_name,
            "lastName": current_user.get("lastName"),
        },
        "identityWarning": name_warning,
        "identityWarningMessage": None,
        "existingExactWebhookIds": [item.get("webhookId") or item.get("id") for item in exact_current],
        "sameUrlConflicts": [summarize_webhook(item) for item in same_url if item not in exact_current],
        "connected": False,
    }

    if name_warning:
        result["identityWarningMessage"] = (
            f"Possible identity problem: setting up agent '{args.agent_id}', but the BasicOps user firstName is '{first_name}'."
        )
        if not args.ignore_name_warning:
            result["status"] = "identity_warning"
            if args.json:
                print(json.dumps(result, indent=2))
            else:
                print(result["identityWarningMessage"])
                print("Nothing was changed. Review the persona/API key, or rerun with --ignore-name-warning if this mismatch is intentional.")
            return 2

    if exact_other_user:
        result["status"] = "conflict_other_user"
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print("Conflict: an exact agent connection already exists for this URL and event set, but under a different BasicOps user.")
            print(json.dumps([summarize_webhook(item) for item in exact_other_user], indent=2))
            print(f"Current user id from get_current_user: {current_user_id}")
        return 3

    if same_url_current_user_mismatch and not args.create_if_missing:
        result["status"] = "conflict_same_url"
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print("Review required: a webhook already exists for this exact URL under the current BasicOps user, but it does not match the expected connect_agent event set.")
            print(json.dumps([summarize_webhook(item) for item in same_url_current_user_mismatch], indent=2))
            print("Rerun with --create-if-missing to register/update this agent through connect_agent.")
        return 4

    if same_url_other_user:
        result["status"] = "conflict_same_url_other_user"
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print("Review required: at least one webhook already points at this exact URL under a different BasicOps user.")
            print(json.dumps([summarize_webhook(item) for item in same_url_other_user], indent=2))
            print(f"Current user id from get_current_user: {current_user_id}")
        return 5

    if exact_current:
        result["status"] = "ok_existing"
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            if name_warning:
                print(result["identityWarningMessage"])
            print("Agent connection already exists with the expected URL, connect_agent event set, and BasicOps user id.")
            print(json.dumps([summarize_webhook(item) for item in exact_current], indent=2))
        return 0

    if not args.create_if_missing:
        result["status"] = "missing"
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            if name_warning:
                print(result["identityWarningMessage"])
            print("No exact connect_agent registration was found for this URL and event set.")
            print("Rerun with --create-if-missing after the public webhook route has been verified. That flag now registers or refreshes the agent via connect_agent.")
        return 6

    connect_args: dict[str, Any] = {
        "webhook": args.public_webhook_url,
        "kind": args.kind,
        "signing": args.signing,
    }
    if args.secret:
        connect_args["secret"] = args.secret

    connected_payload = call_wrapper(args.wrapper_path, args.profile, "connect_agent", connect_args)
    result["connected"] = True
    result["connectResult"] = connected_payload

    webhooks_after = call_wrapper(args.wrapper_path, args.profile, "list_webhooks", {})
    if not isinstance(webhooks_after, list):
        raise RuntimeError(f"list_webhooks after connect_agent returned unexpected payload: {webhooks_after!r}")

    exact_current_after = exact_webhooks_for_current_user(
        webhooks_after,
        args.public_webhook_url,
        current_user_id,
    )
    result["existingExactWebhookIds"] = [item.get("webhookId") or item.get("id") for item in exact_current_after]

    if not exact_current_after:
        result["status"] = "connect_verification_failed"
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print("connect_agent returned successfully, but verification could not find the expected webhook afterwards.")
            print(json.dumps(result, indent=2))
        return 7

    result["status"] = "ok_connected"
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        if name_warning:
            print(result["identityWarningMessage"])
        print("Agent connection registered through connect_agent and verified successfully.")
        print(json.dumps([summarize_webhook(item) for item in exact_current_after], indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
