#!/usr/bin/env bash
set -euo pipefail

status=0
pass(){ printf '[PASS] %s\n' "$1"; }
fail(){ printf '[FAIL] %s\n' "$1"; status=1; }
warn(){ printf '[WARN] %s\n' "$1"; }

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
STATUS_OUT="$(mktemp)"
DIRECT_TEST_JSON="$(mktemp)"
MODEL_TEST_JSON="$(mktemp)"
PUBLIC_BODY="$(mktemp)"
cleanup() { rm -f "$STATUS_OUT" "$DIRECT_TEST_JSON" "$MODEL_TEST_JSON" "$PUBLIC_BODY"; }
trap cleanup EXIT

EXPECTED_AGENT="thor"
OPENCLAW_CONFIG="/home/hjhlarsen/.openclaw/openclaw.json"
LOCAL_HOOK_URL="http://127.0.0.1:18789/hooks/basicops-thor"
BOOTSTRAP_FILE="/home/hjhlarsen/.openclaw/agents/thor/BOOTSTRAP.md"
PUBLIC_WEBHOOK_URL="${PUBLIC_WEBHOOK_URL:-https://YOUR_HOST_NAME/webhooks/basicops-thor}"
export EXPECTED_AGENT OPENCLAW_CONFIG LOCAL_HOOK_URL BOOTSTRAP_FILE STATUS_OUT DIRECT_TEST_JSON PUBLIC_WEBHOOK_URL

echo 'TARGET AGENT: thor'
echo 'READ ONLY: /tmp/thor-bundle-test-packaged/NEXT-STEPS.md'
echo 'Running final readiness gate for thor...'

if "$SCRIPT_DIR/PRECHECK-AGENT-INSTALL.sh"; then
  pass "precheck script passes"
else
  fail "precheck script failed"
fi

if openclaw status --all >"$STATUS_OUT" 2>&1; then
  pass 'openclaw status --all completed'
else
  fail 'openclaw status --all failed'
fi

if /usr/bin/python3 - <<'PY'
import os, re, sys
from pathlib import Path
agent_id = os.environ['EXPECTED_AGENT']
text = Path(os.environ['STATUS_OUT']).read_text()
pattern = re.compile(rf"^│\s*{re.escape(agent_id)}\b.*│\s*(ABSENT|PRESENT)\s*│", re.M)
match = pattern.search(text)
if not match:
    print(f"[FAIL] agent row not found in openclaw status --all: {agent_id}")
    sys.exit(1)
state = match.group(1)
if state != 'ABSENT':
    print(f"[FAIL] openclaw status shows Bootstrap file {state} for {agent_id}")
    sys.exit(1)
print(f"[PASS] openclaw status shows Bootstrap file ABSENT for {agent_id}")
PY
then
  :
else
  status=1
fi

if [[ -f "$BOOTSTRAP_FILE" ]]; then
  fail "bootstrap file still present on disk: $BOOTSTRAP_FILE"
else
  pass "bootstrap file absent on disk: $BOOTSTRAP_FILE"
fi

if systemctl --user is-active --quiet basicops-preack@thor.service; then
  pass "pre-ack service is active: basicops-preack@thor.service"
else
  fail "pre-ack service is not active: basicops-preack@thor.service"
fi


if openclaw agent --agent "$EXPECTED_AGENT" --message "reply OK" --json --timeout 120 >"$DIRECT_TEST_JSON"; then
  if /usr/bin/python3 - <<'PY'
import json, os, sys
from pathlib import Path
data = json.loads(Path(os.environ['DIRECT_TEST_JSON']).read_text())
texts = []
def walk(node):
    if isinstance(node, dict):
        for key, value in node.items():
            if key in ('finalAssistantVisibleText', 'finalAssistantRawText') and isinstance(value, str):
                texts.append(value.strip())
            walk(value)
    elif isinstance(node, list):
        for item in node:
            walk(item)
walk(data)
reply = next((item for item in texts if item and item != 'NO_REPLY'), '')
if not reply:
    print('[FAIL] direct OpenClaw agent test did not produce a visible reply')
    sys.exit(1)
print(f"[PASS] direct OpenClaw agent test returned a visible reply: {reply[:120]}")
PY
  then
    :
  else
    status=1
  fi
else
  fail 'direct OpenClaw agent test command failed'
fi

HOOK_MODEL="$(/usr/bin/python3 - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ['OPENCLAW_CONFIG']).expanduser()
hook_path = "basicops-thor"
agent_id = os.environ['EXPECTED_AGENT']
if not path.is_file():
    print('')
    raise SystemExit(0)
data = json.loads(path.read_text())
mappings = data.get('hooks', {}).get('mappings', []) if isinstance(data, dict) else []
for item in mappings:
    if not isinstance(item, dict):
        continue
    match = item.get('match') if isinstance(item.get('match'), dict) else {}
    if match.get('path') == hook_path and item.get('agentId') == agent_id:
        value = item.get('model')
        print(value.strip() if isinstance(value, str) else '')
        raise SystemExit(0)
print('')
PY
)"
if [[ -n "$HOOK_MODEL" ]]; then
  if openclaw agent --agent "$EXPECTED_AGENT" --message "reply OK" --model "$HOOK_MODEL" --json --timeout 120 >"$MODEL_TEST_JSON"; then
    if MODEL_TEST_JSON="$MODEL_TEST_JSON" /usr/bin/python3 - <<'PY'
import json, os, sys
from pathlib import Path
data = json.loads(Path(os.environ['MODEL_TEST_JSON']).read_text())
texts = []
def walk(node):
    if isinstance(node, dict):
        for key, value in node.items():
            if key in ('finalAssistantVisibleText', 'finalAssistantRawText') and isinstance(value, str):
                texts.append(value.strip())
            walk(value)
    elif isinstance(node, list):
        for item in node:
            walk(item)
walk(data)
reply = next((item for item in texts if item and item != 'NO_REPLY'), '')
if not reply:
    print('[FAIL] explicit hook model override direct test did not produce a visible reply')
    sys.exit(1)
print(f"[PASS] explicit hook model override is authorized via direct test: {reply[:120]}")
PY
    then
      pass "hook model override direct test succeeded: $HOOK_MODEL"
    else
      status=1
    fi
  else
    fail "hook model override direct test failed: $HOOK_MODEL"
  fi
else
  pass 'no explicit hook model override configured'
fi

HOOK_TOKEN="$(/usr/bin/python3 - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ['OPENCLAW_CONFIG']).expanduser()
if not path.is_file():
    print('')
    raise SystemExit(0)
data = json.loads(path.read_text())
hooks = data.get('hooks') if isinstance(data.get('hooks'), dict) else {}
value = hooks.get('token') if isinstance(hooks.get('token'), str) else ''
print(value.strip())
PY
)"

if [[ -z "$HOOK_TOKEN" ]]; then
  fail 'hooks.token missing in OpenClaw config'
else
  local_code=$(curl -o "$PUBLIC_BODY" -sS -w '%{http_code}' "$LOCAL_HOOK_URL" -H "Authorization: Bearer $HOOK_TOKEN" -H 'Content-Type: application/json' --data-binary '{}' || true)
  if [[ "$local_code" == "200" ]]; then
    pass "local hook returns 200: $LOCAL_HOOK_URL"
  else
    fail "local hook failed at $LOCAL_HOOK_URL (HTTP $local_code)"
  fi
fi

if [[ "$PUBLIC_WEBHOOK_URL" == *YOUR_HOST_NAME* ]]; then
  fail 'PUBLIC_WEBHOOK_URL still uses the YOUR_HOST_NAME placeholder. Re-run with PUBLIC_WEBHOOK_URL set to the real public webhook URL.'
elif [[ -z "$HOOK_TOKEN" ]]; then
  fail 'public webhook check skipped because hooks.token is missing in OpenClaw config'
else
  public_code=$(curl -o "$PUBLIC_BODY" -sS -w '%{http_code}' "$PUBLIC_WEBHOOK_URL" -H "Authorization: Bearer $HOOK_TOKEN" -H 'Content-Type: application/json' --data-binary '{}' || true)
  if [[ "$public_code" == "200" ]]; then
    pass "public webhook returns 200: $PUBLIC_WEBHOOK_URL"
  else
    fail "public webhook failed at $PUBLIC_WEBHOOK_URL (HTTP $public_code)"
  fi
fi

echo
echo 'Expected evidence chain for the first real BasicOps test:'
echo '1. public webhook returns 200'
echo '2. pre-ack logs show the incoming event'
echo '3. OpenClaw hook responds successfully'
echo '4. the target agent session store updates'
echo '5. BasicOps shows the reply'
echo
echo 'Important: use a real BasicOps message for the first end-to-end replay.'
echo 'Synthetic payloads or fake IDs can prove session creation, but reply posting may still fail with "Message not found".'

if [[ $status -eq 0 ]]; then
  echo 'RESULT: PASS. The install looks ready for the first real BasicOps message.'
else
  echo 'RESULT: FAIL. Fix the failing layer above before testing in BasicOps.'
fi
exit $status
