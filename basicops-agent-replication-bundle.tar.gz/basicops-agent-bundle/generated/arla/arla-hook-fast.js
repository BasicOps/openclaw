import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';

const DRIVER_PATH = path.join(os.homedir(), 'basicops-agent-bundle', 'scripts', 'arla_fast_driver.py');
const LOG_PATH = path.join(os.tmpdir(), 'arla-hook.log');

export default async function transform(ctx) {
  const payload = ctx?.payload ?? null;
  const eventType = payload?.event ?? payload?.events?.[0]?.event ?? 'unknown-event';
  const context = payload?.context ?? payload?.events?.[0]?.data ?? {};
  const currentEntityId = context?.replyId ?? context?.id ?? context?.Id ?? context?.messageId ?? context?.taskId ?? context?.projectId ?? context?.chatId ?? context?.groupChatId ?? context?.groupchatId ?? context?.channelId ?? 'no-entity';
  const fileToken = `${eventType}-${currentEntityId}-${Date.now()}`.replace(/[^a-zA-Z0-9._-]+/g, '_');
  const payloadPath = path.join(os.tmpdir(), `arla-hook-${fileToken}.json`);
  fs.writeFileSync(payloadPath, JSON.stringify(payload, null, 2), 'utf8');

  const fd = fs.openSync(LOG_PATH, 'a');
  fs.writeSync(fd, `\n=== ${new Date().toISOString()} event=${eventType} entity=${currentEntityId} ===\n`);
  fs.writeSync(fd, `payload=${payloadPath}\n`);

  const child = spawn('python3', [DRIVER_PATH, payloadPath, '--execute'], {
    detached: true,
    stdio: ['ignore', fd, fd],
  });
  child.unref();
  fs.closeSync(fd);

  return null;
}
