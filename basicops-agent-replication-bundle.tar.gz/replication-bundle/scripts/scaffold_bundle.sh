#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PARENT_DIR="$(dirname "$ROOT")"
BUNDLE_NAME="$(basename "$ROOT")"
DEFAULT_TAR="$PARENT_DIR/basicops-agent-replication-bundle.tar.gz"
DEFAULT_ZIP="$PARENT_DIR/basicops-agent-replication-bundle.zip"
DO_VERIFY=1
DO_TAR=0
DO_ZIP=0
TAR_PATH="$DEFAULT_TAR"
ZIP_PATH="$DEFAULT_ZIP"

usage() {
  cat <<EOF
Usage:
  $(basename "$0") [--verify-only] [--tar [PATH]] [--zip [PATH]]

Examples:
  $(basename "$0") --verify-only
  $(basename "$0") --tar
  $(basename "$0") --tar /tmp/basicops-agent-replication-bundle.tar.gz
  $(basename "$0") --tar --zip

Behavior:
  - refuses to continue if the source bundle contains stale generated output
  - refuses to continue if Python bytecode caches are present
  - refuses to continue if secret-bearing files like basicops-personas.json,
    mcporter.json, or openclaw-gateway-hooks-token.conf appear in the shipped tree
  - when packaging, stages a clean copy that excludes generated/, __pycache__/, and *.pyc
  - verifies the final archive contents before reporting success
EOF
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --verify-only)
      DO_VERIFY=1
      ;;
    --tar)
      DO_TAR=1
      if [ "$#" -gt 1 ] && [[ "$2" != --* ]]; then
        TAR_PATH="$2"
        shift
      fi
      ;;
    --zip)
      DO_ZIP=1
      if [ "$#" -gt 1 ] && [[ "$2" != --* ]]; then
        ZIP_PATH="$2"
        shift
      fi
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown argument: $1" >&2
      echo >&2
      usage >&2
      exit 2
      ;;
  esac
  shift
done

fail_list() {
  local header="$1"
  shift
  echo "$header"
  printf '  %s\n' "$@"
  echo
  exit 1
}

check_source_tree_clean() {
  local generated_dir="$ROOT/generated"
  if [ -d "$generated_dir" ]; then
    mapfile -t generated_files < <(find "$generated_dir" -type f | sort)
    if [ "${#generated_files[@]}" -gt 0 ]; then
      fail_list \
        "Refusing to package bundle: stale generated output detected under $generated_dir" \
        "${generated_files[@]}"
    fi
  fi

  mapfile -t bytecode_files < <(find "$ROOT" \( -type d -name '__pycache__' -o -type f -name '*.pyc' \) | sort)
  if [ "${#bytecode_files[@]}" -gt 0 ]; then
    fail_list \
      "Refusing to package bundle: Python bytecode cache files detected in bundle tree" \
      "${bytecode_files[@]}"
  fi

  mapfile -t forbidden_files < <(find "$ROOT" -type f \(
    -name 'openclaw-gateway-hooks-token.conf' -o
    -name 'basicops-personas.json' -o
    -name 'mcporter.json' -o
    \( -name '*.basicops-personas.json' ! -name '*.example.json' \)
  \) | sort)
  if [ "${#forbidden_files[@]}" -gt 0 ]; then
    fail_list \
      "Refusing to package bundle: secret-bearing files detected in bundle tree" \
      "${forbidden_files[@]}"
  fi
}

stage_clean_bundle() {
  local stage_dir="$1"
  mkdir -p "$stage_dir"
  tar -C "$PARENT_DIR" -cf - \
    --exclude="$BUNDLE_NAME/generated" \
    --exclude='*/__pycache__' \
    --exclude='*.pyc' \
    --exclude='*.DS_Store' \
    "$BUNDLE_NAME" | tar -C "$stage_dir" -xf -
}

check_staged_tree_clean() {
  local staged_root="$1/$BUNDLE_NAME"
  if [ ! -d "$staged_root" ]; then
    echo "Staged bundle missing: $staged_root" >&2
    exit 1
  fi

  mapfile -t staged_generated < <(find "$staged_root/generated" -type f 2>/dev/null | sort || true)
  if [ "${#staged_generated[@]}" -gt 0 ]; then
    fail_list \
      "Refusing to package bundle: staged bundle still contains generated output" \
      "${staged_generated[@]}"
  fi

  mapfile -t staged_forbidden < <(find "$staged_root" -type f \(
    -name 'openclaw-gateway-hooks-token.conf' -o
    -name 'basicops-personas.json' -o
    -name 'mcporter.json' -o
    \( -name '*.basicops-personas.json' ! -name '*.example.json' \)
  \) | sort)
  if [ "${#staged_forbidden[@]}" -gt 0 ]; then
    fail_list \
      "Refusing to package bundle: staged bundle still contains secret-bearing files" \
      "${staged_forbidden[@]}"
  fi
}

verify_tarball() {
  local archive="$1"
  mapfile -t bad_entries < <(tar -tzf "$archive" | grep -E '(^|/)(generated/|__pycache__/|openclaw-gateway-hooks-token\.conf$|basicops-personas\.json$|mcporter\.json$|[^/]+\.basicops-personas\.json$|[^/]+\.pyc$)' || true)
  if [ "${#bad_entries[@]}" -gt 0 ]; then
    fail_list \
      "Refusing to accept tarball: forbidden entries detected in $archive" \
      "${bad_entries[@]}"
  fi
}

verify_zipfile() {
  local archive="$1"
  mapfile -t bad_entries < <(zipinfo -1 "$archive" | grep -E '(^|/)(generated/|__pycache__/|openclaw-gateway-hooks-token\.conf$|basicops-personas\.json$|mcporter\.json$|[^/]+\.basicops-personas\.json$|[^/]+\.pyc$)' || true)
  if [ "${#bad_entries[@]}" -gt 0 ]; then
    fail_list \
      "Refusing to accept zip: forbidden entries detected in $archive" \
      "${bad_entries[@]}"
  fi
}

check_source_tree_clean

echo "Bundle root: $ROOT"
echo ""
echo "Source tree passed clean-bundle checks."

if [ "$DO_TAR" -eq 0 ] && [ "$DO_ZIP" -eq 0 ]; then
  echo
  echo "Verification only. To package safely, use one of:" 
  echo "  $(basename "$0") --tar"
  echo "  $(basename "$0") --zip"
  echo "  $(basename "$0") --tar --zip"
  exit 0
fi

STAGE_DIR="$(mktemp -d)"
cleanup() {
  rm -rf "$STAGE_DIR"
}
trap cleanup EXIT

stage_clean_bundle "$STAGE_DIR"
check_staged_tree_clean "$STAGE_DIR"

if [ "$DO_TAR" -eq 1 ]; then
  mkdir -p "$(dirname "$TAR_PATH")"
  tar -C "$STAGE_DIR" -czf "$TAR_PATH" "$BUNDLE_NAME"
  verify_tarball "$TAR_PATH"
  echo "Created clean tarball: $TAR_PATH"
fi

if [ "$DO_ZIP" -eq 1 ]; then
  if ! command -v zip >/dev/null 2>&1; then
    echo "zip is not installed, cannot create $ZIP_PATH" >&2
    exit 1
  fi
  if ! command -v zipinfo >/dev/null 2>&1; then
    echo "zipinfo is not installed, cannot verify $ZIP_PATH" >&2
    exit 1
  fi
  mkdir -p "$(dirname "$ZIP_PATH")"
  (
    cd "$STAGE_DIR"
    zip -qr "$ZIP_PATH" "$BUNDLE_NAME"
  )
  verify_zipfile "$ZIP_PATH"
  echo "Created clean zip: $ZIP_PATH"
fi
