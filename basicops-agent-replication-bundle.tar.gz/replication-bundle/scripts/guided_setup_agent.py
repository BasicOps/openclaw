#!/usr/bin/env python3
from __future__ import annotations

import argparse
import difflib
import json
import os
import platform
import secrets
import socket
import subprocess
from pathlib import Path
import sys
import urllib.error
import urllib.request

from agent_naming import default_display_name, validate_agent_id


def prompt(label: str, default: str | None = None) -> str:
    suffix = f" [{default}]" if default else ""
    value = input(f"{label}{suffix}: ").strip()
    return value or (default or "")


def redact_cmd(cmd: list[str]) -> str:
    redacted: list[str] = []
    redact_next = False
    for part in cmd:
        if redact_next:
            redacted.append("***REDACTED***")
            redact_next = False
            continue
        if part == "--hooks-token":
            redacted.append(part)
            redact_next = True
            continue
        redacted.append(part)
    return " ".join(redacted)


def run(cmd: list[str], dry_run: bool, allow_failure: bool = False) -> int:
    print("$", redact_cmd(cmd))
    if dry_run:
        return 0
    result = subprocess.run(cmd)
    if result.returncode != 0 and not allow_failure:
        raise SystemExit(result.returncode)
    return result.returncode


def validate_hook_ingress_locally(port: int, hook_path: str, hooks_token: str) -> tuple[bool, str]:
    url = f"http://127.0.0.1:{port}/hooks/{hook_path}"
    smoke_payload = json.dumps({"openclawInstallSmokeTest": True, "source": "guided-setup"}).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=smoke_payload,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {hooks_token}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return True, f"Local hook smoke test reached {url} and returned HTTP {resp.status}"
    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            return False, f"Local hook smoke test reached {url} but returned HTTP 401. The hooks token does not match the gateway runtime token."
        if exc.code == 404:
            return False, f"Local hook smoke test reached {url} but returned HTTP 404. The hook path is not active, hooks are disabled, or the mapping was not loaded."
        return True, f"Local hook smoke test reached {url} and returned HTTP {exc.code}. The route is live, but the synthetic smoke payload was rejected by application logic."
    except Exception as exc:
        return False, f"Local hook smoke test failed for {url}: {exc}"


def is_local_port_available(port: int) -> bool:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        sock.bind(("127.0.0.1", port))
    except OSError:
        return False
    finally:
        sock.close()
    return True



def find_available_port(start_port: int, end_port: int = 18950) -> int | None:
    for port in range(start_port, end_port + 1):
        if is_local_port_available(port):
            return port
    return None


def read_shim_port_from_env(path: Path) -> str | None:
    if not path.is_file():
        return None
    for line in path.read_text().splitlines():
        if line.startswith("SHIM_PORT="):
            return line.split("=", 1)[1].strip()
    return None


def load_self_context_from_cache(cache_path: str) -> dict | None:
    path = Path(cache_path).expanduser()
    if not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text())
    except Exception:
        return None
    self_context = payload.get("selfContext") if isinstance(payload, dict) else None
    return self_context if isinstance(self_context, dict) else None


def show_basicops_identity_confirmation(
    *,
    cache_path: str,
    agent_id: str,
    display_name: str,
    basicops_profile: str,
    require_confirmation: bool,
) -> None:
    self_context = load_self_context_from_cache(cache_path)
    if not self_context:
        print("Warning: could not read self-context cache to confirm the BasicOps identity.", flush=True)
        return

    print(flush=True)
    print("Resolved BasicOps identity from the configured API key:", flush=True)
    print(f"- profile: {basicops_profile}", flush=True)
    print(f"- intended OpenClaw agent: {agent_id}", flush=True)
    print(f"- intended display name: {display_name}", flush=True)
    print(f"- BasicOps userId: {self_context.get('userId')}", flush=True)
    print(f"- BasicOps displayName: {self_context.get('displayName')}", flush=True)
    print(f"- BasicOps email: {self_context.get('email')}", flush=True)
    print(flush=True)
    print(
        "Hard stop check: if this resolves to a previous agent user or the wrong person, do not continue. Fix the API key in basicops-personas.json first, then refresh self-context again.",
        flush=True,
    )

    if not require_confirmation:
        return

    confirm = prompt("Does this BasicOps identity match the intended agent user?", "no").lower()
    if confirm not in {"y", "yes"}:
        raise SystemExit("aborting: BasicOps identity was not confirmed")


def discover_openclaw_gateway_port(config_path: str) -> tuple[str | None, str | None]:
    path = Path(config_path).expanduser()
    if not path.is_file():
        return None, None
    try:
        data = json.loads(path.read_text())
    except Exception:
        return None, None
    gateway = data.get("gateway") if isinstance(data, dict) else None
    if not isinstance(gateway, dict):
        return None, None
    port = gateway.get("port")
    if isinstance(port, int) and port > 0:
        return str(port), f"{path} gateway.port"
    if isinstance(port, str) and port.strip().isdigit():
        return port.strip(), f"{path} gateway.port"
    return None, None



def discover_hooks_token_from_dropins(target_home: str) -> tuple[str | None, str | None, str | None]:
    dropin_dir = Path(target_home).expanduser() / ".config/systemd/user/openclaw-gateway.service.d"
    if not dropin_dir.is_dir():
        return None, None, None

    sources: list[tuple[str, str]] = []
    for path in sorted(dropin_dir.glob("*.conf")):
        try:
            for raw_line in path.read_text().splitlines():
                line = raw_line.strip()
                if "OPENCLAW_HOOKS_TOKEN=" not in line:
                    continue
                token = line.split("OPENCLAW_HOOKS_TOKEN=", 1)[1].strip().strip('"')
                if token and token != "REPLACE_ME":
                    sources.append((path.name, token))
        except Exception as exc:
            return None, None, f"failed reading {path}: {exc}"

    if not sources:
        return None, None, None

    distinct_tokens = {token for _, token in sources}
    source_files = ", ".join(name for name, _ in sources)
    if len(distinct_tokens) > 1:
        return None, None, f"conflicting OPENCLAW_HOOKS_TOKEN values found across: {source_files}"
    return sources[0][1], f"gateway systemd drop-in ({source_files})", None


def discover_hooks_token(openclaw_config_path: str, target_home: str) -> tuple[str | None, str | None, str | None]:
    path = Path(openclaw_config_path).expanduser()
    if path.is_file():
        try:
            data = json.loads(path.read_text())
        except Exception as exc:
            return None, None, f"failed reading {path}: {exc}"

        candidates = [
            (data.get("hooks", {}).get("token") if isinstance(data.get("hooks"), dict) else None, f"{path} hooks.token"),
            (data.get("server", {}).get("hooksToken") if isinstance(data.get("server"), dict) else None, f"{path} server.hooksToken"),
        ]

        for value, source in candidates:
            if isinstance(value, str) and value.strip() and value.strip() != "REPLACE_ME":
                return value.strip(), source, None

    token, source, warning = discover_hooks_token_from_dropins(target_home)
    if token:
        return token, source, warning
    if warning:
        return None, None, warning

    env_token = os.environ.get("OPENCLAW_HOOKS_TOKEN", "").strip()
    if env_token and env_token != "REPLACE_ME":
        return env_token, "current shell environment OPENCLAW_HOOKS_TOKEN", None

    return None, None, None


def generate_hooks_token() -> str:
    return secrets.token_hex(32)


def detect_default_target_home() -> str:
    env_home = os.environ.get("HOME", "").strip()
    if env_home:
        return env_home.rstrip("/") or "/"
    return str(Path.home())


def detect_platform_name() -> str:
    return platform.system() or "Unknown"


def resolve_service_manager(requested: str, platform_name: str) -> str:
    if requested != "auto":
        return requested
    if platform_name == "Darwin":
        return "launchd"
    return "systemd"


def main() -> int:
    script_dir = Path(__file__).resolve().parent
    default_bundle_root = script_dir.parent
    default_output_root = default_bundle_root / "generated"

    parser = argparse.ArgumentParser(description="Guided BasicOps agent setup helper")
    parser.add_argument("--bundle-root", default=str(default_bundle_root))
    parser.add_argument("--output-root", default=str(default_output_root))
    parser.add_argument("--agent-id")
    parser.add_argument("--display-name")
    parser.add_argument("--basicops-profile")
    parser.add_argument("--hook-path")
    parser.add_argument("--shim-port")
    parser.add_argument("--openclaw-hook-port")
    parser.add_argument("--target-home", help="Target home directory. Defaults to the current user's home.")
    parser.add_argument("--runtime", default="codex")
    parser.add_argument("--service-manager", choices=["auto", "systemd", "launchd"], default="auto")
    parser.add_argument("--path-with-mcporter")
    parser.add_argument("--wrapper-path")
    parser.add_argument("--self-context-cache-path")
    parser.add_argument("--preack-webhook-path")
    parser.add_argument("--preack-workdir")
    parser.add_argument("--openclaw-config-path")
    parser.add_argument("--hooks-token", default="REPLACE_ME")
    parser.add_argument("--generate-hooks-token-if-missing", action="store_true", help="Generate a new hooks token when none can be discovered")
    parser.add_argument("--register-agent", action="store_true", help="Also add the generated agent to agents.list in the target OpenClaw config")
    parser.add_argument("--no-agent-config-backup", action="store_true", help="Do not create a backup before modifying the OpenClaw config")
    parser.add_argument("--apply-and-validate-hook", action="store_true", help="After scaffolding, refresh self-context, apply the hook mapping, restart the gateway, and run a local hook smoke test")
    parser.add_argument("--skip-preflight", action="store_true")
    parser.add_argument("--non-interactive", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    print("Guided BasicOps agent setup", flush=True)
    print("This helper runs preflight first, then scaffolds the agent files.", flush=True)
    print("It can also add the new agent to agents.list if you choose.", flush=True)
    print(flush=True)

    agent_id = validate_agent_id(args.agent_id or prompt("Agent ID", "helper"))
    default_display = default_display_name(agent_id)
    display_name = args.display_name or (default_display if args.non_interactive else prompt("Display name", default_display))
    basicops_profile = args.basicops_profile or (agent_id if args.non_interactive else prompt("BasicOps profile", agent_id))
    hook_path = args.hook_path or (f"basicops-{agent_id}" if args.non_interactive else prompt("Hook path", f"basicops-{agent_id}"))
    requested_shim_port = args.shim_port or ("18891" if args.non_interactive else prompt("Shim port", "18891"))
    default_target_home = detect_default_target_home()
    target_home = args.target_home or (default_target_home if args.non_interactive else prompt("Target home path", default_target_home))
    platform_name = detect_platform_name()
    service_manager = resolve_service_manager(args.service_manager, platform_name)
    runtime = args.runtime or ("codex" if args.non_interactive else prompt("Desired runtime", "codex"))
    bundle_root = Path(args.bundle_root).expanduser()
    default_wrapper_path = str((bundle_root / "scripts" / "basicops_mcp.py").resolve())
    default_self_context_cache = f"{target_home}/.cache/basicops-agents/{agent_id}-self.json"
    default_preack_webhook_path = str((bundle_root / "scripts" / "preack_webhook.py").resolve())
    default_preack_workdir = str(bundle_root.resolve())
    default_openclaw_config_path = f"{target_home}/.openclaw/openclaw.json"
    default_path_with_mcporter = f"{target_home}/.npm-global/bin:{target_home}/.local/bin:/usr/local/bin:/usr/bin:/bin"
    review_advanced_paths = False
    if not args.non_interactive:
        review_advanced_paths = prompt("Review advanced path settings", "no").lower() in {"y", "yes"}
    wrapper_path = args.wrapper_path or (default_wrapper_path if args.non_interactive or not review_advanced_paths else prompt("BasicOps MCP wrapper path", default_wrapper_path))
    self_context_cache_path = args.self_context_cache_path or (default_self_context_cache if args.non_interactive or not review_advanced_paths else prompt("Self-context cache path", default_self_context_cache))
    preack_webhook_path = args.preack_webhook_path or (default_preack_webhook_path if args.non_interactive or not review_advanced_paths else prompt("Pre-ack webhook path", default_preack_webhook_path))
    preack_workdir = args.preack_workdir or (default_preack_workdir if args.non_interactive or not review_advanced_paths else prompt("Pre-ack workdir", default_preack_workdir))
    openclaw_config_path = args.openclaw_config_path or (default_openclaw_config_path if args.non_interactive or not review_advanced_paths else prompt("OpenClaw config path", default_openclaw_config_path))
    path_with_mcporter = args.path_with_mcporter or (default_path_with_mcporter if args.non_interactive or not review_advanced_paths else prompt("PATH including mcporter", default_path_with_mcporter))
    detected_openclaw_hook_port, detected_openclaw_hook_port_source = discover_openclaw_gateway_port(openclaw_config_path)
    if args.openclaw_hook_port:
        openclaw_hook_port = args.openclaw_hook_port
        openclaw_hook_port_source = "--openclaw-hook-port"
    elif detected_openclaw_hook_port:
        openclaw_hook_port = detected_openclaw_hook_port
        openclaw_hook_port_source = detected_openclaw_hook_port_source
    else:
        openclaw_hook_port = "18789"
        openclaw_hook_port_source = "bundle fallback default"
    hooks_token_source = None
    hooks_token_discovery_warning = None
    generated_hooks_token = False
    if args.hooks_token != "REPLACE_ME":
        hooks_token = args.hooks_token
        hooks_token_source = "--hooks-token"
    else:
        discovered_hooks_token, discovered_hooks_token_source, hooks_token_discovery_warning = discover_hooks_token(openclaw_config_path, target_home)
        if discovered_hooks_token:
            hooks_token = discovered_hooks_token
            hooks_token_source = discovered_hooks_token_source
            if not args.non_interactive:
                print(flush=True)
                print(f"Using discovered OpenClaw hooks token from {hooks_token_source}.", flush=True)
        else:
            should_generate_hooks_token = args.generate_hooks_token_if_missing
            print(flush=True)
            print("Could not automatically discover a real OpenClaw hooks token.", flush=True)
            print(f"Checked OpenClaw config: {openclaw_config_path}", flush=True)
            if service_manager == "systemd":
                print(f"Also looked for OPENCLAW_HOOKS_TOKEN in {Path(target_home).expanduser() / '.config/systemd/user/openclaw-gateway.service.d'}", flush=True)
            if hooks_token_discovery_warning:
                print(f"Note: {hooks_token_discovery_warning}", flush=True)
            if not args.non_interactive:
                print("No existing token was found, so the easiest safe option is to generate one now.", flush=True)
                if service_manager == "systemd":
                    generate_prompt = "Generate one now and scaffold a matching gateway drop-in"
                else:
                    generate_prompt = "Generate one now and use it in the generated hook-apply flow"
                generate_choice = prompt(generate_prompt, "yes").lower()
                should_generate_hooks_token = generate_choice in {"y", "yes"}
            if should_generate_hooks_token:
                hooks_token = generate_hooks_token()
                hooks_token_source = "newly generated for this setup"
                generated_hooks_token = True
                print("Generated a new OpenClaw hooks token for this setup.", flush=True)
                if service_manager == "systemd":
                    print("The scaffolded output will include a gateway drop-in file so the gateway can use the same token.", flush=True)
                else:
                    print("The scaffolded output will carry that token through the generated hook-apply flow so OpenClaw can store it in config.", flush=True)
            else:
                hooks_token = "REPLACE_ME"
                print("Scaffolding can still continue, but the generated env file will keep REPLACE_ME until you update it.", flush=True)

    output_root = Path(args.output_root).expanduser()
    output_dir = output_root / agent_id
    installed_env_path = Path(f"{target_home}/.config/basicops-agents/{agent_id}.env").expanduser()
    installed_gateway_dropin_path = Path(f"{target_home}/.config/systemd/user/openclaw-gateway.service.d/70-basicops-hooks-token.conf").expanduser()
    scaffold_script = bundle_root / "scripts" / "scaffold_agent_from_bundle.py"
    preflight_script = bundle_root / "scripts" / "preflight_replication_bundle.py"

    if not scaffold_script.is_file():
        raise SystemExit(f"Scaffold script not found: {scaffold_script}")
    if not preflight_script.is_file():
        raise SystemExit(f"Preflight script not found: {preflight_script}")

    try:
        requested_shim_port_int = int(requested_shim_port)
    except ValueError:
        print(f"Invalid shim port: {requested_shim_port}", flush=True)
        return 1

    shim_port_int = requested_shim_port_int
    shim_port_note = ""
    if not is_local_port_available(requested_shim_port_int):
        suggested_port = find_available_port(max(1024, requested_shim_port_int + 1))
        print(flush=True)
        print(f"Requested shim port {requested_shim_port_int} is already in use on 127.0.0.1.", flush=True)
        if suggested_port is not None:
            if args.non_interactive:
                shim_port_int = suggested_port
                shim_port_note = f"auto-selected available shim port {suggested_port}"
            else:
                choice = prompt("Shim port is busy. Use suggested available port", str(suggested_port))
                try:
                    shim_port_int = int(choice)
                except ValueError:
                    print(f"Invalid shim port: {choice}", flush=True)
                    return 1
                if shim_port_int == suggested_port:
                    shim_port_note = f"using suggested available shim port {suggested_port}"
        else:
            print("Could not automatically find an available replacement shim port in the scanned range.", flush=True)
            if args.non_interactive:
                return 1
            choice = prompt("Enter a different shim port")
            try:
                shim_port_int = int(choice)
            except ValueError:
                print(f"Invalid shim port: {choice}", flush=True)
                return 1

    shim_port = str(shim_port_int)

    existing_installed_shim_port = read_shim_port_from_env(installed_env_path)

    print(flush=True)
    print("Summary", flush=True)
    print(f"- agent id: {agent_id}", flush=True)
    print(f"- display name: {display_name}", flush=True)
    print(f"- BasicOps profile: {basicops_profile}", flush=True)
    print(f"- hook path: {hook_path}", flush=True)
    print(f"- shim port: {shim_port}" + (f" ({shim_port_note})" if shim_port_note else ""), flush=True)
    print(f"- OpenClaw hook port: {openclaw_hook_port} ({openclaw_hook_port_source})", flush=True)
    print(f"- target home: {target_home}", flush=True)
    print(f"- platform: {platform_name}", flush=True)
    print(f"- service manager: {service_manager}", flush=True)
    print(f"- desired runtime: {runtime}", flush=True)
    if generated_hooks_token:
        print("- hooks token: newly generated for this setup", flush=True)
    elif hooks_token == "REPLACE_ME":
        print("- hooks token: not auto-discovered, generated files will keep REPLACE_ME until you update them", flush=True)
    else:
        print(f"- hooks token: auto-discovered from {hooks_token_source}", flush=True)
    print(f"- generated output dir: {output_dir}", flush=True)
    if existing_installed_shim_port is not None:
        print(f"- currently installed SHIM_PORT: {existing_installed_shim_port} in {installed_env_path}", flush=True)
        if existing_installed_shim_port != shim_port:
            print(f"- note: generated files will use SHIM_PORT={shim_port}, but the installed env still uses SHIM_PORT={existing_installed_shim_port} until you copy the new file into place", flush=True)
    print(flush=True)

    register_agent = args.register_agent
    if not args.non_interactive:
        register_choice = prompt("Also add this agent to agents.list now?", "yes").lower()
        register_agent = register_choice in {"y", "yes"}
    if register_agent:
        print(f"- agent registration: will update {openclaw_config_path}", flush=True)
        if not args.no_agent_config_backup:
            print("- config backup: a timestamped backup will be created first", flush=True)
        if agent_id != "main":
            print("- control-panel safety: if this is the first explicit non-main agent, the bundle will also seed a default 'main' agent", flush=True)
    else:
        print("- agent registration: skipped, NEXT-STEPS.md will show the manual step", flush=True)
    print(flush=True)

    confirm = "yes" if args.non_interactive else prompt("Proceed with preflight + scaffolding?", "yes").lower()
    if confirm not in {"y", "yes"}:
        print("Aborted.")
        return 0

    if not args.skip_preflight:
        print(flush=True)
        print("Running preflight checks...", flush=True)
        preflight_cmd = [
            sys.executable,
            str(preflight_script),
            "--target-home", target_home,
            "--runtime", runtime,
            "--wrapper-path", wrapper_path,
            "--preack-webhook-path", preack_webhook_path,
            "--openclaw-config-path", openclaw_config_path,
            "--self-context-dir", str(Path(self_context_cache_path).parent),
            "--hooks-token", hooks_token,
            "--shim-port", shim_port,
            "--service-manager", service_manager,
        ]
        preflight_rc = run(preflight_cmd, args.dry_run, allow_failure=True)
        if preflight_rc != 0 and not args.dry_run:
            print(flush=True)
            print("Preflight failed. Fix the reported issues or rerun with --skip-preflight if you intentionally want to scaffold anyway.", flush=True)
            return preflight_rc

    cmd = [
        sys.executable,
        str(scaffold_script),
        "--bundle-root", str(bundle_root),
        "--output-dir", str(output_dir),
        "--agent-id", agent_id,
        "--display-name", display_name,
        "--basicops-profile", basicops_profile,
        "--hook-path", hook_path,
        "--shim-port", shim_port,
        "--openclaw-hook-port", openclaw_hook_port,
        "--target-home", target_home,
        "--path-with-mcporter", path_with_mcporter,
        "--wrapper-path", wrapper_path,
        "--self-context-cache-path", self_context_cache_path,
        "--preack-webhook-path", preack_webhook_path,
        "--preack-workdir", preack_workdir,
        "--openclaw-config-path", openclaw_config_path,
        "--hooks-token", hooks_token,
        "--service-manager", service_manager,
    ]
    if generated_hooks_token:
        cmd.append("--hooks-token-generated")
    if register_agent:
        cmd.append("--register-agent")
        if args.no_agent_config_backup:
            cmd.append("--no-agent-config-backup")

    print(flush=True)
    print("Scaffolding agent bundle files...", flush=True)
    run(cmd, args.dry_run)

    next_steps = output_dir / "NEXT-STEPS.md"
    print(flush=True)
    print("Done.", flush=True)
    print(f"Review: {next_steps}", flush=True)
    generated_env_path = output_dir / f"{agent_id}.env"
    generated_gateway_dropin_path = output_dir / "openclaw-gateway-hooks-token.conf"
    print(f"Generated env file: {generated_env_path}", flush=True)
    if generated_hooks_token and service_manager == "systemd":
        print(f"Generated gateway hooks-token drop-in: {generated_gateway_dropin_path}", flush=True)
    if installed_env_path.is_file():
        generated_shim_port = read_shim_port_from_env(generated_env_path)
        installed_shim_port = read_shim_port_from_env(installed_env_path)
        if generated_shim_port is not None and installed_shim_port is not None and generated_shim_port != installed_shim_port:
            print(flush=True)
            print("Important: your installed env file still differs from the newly generated one.", flush=True)
            print(f"- generated SHIM_PORT: {generated_shim_port}", flush=True)
            print(f"- installed SHIM_PORT: {installed_shim_port}", flush=True)
            print("Copy the newly generated env file into ~/.config/basicops-agents before restarting the service.", flush=True)
            print(f"Example: cp {generated_env_path} {installed_env_path}", flush=True)
            generated_lines = generated_env_path.read_text().splitlines()
            installed_lines = installed_env_path.read_text().splitlines()
            diff = "\n".join(difflib.unified_diff(installed_lines, generated_lines, fromfile=str(installed_env_path), tofile=str(generated_env_path), lineterm=""))
            if diff:
                print(flush=True)
                print("Installed vs generated env diff:", flush=True)
                print(diff, flush=True)
    if register_agent:
        print(flush=True)
        print("Because agents.list changed, restart the gateway before live testing:", flush=True)
        print("openclaw gateway restart", flush=True)
        print("openclaw gateway status", flush=True)
        print("If the restart command reports a quick failure, do not assume the gateway is actually down yet. On slower hosts the CLI can time out before the gateway is ready. Wait about 30 seconds, then run `openclaw gateway status` again before retrying.", flush=True)
    apply_and_validate_hook = args.apply_and_validate_hook
    if not args.non_interactive:
        live_choice = prompt(
            "Also refresh self-context, apply the hook mapping, restart the gateway, and run a local hook smoke test now?",
            "no",
        ).lower()
        apply_and_validate_hook = live_choice in {"y", "yes"}
    if apply_and_validate_hook:
        if hooks_token == "REPLACE_ME":
            print(flush=True)
            print("Cannot run live hook apply/validation without a real OpenClaw hooks token.", flush=True)
            if service_manager == "systemd":
                print("Either configure the token in the OpenClaw config or gateway drop-in, or rerun with --hooks-token.", flush=True)
            else:
                print("Either configure the token in the OpenClaw config, set OPENCLAW_HOOKS_TOKEN in the shell, or rerun with --hooks-token.", flush=True)
            return 1
        renderer_script = bundle_root / "scripts" / "render_basicops_hook_config.py"
        template_path = bundle_root / "templates" / "prompts" / "basicops-worker-policy.template.md"

        if not renderer_script.is_file():
            raise SystemExit(f"Renderer script not found: {renderer_script}")
        if not template_path.is_file():
            raise SystemExit(f"Template not found: {template_path}")

        print(flush=True)
        print("Refreshing self-context before apply...", flush=True)
        run([
            sys.executable,
            wrapper_path,
            "--as", basicops_profile,
            "get-self-context",
            "--agent-id", agent_id,
            "--cache-path", self_context_cache_path,
            "--refresh",
        ], args.dry_run)

        if not args.dry_run:
            show_basicops_identity_confirmation(
                cache_path=self_context_cache_path,
                agent_id=agent_id,
                display_name=display_name,
                basicops_profile=basicops_profile,
                require_confirmation=not args.non_interactive,
            )

        print(flush=True)
        print("Applying hook mapping...", flush=True)
        run([
            sys.executable,
            str(renderer_script),
            "--template", str(template_path),
            "--openclaw-config", openclaw_config_path,
            "--self-context-cache", self_context_cache_path,
            "--agent-id", agent_id,
            "--basicops-profile", basicops_profile,
            "--hook-path", hook_path,
            "--hooks-token", hooks_token,
            "--display-name", display_name,
            "--mapping-name", f"BasicOps {display_name} Hook",
            "--wrapper-path", wrapper_path,
            "--mode", "apply",
            "--backup",
        ], args.dry_run)

        if generated_hooks_token and service_manager == "systemd":
            print(flush=True)
            print("Installing the generated gateway hooks-token drop-in before restart...", flush=True)
            run(["mkdir", "-p", str(installed_gateway_dropin_path.parent)], args.dry_run)
            run(["cp", str(generated_gateway_dropin_path), str(installed_gateway_dropin_path)], args.dry_run)
            run(["systemctl", "--user", "daemon-reload"], args.dry_run, allow_failure=True)

        print(flush=True)
        print("Restarting OpenClaw gateway so the updated hook config is live...", flush=True)
        run(["openclaw", "gateway", "restart"], args.dry_run)
        run(["openclaw", "gateway", "status"], args.dry_run, allow_failure=True)

        if not args.dry_run:
            print(flush=True)
            print("Running local hook smoke test...", flush=True)
            ok, detail = validate_hook_ingress_locally(int(openclaw_hook_port), hook_path, hooks_token)
            print(detail, flush=True)
            if not ok:
                return 1
            print("Local hook ingress validation passed.", flush=True)
    print("Suggested next move: follow NEXT-STEPS.md in order, starting with dependency checks if you skipped preflight.", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
