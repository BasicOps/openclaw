#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
GENERATED_DIR="$ROOT/generated"
CACHE_FOUND=0

if [ -d "$GENERATED_DIR" ]; then
  mapfile -t GENERATED_FILES < <(find "$GENERATED_DIR" -type f | sort)
  if [ "${#GENERATED_FILES[@]}" -gt 0 ]; then
    echo "Refusing to package bundle: stale generated output detected under $GENERATED_DIR"
    printf '  %s\n' "${GENERATED_FILES[@]}"
    echo
    echo "Move or delete generated output before shipping the bundle."
    exit 1
  fi
fi

mapfile -t BYTECODE_FILES < <(find "$ROOT" \( -type d -name '__pycache__' -o -type f -name '*.pyc' \) | sort)
if [ "${#BYTECODE_FILES[@]}" -gt 0 ]; then
  echo "Refusing to package bundle: Python bytecode cache files detected in bundle tree"
  printf '  %s\n' "${BYTECODE_FILES[@]}"
  echo
  echo "Remove __pycache__ directories and .pyc files before shipping the bundle."
  exit 1
fi

echo "Bundle root: $ROOT"
echo
echo "Contents:"
find "$ROOT" -maxdepth 3 -type f | sort

echo
echo "To package this bundle:"
echo "  cd $(dirname "$ROOT") && zip -r basicops-agent-replication-bundle.zip $(basename "$ROOT")"
echo "or"
echo "  cd $(dirname "$ROOT") && tar -czf basicops-agent-replication-bundle.tar.gz $(basename "$ROOT")"
