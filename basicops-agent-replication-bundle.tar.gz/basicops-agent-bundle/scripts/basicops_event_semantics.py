#!/usr/bin/env python3
from __future__ import annotations

import html
import re
from typing import Any

from basicops_payload_compat import REPLY_EVENT_TYPES, coerce_primary_event

EVENT_SURFACES = {
    "basicops.task.message.created": "task_message",
    "basicops.task.message.updated": "task_message",
    "basicops.task.reply.created": "task_reply",
    "basicops.task.reply.updated": "task_reply",
    "basicops.task.created": "task_lifecycle",
    "basicops.task.updated": "task_lifecycle",
    "basicops.project.message.created": "project_message",
    "basicops.project.message.updated": "project_message",
    "basicops.project.reply.created": "project_message",
    "basicops.project.reply.updated": "project_message",
    "basicops.chat.message.created": "chat_message",
    "basicops.chat.message.updated": "chat_message",
    "basicops.chat.reply.created": "chat_message",
    "basicops.chat.reply.updated": "chat_message",
    "basicops.groupchat.message.created": "groupchat_message",
    "basicops.groupchat.message.updated": "groupchat_message",
    "basicops.groupchat.reply.created": "groupchat_message",
    "basicops.groupchat.reply.updated": "groupchat_message",
    "basicops.channel.message.created": "channel_message",
    "basicops.channel.message.updated": "channel_message",
    "basicops.channel.reply.created": "channel_message",
    "basicops.channel.reply.updated": "channel_message",
}

TASK_LIFECYCLE_EVENTS = {
    "basicops.task.created",
    "basicops.task.updated",
}

MESSAGE_SURFACES = {
    "task_message",
    "task_reply",
    "project_message",
    "chat_message",
    "groupchat_message",
    "channel_message",
}


def _as_dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}



def _first_present(*values: Any) -> Any:
    for value in values:
        if value is None:
            continue
        if isinstance(value, str) and value == "":
            continue
        return value
    return None



def html_to_text(value: str) -> str:
    if not value:
        return ""
    text = re.sub(r"<br\s*/?>", "\n", value, flags=re.I)
    text = re.sub(r"</p\s*>", "\n", text, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = html.unescape(text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()



def _pick_task_object(data: Any) -> dict[str, Any]:
    if isinstance(data, list) and data and isinstance(data[0], dict):
        return data[0]
    if isinstance(data, dict) and any(
        key in data
        for key in (
            "title",
            "Title",
            "status",
            "Status",
            "description",
            "Description",
            "project",
            "assignee",
            "change",
            "url",
            "Url",
        )
    ):
        return data
    return {}



def normalize_task_snapshot(task_obj: dict[str, Any]) -> dict[str, Any] | None:
    if not task_obj:
        return None
    assignee = _as_dict(task_obj.get("assignee"))
    project = _as_dict(task_obj.get("project"))
    change = _as_dict(task_obj.get("change"))
    assignee_change = _as_dict(change.get("assignee"))
    change_to = _as_dict(assignee_change.get("to"))
    change_from = _as_dict(assignee_change.get("from"))
    return {
        "id": _first_present(task_obj.get("id"), task_obj.get("Id"), task_obj.get("taskId"), task_obj.get("TaskId")),
        "title": _first_present(task_obj.get("title"), task_obj.get("Title")),
        "url": _first_present(task_obj.get("url"), task_obj.get("Url")),
        "status": _first_present(task_obj.get("status"), task_obj.get("Status")),
        "descriptionHtml": _first_present(task_obj.get("description"), task_obj.get("Description")),
        "project": {
            "id": _first_present(project.get("id"), project.get("Id"), task_obj.get("projectId"), task_obj.get("ProjectId")),
            "title": _first_present(project.get("title"), project.get("Title"), project.get("name"), project.get("Name")),
        },
        "assignee": {
            "id": _first_present(assignee.get("id"), assignee.get("Id")),
            "name": _first_present(
                assignee.get("name"),
                " ".join(
                    part
                    for part in [assignee.get("firstName"), assignee.get("lastName")]
                    if isinstance(part, str) and part.strip()
                )
                or None,
            ),
        },
        "assigneeChange": {
            "fromId": _first_present(change_from.get("id"), change_from.get("Id")),
            "toId": _first_present(change_to.get("id"), change_to.get("Id")),
        },
    }



def normalize_basicops_event_semantics(payload: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValueError("payload must be a dict")

    event = coerce_primary_event(payload)
    event_type = event.get("event")
    surface = EVENT_SURFACES.get(event_type, "unknown")

    event_user = _as_dict(event.get("user"))
    data = event.get("data")
    data_dict = _as_dict(data)
    task_obj = _pick_task_object(data)
    task_from_data = _as_dict(data_dict.get("task"))
    project_from_data = _as_dict(data_dict.get("project"))

    is_task_lifecycle = event_type in TASK_LIFECYCLE_EVENTS

    original_id = _first_present(
        data_dict.get("id"),
        task_obj.get("id"),
        data_dict.get("Id"),
        task_obj.get("Id"),
    )
    original_id_fallback = _first_present(
        data_dict.get("Id"),
        task_obj.get("Id"),
        data_dict.get("id"),
        task_obj.get("id"),
    )

    message_entity_id = _first_present(data_dict.get("id"), data_dict.get("Id")) if surface in MESSAGE_SURFACES else None
    reply_target_message_id = _first_present(
        data_dict.get("messageId"),
        data_dict.get("MessageId"),
        message_entity_id if surface in MESSAGE_SURFACES else None,
    )

    author_user_id = _first_present(
        data_dict.get("userId"),
        data_dict.get("UserId"),
        event_user.get("id"),
        event_user.get("Id"),
        _as_dict(data_dict.get("user")).get("id"),
        _as_dict(data_dict.get("user")).get("Id"),
    )

    task_id = _first_present(
        data_dict.get("taskId"),
        data_dict.get("TaskId"),
        task_from_data.get("id"),
        task_from_data.get("Id"),
        task_obj.get("id"),
        task_obj.get("Id"),
    )
    project_id = _first_present(
        data_dict.get("projectId"),
        data_dict.get("ProjectId"),
        project_from_data.get("id"),
        project_from_data.get("Id"),
        _as_dict(task_obj.get("project")).get("id"),
        _as_dict(task_obj.get("project")).get("Id"),
    )
    chat_id = _first_present(data_dict.get("chatId"), data_dict.get("ChatId"))
    groupchat_id = _first_present(
        data_dict.get("groupChatId"),
        data_dict.get("GroupChatId"),
        data_dict.get("groupchatId"),
        data_dict.get("GroupchatId"),
    )
    channel_id = _first_present(data_dict.get("channelId"), data_dict.get("ChannelId"))

    assignee_user_id = _first_present(
        _as_dict(task_obj.get("assignee")).get("id"),
        _as_dict(task_obj.get("assignee")).get("Id"),
        _as_dict(_as_dict(_as_dict(task_obj.get("change")).get("assignee")).get("to")).get("id"),
        _as_dict(_as_dict(_as_dict(task_obj.get("change")).get("assignee")).get("to")).get("Id"),
    )

    message_html = _first_present(data_dict.get("message"), data_dict.get("Message"), "") if not is_task_lifecycle else ""
    message_text = html_to_text(message_html)

    return {
        "schemaVersion": "basicops.event/1",
        "event": {
            "type": event_type,
            "surface": surface,
            "timestamp": event.get("timestamp"),
            "companyId": event.get("companyId"),
            "webhookId": event.get("webhookId"),
            "updates": event.get("updates"),
        },
        "trigger": {
            "originalId": original_id,
            "originalIdFallback": original_id_fallback,
            "messageEntityId": message_entity_id,
            "replyTargetMessageId": reply_target_message_id,
            "authorUserId": author_user_id,
            "actorUserId": _first_present(event_user.get("id"), event_user.get("Id")),
            "taskId": task_id,
            "projectId": project_id,
            "chatId": chat_id,
            "groupChatId": groupchat_id,
            "channelId": channel_id,
            "assigneeUserId": assignee_user_id,
        },
        "request": {
            "html": message_html,
            "text": message_text,
        },
        "context": {
            "task": normalize_task_snapshot(task_obj if is_task_lifecycle else (task_from_data or task_obj)),
            "project": {
                "id": project_id,
                "title": _first_present(
                    project_from_data.get("title"),
                    project_from_data.get("Title"),
                    project_from_data.get("name"),
                    project_from_data.get("Name"),
                    _as_dict(task_obj.get("project")).get("title"),
                    _as_dict(task_obj.get("project")).get("Title"),
                ),
            } if project_id is not None else None,
            "message": {
                "id": message_entity_id,
                "replyTargetMessageId": reply_target_message_id,
                "created": _first_present(data_dict.get("created"), data_dict.get("Created")),
            } if surface in MESSAGE_SURFACES else None,
        },
        "capabilities": {
            "hasTaskId": task_id is not None,
            "hasProjectId": project_id is not None,
            "hasChatId": chat_id is not None,
            "hasGroupChatId": groupchat_id is not None,
            "hasChannelId": channel_id is not None,
            "hasReplyTargetMessageId": reply_target_message_id is not None,
            "canReplyInMessage": reply_target_message_id is not None,
            "canCreateTaskMessage": task_id is not None,
            "canCreateProjectMessage": project_id is not None and surface == "project_message",
            "canCreateChatMessage": chat_id is not None and surface == "chat_message",
            "canCreateGroupchatMessage": groupchat_id is not None and surface == "groupchat_message",
            "canCreateChannelMessage": channel_id is not None and surface == "channel_message",
            "canUpdateCurrentTask": task_id is not None,
        },
        "rawRefs": {
            "dataShape": "list" if isinstance(data, list) else "dict" if isinstance(data, dict) else type(data).__name__,
        },
    }
