#!/usr/bin/env bash
set -euo pipefail

echo 'TARGET AGENT: lyra'
echo 'READ ONLY: /home/hjhlarsen/basicops-agent-bundle/generated/lyra/NEXT-STEPS.md'
echo 'Finishing local install for lyra...'

/usr/bin/python3 /home/hjhlarsen/basicops-agent-bundle/scripts/basicops_mcp.py --as lyra get-self-context --agent-id lyra --cache-path /home/hjhlarsen/.cache/basicops-agents/lyra-self.json --refresh

/usr/bin/python3 /home/hjhlarsen/basicops-agent-bundle/scripts/render_basicops_hook_config.py --template /home/hjhlarsen/basicops-agent-bundle/templates/prompts/basicops-worker-policy.template.md --openclaw-config /home/hjhlarsen/.openclaw/openclaw.json --self-context-cache /home/hjhlarsen/.cache/basicops-agents/lyra-self.json --agent-id lyra --basicops-profile lyra --hook-path basicops-lyra --display-name Lyra --mapping-name "BasicOps Lyra Hook" --wrapper-path /home/hjhlarsen/basicops-agent-bundle/scripts/basicops_mcp.py --mode render --stdout summary

/usr/bin/python3 /home/hjhlarsen/basicops-agent-bundle/scripts/render_basicops_hook_config.py --template /home/hjhlarsen/basicops-agent-bundle/templates/prompts/basicops-worker-policy.template.md --openclaw-config /home/hjhlarsen/.openclaw/openclaw.json --self-context-cache /home/hjhlarsen/.cache/basicops-agents/lyra-self.json --agent-id lyra --basicops-profile lyra --hook-path basicops-lyra --display-name Lyra --mapping-name "BasicOps Lyra Hook" --wrapper-path /home/hjhlarsen/basicops-agent-bundle/scripts/basicops_mcp.py --hooks-token 082533d9f6b900e05ed9884ac8c655db6715370ee5909a40 --mode apply --backup

openclaw gateway restart
openclaw gateway status

systemctl --user daemon-reload
systemctl --user enable --now basicops-preack@lyra.service
systemctl --user status basicops-preack@lyra.service --no-pager

export OPENCLAW_HOOKS_TOKEN="$(/usr/bin/python3 - <<'PY'
import json
from pathlib import Path
cfg = json.loads(Path("/home/hjhlarsen/.openclaw/openclaw.json").expanduser().read_text())
hooks = cfg.get('hooks') if isinstance(cfg.get('hooks'), dict) else {}
value = hooks.get('token') if isinstance(hooks.get('token'), str) else ''
print(value.strip())
PY
)"
curl -i -sS http://127.0.0.1:18789/hooks/basicops-lyra -H "Authorization: Bearer ${OPENCLAW_HOOKS_TOKEN:?set OPENCLAW_HOOKS_TOKEN first}" -H 'Content-Type: application/json' --data-binary '{}'
