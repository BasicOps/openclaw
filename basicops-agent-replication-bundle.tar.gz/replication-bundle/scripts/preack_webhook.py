#!/usr/bin/env python3
import html
import json
import os
import re
import subprocess
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
import urllib.request

from pathlib import Path
import sys

SCRIPT_DIR = Path(__file__).resolve().parent
PYTHON_BIN = sys.executable or "python3"
SELF_CONTEXT_HELPER = SCRIPT_DIR
if str(SELF_CONTEXT_HELPER) not in sys.path:
    sys.path.insert(0, str(SELF_CONTEXT_HELPER))

from basicops_self_context import get_self_context


def env_bool(name: str, default: bool) -> bool:
    value = os.environ.get(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def env_int(name: str, default: int) -> int:
    value = os.environ.get(name)
    if value is None or value == "":
        return default
    return int(value)


def env_csv_set(name: str, default: set[str]) -> set[str]:
    value = os.environ.get(name)
    if value is None:
        return set(default)
    items = {item.strip() for item in value.split(",") if item.strip()}
    return items or set(default)


HOST = os.environ.get("SHIM_HOST", "127.0.0.1")
PORT = env_int("SHIM_PORT", 18891)
BASICOPS_AGENT_ID = os.environ.get("BASICOPS_AGENT_ID", "worker")
BASICOPS_PROFILE = os.environ.get("BASICOPS_PROFILE", "worker")
OPENCLAW_FORWARD_URL = os.environ.get(
    "OPENCLAW_FORWARD_URL", "http://127.0.0.1:18789/hooks/basicops-worker"
)
OPENCLAW_TOKEN = os.environ.get("OPENCLAW_HOOKS_TOKEN", "")
WRAPPER = os.environ.get(
    "BASICOPS_MCP_WRAPPER",
    str(SCRIPT_DIR / "basicops_mcp.py"),
)
SELF_CONTEXT_CACHE_PATH = os.environ.get(
    "SELF_CONTEXT_CACHE_PATH",
    str(Path.home() / ".cache" / "basicops-agents" / f"{BASICOPS_AGENT_ID}-self.json"),
)
SELF_CONTEXT_CACHE_TTL_SECONDS = env_int("SELF_CONTEXT_CACHE_TTL_SECONDS", 21600)
STATUS_ENABLED = env_bool("STATUS_ENABLED", True)
SEEN_TTL_SECONDS = env_int("STATUS_DEDUPE_TTL_SECONDS", 120)
REQUIRE_EXPLICIT_MENTION = env_bool("REQUIRE_EXPLICIT_MENTION", True)
SKIP_IF_OTHER_AGENT_MENTIONED = env_bool("SKIP_IF_OTHER_AGENT_MENTIONED", True)
MENTION_TERMS = env_csv_set("MENTION_TERMS", set())
OTHER_AGENT_TERMS = env_csv_set("OTHER_AGENT_TERMS", set())
ENABLE_ASSIGNMENT_TRIGGERED_TASK_UPDATES = env_bool("ENABLE_ASSIGNMENT_TRIGGERED_TASK_UPDATES", True)

EVENT_SURFACES = {
    "basicops.task.message.created": "task-message",
    "basicops.task.message.updated": "task-message",
    "basicops.task.reply.created": "task-reply",
    "basicops.task.reply.updated": "task-reply",
    "basicops.task.updated": "task-lifecycle",
    "basicops.project.message.created": "project-message",
    "basicops.project.message.updated": "project-message",
    "basicops.project.reply.created": "project-message",
    "basicops.project.reply.updated": "project-message",
    "basicops.chat.message.created": "chat-message",
    "basicops.chat.message.updated": "chat-message",
    "basicops.chat.reply.created": "chat-message",
    "basicops.chat.reply.updated": "chat-message",
    "basicops.groupchat.message.created": "groupchat-message",
    "basicops.groupchat.message.updated": "groupchat-message",
    "basicops.groupchat.reply.created": "groupchat-message",
    "basicops.groupchat.reply.updated": "groupchat-message",
    "basicops.channel.message.created": "channel-message",
    "basicops.channel.message.updated": "channel-message",
    "basicops.channel.reply.created": "channel-message",
    "basicops.channel.reply.updated": "channel-message",
}

NON_TASK_MESSAGE_SURFACES = {
    "project-message",
    "channel-message",
    "groupchat-message",
    "chat-message",
}

DEFAULT_ALLOWED_EVENTS = {
    "basicops.task.message.created",
    "basicops.task.message.updated",
    "basicops.task.reply.created",
    "basicops.task.reply.updated",
    "basicops.project.message.created",
    "basicops.project.message.updated",
    "basicops.project.reply.created",
    "basicops.project.reply.updated",
    "basicops.chat.message.created",
    "basicops.chat.message.updated",
    "basicops.chat.reply.created",
    "basicops.chat.reply.updated",
    "basicops.groupchat.message.created",
    "basicops.groupchat.message.updated",
    "basicops.groupchat.reply.created",
    "basicops.groupchat.reply.updated",
    "basicops.channel.message.created",
    "basicops.channel.message.updated",
    "basicops.channel.reply.created",
    "basicops.channel.reply.updated",
}
ALLOWED_EVENTS = env_csv_set("ALLOWED_EVENTS", DEFAULT_ALLOWED_EVENTS)

SEEN_EVENT_IDS = {}
SELF_CONTEXT = None


def log(msg):
    print(msg, flush=True)


def load_self_context(force_refresh: bool = False):
    global SELF_CONTEXT
    SELF_CONTEXT = get_self_context(
        agent_id=BASICOPS_AGENT_ID,
        profile=BASICOPS_PROFILE,
        wrapper_path=WRAPPER,
        cache_path=SELF_CONTEXT_CACHE_PATH,
        max_age_seconds=SELF_CONTEXT_CACHE_TTL_SECONDS,
        force_refresh=force_refresh,
    )
    log(
        "self_context: loaded "
        f"agent_id={SELF_CONTEXT.get('agentId')} profile={SELF_CONTEXT.get('profile')} "
        f"user_id={SELF_CONTEXT.get('userId')} tz={SELF_CONTEXT.get('timeZone')} "
        f"date_format={SELF_CONTEXT.get('dateFormat')} time_format={SELF_CONTEXT.get('timeFormat')}"
    )
    return SELF_CONTEXT


def self_user_id():
    global SELF_CONTEXT
    if not SELF_CONTEXT:
        load_self_context(force_refresh=False)
    return SELF_CONTEXT.get("userId") if SELF_CONTEXT else None


def is_duplicate(event_id: str) -> bool:
    if not event_id:
        return False

    now = time.time()

    expired = [k for k, ts in SEEN_EVENT_IDS.items() if now - ts > SEEN_TTL_SECONDS]
    for k in expired:
        SEEN_EVENT_IDS.pop(k, None)

    if event_id in SEEN_EVENT_IDS:
        return True

    SEEN_EVENT_IDS[event_id] = now
    return False


def parse_event(payload):
    try:
        event = payload["events"][0]
        event_type = event.get("event")
        surface = EVENT_SURFACES.get(event_type)
        data = event.get("data", {})
        event_id = None
        user_id = None
        task_id = None
        project_id = None
        assignee_user_id = None
        message_html = ""

        if event_type == "basicops.task.updated":
            task_obj = None
            if isinstance(data, list) and data:
                task_obj = data[0]
            elif isinstance(data, dict):
                task_obj = data
            if not isinstance(task_obj, dict):
                raise ValueError("task.updated payload missing task object")

            project_obj = task_obj.get("project") if isinstance(task_obj.get("project"), dict) else {}
            assignee_obj = task_obj.get("assignee") if isinstance(task_obj.get("assignee"), dict) else {}
            change_obj = task_obj.get("change") if isinstance(task_obj.get("change"), dict) else {}
            change_assignee = change_obj.get("assignee") if isinstance(change_obj.get("assignee"), dict) else {}
            change_to = change_assignee.get("to") if isinstance(change_assignee.get("to"), dict) else {}
            event_user = event.get("user") if isinstance(event.get("user"), dict) else {}

            event_id = task_obj.get("id") or task_obj.get("Id")
            task_id = task_obj.get("id") or task_obj.get("Id")
            project_id = task_obj.get("projectId") or task_obj.get("ProjectId") or project_obj.get("id") or project_obj.get("Id")
            user_id = event_user.get("id") or event_user.get("Id")
            assignee_user_id = assignee_obj.get("id") or assignee_obj.get("Id") or change_to.get("id") or change_to.get("Id")
        else:
            if not isinstance(data, dict):
                raise ValueError("message/reply payload missing data object")
            user_obj = data.get("user") if isinstance(data.get("user"), dict) else {}
            task_obj = data.get("task") if isinstance(data.get("task"), dict) else {}
            project_obj = data.get("project") if isinstance(data.get("project"), dict) else {}
            event_id = data.get("id") or data.get("Id")
            user_id = data.get("userId") or data.get("UserId") or user_obj.get("id") or user_obj.get("Id")
            task_id = data.get("taskId") or data.get("TaskId") or task_obj.get("id") or task_obj.get("Id")
            project_id = data.get("projectId") or data.get("ProjectId") or project_obj.get("id") or project_obj.get("Id")
            message_html = data.get("message") or data.get("Message") or ""

        return {
            "event_type": event_type,
            "surface": surface,
            "event_id": event_id,
            "user_id": user_id,
            "task_id": task_id,
            "project_id": project_id,
            "assignee_user_id": assignee_user_id,
            "message_html": message_html,
        }
    except Exception as e:
        log(f"status: payload parse failed: {e}")
        return None


def html_to_text(value: str) -> str:
    if not value:
        return ""
    text = re.sub(r"<br\s*/?>", "\n", value, flags=re.I)
    text = re.sub(r"</p\s*>", "\n", text, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = html.unescape(text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def build_self_mention_terms() -> set[str]:
    terms = set(MENTION_TERMS)
    terms.add(BASICOPS_AGENT_ID)

    return {term.strip() for term in terms if term and term.strip()}


def has_any_term(text: str, terms: set[str]) -> bool:
    if not text or not terms:
        return False
    for term in terms:
        pattern = rf"(?<!\w)@?{re.escape(term)}(?!\w)"
        if re.search(pattern, text, flags=re.I):
            return True
    return False


def should_forward_event(info):
    if not info:
        return False

    current_self_user_id = self_user_id()
    event_type = info.get("event_type")
    surface = info.get("surface")
    user_id = info.get("user_id")

    if current_self_user_id is not None and user_id == current_self_user_id:
        log(
            "status: skip forward, self event "
            f"agent={BASICOPS_AGENT_ID} event_type={event_type} user_id={user_id}"
        )
        return False

    if event_type == "basicops.task.updated":
        assignee_user_id = info.get("assignee_user_id")
        if (
            ENABLE_ASSIGNMENT_TRIGGERED_TASK_UPDATES
            and current_self_user_id is not None
            and assignee_user_id == current_self_user_id
        ):
            log(
                "status: forward assignment-triggered task update "
                f"agent={BASICOPS_AGENT_ID} task_id={info.get('task_id')} assignee_user_id={assignee_user_id}"
            )
            return True

        log(
            "status: skip forward, non-triggering task update "
            f"agent={BASICOPS_AGENT_ID} task_id={info.get('task_id')} assignee_user_id={assignee_user_id}"
        )
        return False

    text = html_to_text(info.get("message_html") or "")
    self_terms = build_self_mention_terms()
    mentions_self = has_any_term(text, self_terms)
    mentions_other = has_any_term(text, OTHER_AGENT_TERMS)

    if surface in NON_TASK_MESSAGE_SURFACES and surface != "chat-message" and not mentions_self:
        log(
            "status: skip forward, non-task surface without self mention "
            f"agent={BASICOPS_AGENT_ID} surface={surface} text={text!r}"
        )
        return False

    if REQUIRE_EXPLICIT_MENTION and surface != "chat-message" and not mentions_self:
        log(
            "status: skip forward, no self mention "
            f"agent={BASICOPS_AGENT_ID} text={text!r}"
        )
        return False

    if SKIP_IF_OTHER_AGENT_MENTIONED and surface != "chat-message" and mentions_other and not mentions_self:
        log(
            "status: skip forward, other agent mentioned "
            f"agent={BASICOPS_AGENT_ID} text={text!r}"
        )
        return False

    return True


def should_track_status(info):
    if not STATUS_ENABLED:
        log("status: disabled by config")
        return False

    if not info:
        return False

    event_type = info.get("event_type")
    event_id = info.get("event_id")
    user_id = info.get("user_id")
    current_self_user_id = self_user_id()

    log(
        f"status: event_type={event_type} event_id={event_id} "
        f"user_id={user_id} self_user_id={current_self_user_id} task_id={info.get('task_id')}"
    )

    if event_type not in ALLOWED_EVENTS:
        log("status: skip event not in allowed set")
        return False

    if not event_id:
        log("status: skip missing event_id")
        return False

    if current_self_user_id is not None and user_id == current_self_user_id:
        log(f"status: skip self message user_id={user_id}")
        return False

    return True


def set_status(event_id, event_type, status):
    args = json.dumps({
        "id": event_id,
        "event": event_type,
        "status": status,
    })

    log(f"status: setting {status} for event_id={event_id} event_type={event_type}")

    proc = subprocess.run(
        [
            PYTHON_BIN,
            WRAPPER,
            "--as",
            BASICOPS_PROFILE,
            "call",
            "--tool",
            "set_agent_status",
            "--args",
            args,
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
    )

    stdout = (proc.stdout or "").strip()
    stderr = (proc.stderr or "").strip()
    log(
        f"status: result status={status} rc={proc.returncode} "
        f"stdout={stdout!r} stderr={stderr!r}"
    )


def maybe_set_working(info):
    if not should_track_status(info):
        return False

    event_id = info["event_id"]
    event_type = info["event_type"]

    if is_duplicate(event_id):
        log(f"status: skip duplicate event_id={event_id}")
        return False

    set_status(event_id, event_type, "working")
    return True


class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length)

        log(f"status: received POST path={self.path} bytes={length}")

        try:
            payload = json.loads(body.decode("utf-8"))
        except Exception:
            self.send_response(400)
            self.end_headers()
            self.wfile.write(b'{"ok":false,"error":"invalid_json"}')
            return

        event_info = parse_event(payload)
        if not should_forward_event(event_info):
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"ok":true,"filtered":true}')
            return

        maybe_set_working(event_info)

        req = urllib.request.Request(
            OPENCLAW_FORWARD_URL,
            data=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {OPENCLAW_TOKEN}",
            },
            method="POST",
        )

        try:
            with urllib.request.urlopen(req) as resp:
                resp_body = resp.read()
                log(f"status: forward ok status={resp.status}")
                self.send_response(resp.status)
                for k, v in resp.getheaders():
                    if k.lower() != "transfer-encoding":
                        self.send_header(k, v)
                self.end_headers()
                self.wfile.write(resp_body)
        except Exception as e:
            log(f"status: forward failed: {e}")
            self.send_response(502)
            self.end_headers()
            self.wfile.write(json.dumps({
                "ok": False,
                "error": "forward_failed",
                "detail": str(e),
            }).encode("utf-8"))

    def log_message(self, format, *args):
        return


if __name__ == "__main__":
    load_self_context(force_refresh=False)
    server = HTTPServer((HOST, PORT), Handler)
    log(f"Listening on http://{HOST}:{PORT}")
    server.serve_forever()
