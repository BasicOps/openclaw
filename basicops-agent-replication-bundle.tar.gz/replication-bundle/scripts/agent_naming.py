from __future__ import annotations

import re


AGENT_ID_PATTERN = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")


def validate_agent_id(agent_id: str) -> str:
    value = agent_id.strip()
    if not value:
        raise SystemExit("--agent-id must not be empty")
    if "/" in value:
        raise SystemExit("--agent-id must not contain /")
    if value.lower() != value:
        raise SystemExit("--agent-id must use lowercase letters, numbers, and hyphens only")
    if not AGENT_ID_PATTERN.fullmatch(value):
        raise SystemExit("--agent-id must match ^[a-z0-9]+(?:-[a-z0-9]+)*$")
    return value


def default_display_name(agent_id: str) -> str:
    parts = [part for part in agent_id.strip().replace("_", "-").split("-") if part]
    if not parts:
        return agent_id.strip().capitalize()
    return " ".join(part.capitalize() for part in parts)
