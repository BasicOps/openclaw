#!/usr/bin/env node
import fs from 'node:fs';
import net from 'node:net';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const MODULE_DIR = path.dirname(fileURLToPath(import.meta.url));

function pathExists(candidate) {
  try {
    fs.accessSync(candidate);
    return true;
  } catch {
    return false;
  }
}

function findExecutableOnPath(name) {
  const pathValue = process.env.PATH || '';
  for (const dir of pathValue.split(path.delimiter)) {
    if (!dir) continue;
    const candidate = path.join(dir, name);
    if (pathExists(candidate)) return candidate;
  }
  return null;
}

function extractOpenClawRootFromExecutable(executablePath) {
  try {
    const realPath = fs.realpathSync(executablePath);
    if (path.basename(realPath) === 'openclaw.mjs') return path.dirname(realPath);
    if (realPath.endsWith(`${path.sep}dist${path.sep}index.js`) || realPath.endsWith(`${path.sep}dist${path.sep}index.mjs`)) {
      return path.dirname(path.dirname(realPath));
    }
    const text = fs.readFileSync(realPath, 'utf8');
    const match = text.match(/([\\/A-Za-z0-9._-]+node_modules[\\/]openclaw)(?:[\\/]dist[\\/]index\\.(?:js|mjs)|[\\/]openclaw\\.mjs)?/);
    return match ? match[1] : null;
  } catch {
    return null;
  }
}

function resolveOpenClawDistDir() {
  const candidates = [];
  if (process.env.OPENCLAW_DIST_DIR) candidates.push(process.env.OPENCLAW_DIST_DIR);
  if (process.env.OPENCLAW_ROOT) candidates.push(path.join(process.env.OPENCLAW_ROOT, 'dist'));

  const openclawExecutable = findExecutableOnPath('openclaw');
  const derivedRoot = openclawExecutable ? extractOpenClawRootFromExecutable(openclawExecutable) : null;
  if (derivedRoot) candidates.push(path.join(derivedRoot, 'dist'));

  if (process.env.HOME) {
    candidates.push(path.join(process.env.HOME, '.npm-global', 'lib', 'node_modules', 'openclaw', 'dist'));
  }
  candidates.push('/usr/lib/node_modules/openclaw/dist');
  candidates.push('/usr/local/lib/node_modules/openclaw/dist');

  for (const candidate of candidates) {
    if (!candidate) continue;
    try {
      if (fs.statSync(candidate).isDirectory()) return candidate;
    } catch {}
  }
  throw new Error(`Could not resolve OpenClaw dist directory. Checked: ${candidates.filter(Boolean).join(', ')}`);
}

const DIST_DIR = resolveOpenClawDistDir();
const DEFAULT_SOCKET_PATH = path.join(process.env.HOME || '.', '.cache', 'openclaw', 'agent-command.sock');
const SERVER_STARTED_AT = new Date().toISOString();

function parseArgs(argv) {
  const args = { socket: process.env.OPENCLAW_AGENT_COMMAND_SOCKET || DEFAULT_SOCKET_PATH };
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];
    if (token === '--socket') {
      args.socket = argv[i + 1] ?? args.socket;
      i += 1;
      continue;
    }
    throw new Error(`Unexpected argument: ${token}`);
  }
  return args;
}

function resolveDistModulePath(prefix) {
  const entry = fs.readdirSync(DIST_DIR).find((name) => name.startsWith(prefix) && name.endsWith('.js'));
  if (!entry) throw new Error(`Could not locate ${prefix} module under ${DIST_DIR}`);
  return path.join(DIST_DIR, entry);
}

function resolveAgentCommandModulePath() {
  return resolveDistModulePath('agent-command-');
}

function resolveAgentEventsModulePath() {
  return resolveDistModulePath('agent-events-');
}

async function loadRuntime() {
  const [mod, agentEventsMod] = await Promise.all([
    import(pathToFileURL(resolveAgentCommandModulePath()).href),
    import(pathToFileURL(resolveAgentEventsModulePath()).href),
  ]);
  const agentCommand = mod.n;
  const onAgentEvent = agentEventsMod.l;
  if (typeof agentCommand !== 'function') throw new Error('agentCommand export not found');
  if (typeof onAgentEvent !== 'function') throw new Error('onAgentEvent export not found');
  return { agentCommand, onAgentEvent };
}

function buildErrorEnvelope(requestId, message, retryable) {
  return {
    protocolVersion: 1,
    requestId,
    status: 'error',
    error: {
      message,
      retryable,
    },
  };
}

async function executeRequest(request, runtime, queueWaitMs) {
  const traceStartedAt = Date.now();
  const streamCounts = {};
  const phaseOffsetsMs = {};
  const eventTrace = [];
  const unsubscribe = runtime.onAgentEvent((event) => {
    if (!event || event.sessionKey !== request.sessionKey) return;
    const offsetMs = Date.now() - traceStartedAt;
    const stream = typeof event.stream === 'string' ? event.stream : 'unknown';
    streamCounts[stream] = (streamCounts[stream] || 0) + 1;
    const phase = typeof event.data?.phase === 'string' ? event.data.phase : undefined;
    const key = phase ? `${stream}:${phase}` : stream;
    if (phaseOffsetsMs[key] === undefined) phaseOffsetsMs[key] = offsetMs;
    if (eventTrace.length < 40) {
      eventTrace.push({
        runId: event.runId,
        stream,
        phase,
        offsetMs,
        dataKeys: event.data && typeof event.data === 'object' ? Object.keys(event.data).slice(0, 8) : [],
      });
    }
  });

  const quietRuntime = {
    log: () => {},
    error: () => {},
    warn: () => {},
  };
  const agentCommandStartedAt = Date.now();
  let result;
  try {
    result = await runtime.agentCommand({
      agentId: request.agentId,
      sessionKey: request.sessionKey,
      message: request.message,
      timeout: String(request.timeoutSeconds ?? 180),
      thinking: request.thinking || undefined,
      model: request.model || undefined,
      senderIsOwner: true,
      allowModelOverride: true,
    }, quietRuntime);
  } finally {
    try {
      unsubscribe?.();
    } catch {}
  }
  const agentCommandFinishedAt = Date.now();

  const envelope = {
    status: 'success',
    summary: null,
    runId: null,
    result,
    runnerTiming: {
      totalDurationMs: agentCommandFinishedAt - agentCommandStartedAt,
      queueWaitMs,
      moduleResolveDurationMs: 0,
      moduleImportDurationMs: 0,
      agentCommandDurationMs: agentCommandFinishedAt - agentCommandStartedAt,
      firstEventOffsetMs: eventTrace.length > 0 ? eventTrace[0].offsetMs : null,
      firstLifecycleStartOffsetMs: phaseOffsetsMs['lifecycle:start'] ?? null,
      firstAssistantOffsetMs: phaseOffsetsMs.assistant ?? null,
      streamCounts,
      phaseOffsetsMs,
      eventTrace,
    },
    runnerTransport: {
      mode: 'warm',
      pid: process.pid,
      startedAt: SERVER_STARTED_AT,
    },
  };
  return envelope;
}

function validateRequest(request) {
  if (!request || typeof request !== 'object') throw new Error('Request must be a JSON object');
  if (request.protocolVersion !== 1) throw new Error('Unsupported protocolVersion');
  if (typeof request.requestId !== 'string' || !request.requestId) throw new Error('requestId is required');
  if (typeof request.agentId !== 'string' || !request.agentId) throw new Error('agentId is required');
  if (typeof request.sessionKey !== 'string' || !request.sessionKey) throw new Error('sessionKey is required');
  if (typeof request.message !== 'string') throw new Error('message must be a string');
}

async function main() {
  const { socket } = parseArgs(process.argv.slice(2));
  fs.mkdirSync(path.dirname(socket), { recursive: true });
  try {
    if (fs.existsSync(socket)) {
      try {
        await new Promise((resolve, reject) => {
          const probe = net.createConnection(socket, () => {
            probe.end();
            resolve();
          });
          probe.on('error', reject);
        });
        return;
      } catch {
        fs.unlinkSync(socket);
      }
    }
  } catch {}

  const runtime = await loadRuntime();
  let queue = Promise.resolve();

  const server = net.createServer((connection) => {
    connection.setEncoding('utf8');
    let buffer = '';
    let handled = false;

    const finish = async (payload) => {
      if (connection.destroyed) return;
      connection.end(`${JSON.stringify(payload)}\n`);
    };

    connection.on('data', (chunk) => {
      if (handled) return;
      buffer += chunk;
      const newlineIndex = buffer.indexOf('\n');
      if (newlineIndex === -1) return;
      handled = true;
      const line = buffer.slice(0, newlineIndex).trim();
      let request;
      try {
        request = JSON.parse(line);
        validateRequest(request);
      } catch (error) {
        finish(buildErrorEnvelope(request?.requestId || null, error instanceof Error ? error.message : String(error), false));
        return;
      }

      const queuedAt = Date.now();
      const task = queue.then(async () => {
        const queueWaitMs = Date.now() - queuedAt;
        return executeRequest(request, runtime, queueWaitMs);
      });
      queue = task.catch(() => {});
      task
        .then((envelope) => finish({
          protocolVersion: 1,
          requestId: request.requestId,
          status: 'success',
          envelope,
        }))
        .catch((error) => finish(buildErrorEnvelope(request.requestId, error instanceof Error ? error.message : String(error), false)));
    });

    connection.on('error', () => {
      try {
        connection.destroy();
      } catch {}
    });
  });

  server.on('error', (error) => {
    if (error && error.code === 'EADDRINUSE') {
      process.exit(0);
      return;
    }
    process.stderr.write(`${error instanceof Error ? error.stack || error.message : String(error)}\n`);
    process.exit(3);
  });

  const cleanup = () => {
    try {
      server.close();
    } catch {}
    try {
      if (fs.existsSync(socket)) fs.unlinkSync(socket);
    } catch {}
  };

  process.on('SIGINT', () => {
    cleanup();
    process.exit(0);
  });
  process.on('SIGTERM', () => {
    cleanup();
    process.exit(0);
  });
  process.on('exit', cleanup);

  server.listen(socket);
}

main().catch((error) => {
  process.stderr.write(`${error instanceof Error ? error.stack || error.message : String(error)}\n`);
  process.exit(3);
});
