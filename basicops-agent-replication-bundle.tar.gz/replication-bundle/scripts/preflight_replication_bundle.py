#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import socket
import subprocess
from pathlib import Path
import sys


REQUIRED_BINARIES = ["python3", "mcporter", "openclaw"]
REQUIRED_BINARY_INSTALL_HINTS = {
    "mcporter": "Install with: sudo npm install -g mcporter",
}


def detect_default_target_home() -> str:
    env_home = os.environ.get("HOME", "").strip()
    if env_home:
        return env_home.rstrip("/") or "/"
    return str(Path.home())


def detect_platform_name() -> str:
    return platform.system() or "Unknown"


def resolve_service_manager(requested: str, platform_name: str) -> str:
    if requested != "auto":
        return requested
    if platform_name == "Darwin":
        return "launchd"
    return "systemd"
OPTIONAL_RUNTIME_BINARIES = {
    "codex": ["codex"],
    "claude-code": ["claude"],
    "pi": ["pi"],
    "opencode": ["opencode"],
    "gemini-cli": ["gemini"],
}
OPTIONAL_RUNTIME_INSTALL_HINTS = {
    "codex": "Install example: npm install -g @openai/codex",
}

INHERITED_RUNTIME_CHOICES = {"same-as-main", "inherit", "default", "native", "main"}


def check_binary(name: str) -> tuple[bool, str]:
    path = shutil.which(name)
    if path:
        return True, path
    hint = REQUIRED_BINARY_INSTALL_HINTS.get(name)
    if hint:
        return False, f"not found on PATH. {hint}"
    return False, "not found on PATH"


def check_file(path: str) -> tuple[bool, str]:
    p = Path(path).expanduser()
    if p.is_file():
        return True, str(p)
    return False, f"missing file: {p}"


def check_dir(path: str) -> tuple[bool, str]:
    p = Path(path).expanduser()
    if p.is_dir():
        return True, str(p)
    return False, f"missing directory: {p}"


def inspect_inherited_runtime(openclaw_config_path: str) -> tuple[bool, str]:
    path = Path(openclaw_config_path).expanduser()
    if not path.is_file():
        return False, f"missing file: {path}"
    try:
        data = json.loads(path.read_text())
    except Exception as exc:
        return False, f"could not parse OpenClaw config JSON at {path}: {exc}"
    agents = data.get("agents") if isinstance(data, dict) else None
    defaults = agents.get("defaults") if isinstance(agents, dict) else None
    if not isinstance(defaults, dict):
        return False, f"{path} is missing agents.defaults, so there is no inherited runtime/model to reuse"
    model = defaults.get("model")
    if isinstance(model, dict):
        primary = str(model.get("primary", "")).strip()
    else:
        primary = str(model).strip() if isinstance(model, str) else ""
    if primary:
        return True, f"agents.defaults.model.primary is configured as {primary}; same-as-main inheritance should work"
    return False, f"{path} does not contain agents.defaults.model.primary, so same-as-main inheritance cannot be verified"


def inspect_codex_runtime(openclaw_config_path: str) -> list[dict[str, str | bool]]:
    results: list[dict[str, str | bool]] = []
    ok, detail = check_binary("codex")
    runtime_hint = OPTIONAL_RUNTIME_INSTALL_HINTS.get("codex")
    if not ok and runtime_hint:
        detail = f"{detail}. {runtime_hint}"
    add_result(results, "runtime:codex", ok, detail, "required")
    if not ok:
        return results

    try:
        login = subprocess.run(["codex", "login", "status"], capture_output=True, text=True, timeout=20)
        output = (login.stdout or "") + ("\n" + login.stderr if login.stderr else "")
        output = output.strip()
        if login.returncode == 0 and "not logged in" not in output.lower():
            add_result(results, "runtime:codex-login", True, output or "codex login status reported an authenticated session", "required")
        else:
            add_result(results, "runtime:codex-login", False, output or "codex login status did not report an authenticated session", "required")
    except Exception as exc:
        add_result(results, "runtime:codex-login", False, f"failed to run codex login status: {exc}", "required")

    path = Path(openclaw_config_path).expanduser()
    if not path.is_file():
        add_result(results, "runtime:acpx-plugin", False, f"missing file: {path}", "required")
        return results
    try:
        data = json.loads(path.read_text())
    except Exception as exc:
        add_result(results, "runtime:acpx-plugin", False, f"could not parse OpenClaw config JSON at {path}: {exc}", "required")
        return results

    acp = data.get("acp") if isinstance(data, dict) else None
    plugins = data.get("plugins") if isinstance(data, dict) else None
    entries = plugins.get("entries") if isinstance(plugins, dict) else None
    acpx_entry = entries.get("acpx") if isinstance(entries, dict) else None
    backend = acp.get("backend") if isinstance(acp, dict) else None
    acp_enabled = acp.get("enabled") if isinstance(acp, dict) else None
    acpx_enabled = acpx_entry.get("enabled") if isinstance(acpx_entry, dict) else None

    if backend == "acpx" and acp_enabled is True and acpx_enabled is True:
        add_result(results, "runtime:acpx-plugin", True, f"OpenClaw ACP backend is acpx and plugins.entries.acpx.enabled is true in {path}", "required")
    else:
        add_result(results, "runtime:acpx-plugin", False, f"Codex runtime requires ACP backend acpx plus plugins.entries.acpx.enabled=true in {path}; found acp.enabled={acp_enabled!r}, acp.backend={backend!r}, acpx.enabled={acpx_enabled!r}", "required")

    return results


def check_systemd_user_instance() -> tuple[bool, str]:
    try:
        result = subprocess.run(
            ["systemctl", "--user", "status", "--no-pager"],
            capture_output=True,
            text=True,
            timeout=10,
        )
    except Exception as exc:
        return False, f"failed to run systemctl --user status: {exc}"

    if result.returncode == 0:
        return True, "systemctl --user is available in this shell/session"

    detail = (result.stderr or result.stdout or "systemctl --user returned a non-zero exit code").strip()
    detail += " Common fix on headless Linux: run 'loginctl enable-linger $(whoami)', start a fresh login shell, then retry."
    return False, detail


def inspect_gateway_hook_token_sources(target_home: str) -> tuple[bool, str, str]:
    dropin_dir = Path(target_home).expanduser() / ".config/systemd/user/openclaw-gateway.service.d"
    if not dropin_dir.is_dir():
        return True, f"no gateway drop-in directory at {dropin_dir}", "warning"

    sources: list[tuple[str, str]] = []
    for path in sorted(dropin_dir.glob("*.conf")):
        try:
            for raw_line in path.read_text().splitlines():
                line = raw_line.strip()
                if "OPENCLAW_HOOKS_TOKEN=" not in line:
                    continue
                token = line.split("OPENCLAW_HOOKS_TOKEN=", 1)[1].strip().strip('"')
                if token:
                    sources.append((path.name, token))
        except Exception as exc:
            return False, f"failed reading {path}: {exc}", "warning"

    if not sources:
        return True, f"no OPENCLAW_HOOKS_TOKEN entries found in {dropin_dir}", "warning"

    source_files = ", ".join(name for name, _ in sources)
    distinct_tokens = {token for _, token in sources}
    if len(sources) > 1 and len(distinct_tokens) > 1:
        return False, f"conflicting OPENCLAW_HOOKS_TOKEN values found across: {source_files}", "required"
    if len(sources) > 1:
        return False, f"multiple OPENCLAW_HOOKS_TOKEN sources found across: {source_files}", "warning"
    return True, f"single OPENCLAW_HOOKS_TOKEN source found in {source_files}", "warning"


def add_result(results: list[dict[str, str | bool]], label: str, ok: bool, detail: str, severity: str) -> None:
    results.append({
        "label": label,
        "ok": ok,
        "detail": detail,
        "severity": severity,
    })


def can_bind_local_port(port: int) -> tuple[bool, str]:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        sock.bind(("127.0.0.1", port))
    except OSError as exc:
        return False, str(exc)
    finally:
        sock.close()
    return True, f"127.0.0.1:{port} appears available"



def find_available_port(start_port: int, end_port: int = 18950) -> int | None:
    for port in range(start_port, end_port + 1):
        ok, _ = can_bind_local_port(port)
        if ok:
            return port
    return None


def discover_hooks_token_from_dropins(target_home: str) -> tuple[str | None, str | None, str | None]:
    dropin_dir = Path(target_home).expanduser() / ".config/systemd/user/openclaw-gateway.service.d"
    if not dropin_dir.is_dir():
        return None, None, None

    sources: list[tuple[str, str]] = []
    for path in sorted(dropin_dir.glob("*.conf")):
        try:
            for raw_line in path.read_text().splitlines():
                line = raw_line.strip()
                if "OPENCLAW_HOOKS_TOKEN=" not in line:
                    continue
                token = line.split("OPENCLAW_HOOKS_TOKEN=", 1)[1].strip().strip('"')
                if token and token != "REPLACE_ME":
                    sources.append((path.name, token))
        except Exception as exc:
            return None, None, f"failed reading {path}: {exc}"

    if not sources:
        return None, None, None

    distinct_tokens = {token for _, token in sources}
    source_files = ", ".join(name for name, _ in sources)
    if len(distinct_tokens) > 1:
        return None, None, f"conflicting OPENCLAW_HOOKS_TOKEN values found across: {source_files}"
    return sources[0][1], f"gateway systemd drop-in ({source_files})", None


def discover_hooks_token(openclaw_config_path: str, target_home: str) -> tuple[str | None, str | None, str | None]:
    path = Path(openclaw_config_path).expanduser()
    if path.is_file():
        try:
            data = json.loads(path.read_text())
        except Exception as exc:
            return None, None, f"failed reading {path}: {exc}"

        candidates = [
            (data.get("hooks", {}).get("token") if isinstance(data.get("hooks"), dict) else None, f"{path} hooks.token"),
            (data.get("server", {}).get("hooksToken") if isinstance(data.get("server"), dict) else None, f"{path} server.hooksToken"),
        ]

        for value, source in candidates:
            if isinstance(value, str) and value.strip() and value.strip() != "REPLACE_ME":
                return value.strip(), source, None

    token, source, warning = discover_hooks_token_from_dropins(target_home)
    if token:
        return token, source, warning
    if warning:
        return None, None, warning

    env_token = os.environ.get("OPENCLAW_HOOKS_TOKEN", "").strip()
    if env_token and env_token != "REPLACE_ME":
        return env_token, "current shell environment OPENCLAW_HOOKS_TOKEN", None

    return None, None, None


def emit_text(result: dict[str, str | bool]) -> None:
    ok = bool(result["ok"])
    severity = str(result["severity"])
    prefix = "PASS" if ok else ("WARN" if severity == "warning" else "FAIL")
    print(f"[{prefix}] {result['label']}: {result['detail']}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Preflight checks for the BasicOps replication bundle")
    parser.add_argument("--target-home", help="Target home directory. Defaults to the current user's home.")
    parser.add_argument("--wrapper-path")
    parser.add_argument("--preack-webhook-path")
    parser.add_argument("--openclaw-config-path")
    parser.add_argument("--personas-config-path")
    parser.add_argument("--self-context-dir")
    parser.add_argument("--hooks-token", default="REPLACE_ME")
    parser.add_argument("--runtime", default="same-as-main", help="Desired agent runtime, for example same-as-main, codex, claude-code, pi, opencode, gemini-cli")
    parser.add_argument("--service-manager", choices=["auto", "systemd", "launchd"], default="auto")
    parser.add_argument("--shim-port", type=int)
    parser.add_argument("--json", action="store_true", dest="json_mode")
    args = parser.parse_args()

    default_target_home = detect_default_target_home()
    target_home = (args.target_home or default_target_home).rstrip("/") or default_target_home
    platform_name = detect_platform_name()
    service_manager = resolve_service_manager(args.service_manager, platform_name)
    bundle_root = Path(__file__).resolve().parent.parent
    wrapper_path = args.wrapper_path or str(bundle_root / "scripts" / "basicops_mcp.py")
    preack_webhook_path = args.preack_webhook_path or str(bundle_root / "scripts" / "preack_webhook.py")
    openclaw_config_path = args.openclaw_config_path or f"{target_home}/.openclaw/openclaw.json"
    personas_config_path = args.personas_config_path or f"{target_home}/.config/basicops-agents/basicops-personas.json"
    self_context_dir = args.self_context_dir or f"{target_home}/.cache/basicops-agents"

    results: list[dict[str, str | bool]] = []

    for binary in REQUIRED_BINARIES:
        ok, detail = check_binary(binary)
        add_result(results, f"binary:{binary}", ok, detail, "required")

    if service_manager == "systemd":
        ok, detail = check_binary("systemctl")
        add_result(results, "service-manager:systemd", ok, detail, "required")
        if ok:
            ok, detail = check_systemd_user_instance()
            add_result(results, "service-manager:systemd-user-instance", ok, detail, "required")
    else:
        ok, detail = check_binary("launchctl")
        add_result(results, "service-manager:launchd", ok, detail, "required")

    ok, detail = check_file(wrapper_path)
    add_result(results, "basicops wrapper", ok, detail, "required")

    ok, detail = check_file(preack_webhook_path)
    add_result(results, "preack webhook", ok, detail, "required")

    ok, detail = check_file(openclaw_config_path)
    add_result(results, "openclaw config", ok, detail, "required")

    ok, detail = check_file(personas_config_path)
    if not ok:
        detail += (
            f". This does not have to exist before scaffolding, but get-self-context and live hook apply/validation will fail until it exists. "
            f"You can start from {bundle_root / 'examples' / 'basicops-personas.example.json'}"
        )
    add_result(results, "basicops personas config", ok, detail, "warning")

    discovered_hooks_token, discovered_hooks_token_source, hooks_token_discovery_warning = discover_hooks_token(openclaw_config_path, target_home)
    effective_hooks_token = args.hooks_token if args.hooks_token != "REPLACE_ME" else (discovered_hooks_token or "REPLACE_ME")
    hooks_token_ok = effective_hooks_token != "REPLACE_ME"
    if args.hooks_token != "REPLACE_ME":
        hooks_token_detail = "hooks token provided via --hooks-token"
    elif hooks_token_ok and discovered_hooks_token_source:
        hooks_token_detail = f"hooks token found via {discovered_hooks_token_source}"
    else:
        hooks_token_detail = (
            f"OPENCLAW_HOOKS_TOKEN is still REPLACE_ME and no token was discovered in {openclaw_config_path}, gateway drop-ins, or the current shell environment. "
            "That is okay at preflight time. Guided setup can still scaffold files, but live hook validation will need a real token later."
        )
        if hooks_token_discovery_warning:
            hooks_token_detail += f" Note: {hooks_token_discovery_warning}"
    add_result(results, "hooks token", hooks_token_ok, hooks_token_detail, "warning")

    ok, detail = check_dir(self_context_dir)
    add_result(results, "self-context dir", ok, detail, "warning")

    if service_manager == "systemd":
        ok, detail, severity = inspect_gateway_hook_token_sources(target_home)
        add_result(results, "gateway hooks token sources", ok, detail, severity)
    else:
        add_result(
            results,
            "gateway hooks token sources",
            True,
            "skipped drop-in inspection on launchd. Hooks token discovery currently uses OpenClaw config or OPENCLAW_HOOKS_TOKEN in the shell.",
            "warning",
        )

    if args.runtime in INHERITED_RUNTIME_CHOICES:
        ok, detail = inspect_inherited_runtime(openclaw_config_path)
        add_result(results, "runtime:same-as-main", ok, detail, "required")
    elif args.runtime == "codex":
        results.extend(inspect_codex_runtime(openclaw_config_path))
    else:
        runtime_bins = OPTIONAL_RUNTIME_BINARIES.get(args.runtime, [args.runtime])
        runtime_found = False
        for candidate in runtime_bins:
            ok, detail = check_binary(candidate)
            runtime_hint = OPTIONAL_RUNTIME_INSTALL_HINTS.get(args.runtime)
            if not ok and runtime_hint:
                detail = f"{detail}. {runtime_hint}"
            add_result(results, f"runtime:{candidate}", ok, detail, "required")
            if ok:
                runtime_found = True
        if not runtime_found:
            desired_runtime_detail = f"runtime '{args.runtime}' is not currently available on PATH"
            runtime_hint = OPTIONAL_RUNTIME_INSTALL_HINTS.get(args.runtime)
            if runtime_hint:
                desired_runtime_detail += f". {runtime_hint}"
            add_result(results, f"desired runtime:{args.runtime}", False, desired_runtime_detail, "required")

    suggested_port = None
    if args.shim_port is not None:
        ok, detail = can_bind_local_port(args.shim_port)
        if ok:
            add_result(results, "shim port", True, detail, "required")
        else:
            suggested_port = find_available_port(max(1024, args.shim_port + 1))
            suggestion_text = f" Next available port suggestion: {suggested_port}" if suggested_port is not None else " No open replacement port found in the scanned range."
            add_result(results, "shim port", False, f"127.0.0.1:{args.shim_port} is not available: {detail}.{suggestion_text}", "required")

    required_failures = sum(1 for r in results if not r["ok"] and r["severity"] == "required")
    warning_failures = sum(1 for r in results if not r["ok"] and r["severity"] == "warning")

    summary = {
        "targetHome": target_home,
        "platform": platform_name,
        "serviceManager": service_manager,
        "runtime": args.runtime,
        "requiredFailures": required_failures,
        "warnings": warning_failures,
        "ok": required_failures == 0,
        "results": results,
        "suggestedShimPort": suggested_port,
    }

    if args.json_mode:
        print(json.dumps(summary, indent=2))
    else:
        print("BasicOps replication bundle preflight")
        print(f"Target home: {target_home}")
        print(f"Platform: {platform_name}")
        print(f"Service manager: {service_manager}")
        print(f"Desired runtime: {args.runtime}")
        print()

        for result in results:
            emit_text(result)

        print()
        print(f"Required failures: {required_failures}")
        print(f"Warnings: {warning_failures}")

        if required_failures:
            print("Preflight failed. Fix the FAIL items before attempting live setup.")
            if warning_failures:
                print("You should also review the WARN items.")
        elif warning_failures:
            print("Preflight passed with warnings. You can continue, but review the WARN items.")
        else:
            print("Preflight passed. The machine looks ready for scaffold + guided setup.")

    return 1 if required_failures else 0


if __name__ == "__main__":
    sys.exit(main())
