# Release Notes

## 2026-04-22

This bundle was updated after live install feedback from a fresh-server test.

### Fixed

- When the bundle registers the first explicit non-main agent on a fresh OpenClaw install, it now also seeds a safe default `main` agent.
  - This prevents the web control panel from breaking with errors like `Agent "main" no longer exists in configuration`.
- For Codex-backed ACP agents, the generated hook mapping now pins:
  - `openai-codex/gpt-5.4`
  - This prevents webhook runs from falling back to `openai/gpt-5.4` on machines authenticated through Codex OAuth.

### Improved

- Guided setup now states more clearly that:
  - a timestamped backup of `~/.openclaw/openclaw.json` is created before agent registration changes, unless explicitly disabled
  - a default `main` agent may be seeded on the first explicit non-main registration
- Bundle docs now explain the backup behavior and the Codex hook-model pinning more explicitly.
- Guided setup and scaffolding now prefer the actual OpenClaw gateway port from `~/.openclaw/openclaw.json` (`gateway.port`) instead of assuming `18789`.
- Generated precheck helpers now export the shell variables that their embedded Python snippets expect.
- Generated service files now use the Python interpreter that ran scaffolding, instead of hardcoding `/usr/bin/python3`.
- Bundle helper subprocesses now prefer `sys.executable` so macOS launchd runs stay on the same Python interpreter.

### Packaging recommendation

Keep `START-HERE.md` inside the bundle, but also distribute a small external bootstrap note alongside the tarball so users can see unpack instructions before extraction.
