# AI Operator Guide

This file is for OpenClaw or another advanced helper.

The human operator using this bundle may be a novice with limited Linux knowledge.
Prefer doing safe validation work directly instead of making the human interpret logs or infer what a failure means.

## Primary rule

Favor:

- short instructions
- direct validation
- one checkpoint at a time
- plain language
- copy/paste commands

Avoid making the human reason about:

- reverse proxy theory
- TLS internals
- systemd details
- hook mapping structure

unless they must make a real decision.

## Default execution rule

Do every safe local install action you can do yourself.

Do not hand the human shell commands for local file edits, persona updates, config writes, service starts, hook applies, routing tests, or reverse-proxy edits when you can perform those actions directly.

Default exceptions:

- the human still has to do upstream BasicOps-side account creation and API key generation if those do not already exist
- the human still has to run `openclaw gateway restart`
- if the environment requires approval or elevation for a privileged change, ask for that approval instead of asking the human to do the change manually
- if `openclaw gateway restart` reports failure quickly, do not assume the gateway is actually down yet. On slower hosts the CLI can time out before the gateway is ready. Wait about 30 seconds, then check `openclaw gateway status` before deciding the restart really failed.

## Files to read first

1. the generated `NEXT-STEPS.md` for the target agent
2. `START-HERE.md`
3. `README.md`
4. `docs/INSTALL.md` only when more detail is needed

If the generated install prompt starts with lines like these, treat them as hard guardrails:

- `TARGET AGENT: <agent-id>`
- `READ ONLY: generated/<agent-id>/NEXT-STEPS.md`

Do not switch to another agent's generated folder unless the human explicitly tells you to.

## What you should collect early

Confirm these values before deeper troubleshooting:

- agent id
- BasicOps profile
- hook path
- shim port
- expected public hostname
- chosen runtime CLI
- generated file directory

## Installation strategy

### If the human is starting from scratch and wants you involved from the first step

Prefer a narrow novice path:

1. ask only for the agent id unless the human already volunteered more values
2. choose safe defaults for everything else
3. run guided setup in non-interactive mode first
4. then read the generated `NEXT-STEPS.md` and continue from there

Default assumptions for this first-pass path:

- display name: default from agent id
- BasicOps profile: same as agent id
- hook path: `basicops-<agent-id>`
- runtime: `codex` unless the human clearly asked for something else
- hooks token: allow guided setup to generate one if missing

Preferred first command for this novice path:

```bash
python3 ~/basicops-agent-bundle/scripts/guided_setup_agent.py --agent-id <agent-id> --runtime codex --non-interactive --generate-hooks-token-if-missing
```

Do not jump straight into broader live mutations from memory. Scaffold first, read the generated output, then continue with one checkpoint at a time.

Use this order:

1. prerequisites exist
2. guided setup completed
3. generated files exist
4. agent registration is correct
5. hook config is correct
6. local shim service is running
7. local smoke test passes
8. reverse proxy is configured correctly
9. public smoke test passes
10. BasicOps webhook points to the correct public URL

Do not skip straight to public webhook debugging when local validation is still failing.

## Validation checkpoints

### 1. Prerequisites

Check:

```bash
python3 --version
openclaw status
mcporter --version
codex --version
```

If something is missing, stop and handle that first.

If `mcporter` is missing, install it with:

```bash
sudo npm install -g mcporter
mcporter --version
```

If `codex` is missing, install it with:

```bash
npm install -g @openai/codex
codex --version
```

If the Codex install fails with a permissions error, retry with:

```bash
sudo npm install -g @openai/codex
codex --version
```

If `codex --version` works but Codex still needs login/auth, finish that before continuing.

### 2. Guided setup output

Confirm the generated directory exists and contains the expected files.
At minimum, check for:

- `NEXT-STEPS.md`
- `<agent-id>.env`
- `basicops-preack@.service` or the matching launchd plist
- `<agent-id>.openclaw-agent.json`

### 3. Agent registration

Confirm the target agent exists in `agents.list` in `openclaw.json`.
If it does not, fix that before hook apply.

For ACP agents, validate this exact shape:

- `runtime.type = acp`
- `runtime.acp.cwd = <workspace>`

Do not put the working directory under `runtime.cwd` for ACP agents.

### 4. Hook config

Confirm these line up:

- agent id
- BasicOps profile
- hook path
- `OPENCLAW_FORWARD_URL`
- public webhook path

If local hook ingress fails, inspect `hooks.enabled`, `hooks.path`, and `hooks.token` before moving on.

### 4.5. Gateway restart boundary

If the installer restarts the OpenClaw gateway, treat that as a state boundary.

Before suggesting another restart:

- verify whether the restart already happened
- verify whether the gateway is already healthy again
- verify whether the next step is now local precheck, hook apply, service start, reverse proxy, or smoke test

If the human returns after a restart and says "continue" or similar, do not assume the restart still needs doing. Check first, then resume from the next unfinished step.

If the generated folder includes `AFTER-GATEWAY-RESTART.txt`, it can help re-anchor the resumed session context, but it is optional. Use it when the original session stalled or lost the install state.

If the human says the restart command printed something like "Gateway restart failed after 14s", treat that as ambiguous, not final. First wait about 30 seconds and run `openclaw gateway status`. If the gateway is healthy, continue without asking for another restart.

Default resume rule for this bundle:

- after the gateway restart step, resume at the strict read-only config check unless current checks prove a later step is already complete
- prefer `openclaw gateway status` plus `./CHECK-READONLY.sh` as the first two post-restart checks

### 5. Shim service

On Linux, validate the user service:

```bash
systemctl --user status basicops-preack@<agent-id>.service --no-pager
journalctl --user -u basicops-preack@<agent-id>.service -n 50 --no-pager
```

Confirm the expected port is listening.

### 6. Reverse proxy

Prefer Caddy unless the machine is already clearly using Traefik.

Detect early whether the machine already has a proxy in place. Adding one route to an existing Caddy install is much safer than treating the machine like a fresh proxy install.

If the needed Caddy change is straightforward and you have access, update `/etc/caddy/Caddyfile` yourself instead of telling the human to do the edit manually. Show the planned diff or exact block when useful, ask for approval only if the environment requires it, then run validation and reload after the change.

For Caddy, always validate:

- the full public hostname is used, not the short machine name
- the webhook path matches the generated hook path
- the reverse proxy target matches the shim port
- certificate issuance is happening for the full FQDN

### 7. Public validation

Do not call the setup complete until both of these work:

- local smoke test
- public HTTPS smoke test

### 8. BasicOps agent connection and identity safety

Do not ask the human to create the BasicOps webhook with raw curl if the configured BasicOps MCP profile is already available.

Hard safety rule for install and repair work:

- If any visible first-class BasicOps tools whose names start with `basicops-` are available, do not use them for identity checks, webhook checks, or registration during install unless the human explicitly instructs you to. You may mention them briefly if relevant, but do not stop just because they are visible.
- Treat ambient session-level tools like `mcp__codex_apps__basicops_*` the same way: do not use them during install unless the human explicitly instructs you to, and do not treat their presence as evidence that the target machine already has local BasicOps credentials configured.
- For BasicOps identity and webhook work on the target machine, use only the bundled wrapper/helper on that machine, for example `python3 ~/basicops-agent-bundle/scripts/basicops_mcp.py --as <profile> ...`.
- If `~/.config/basicops-agents/basicops-personas.json` does not exist yet or the intended profile is missing, ask the human only for the missing API key if needed, then create or update the file yourself. Do not make the human edit it manually.
- If the BasicOps agent user does not exist yet, if no API key has been created for it yet, or if `mcporter` is not installed, stop and say that plainly. Do not fall back to any other ambient BasicOps auth.

Prefer the MCP-backed path:

1. call `get_current_user` through the intended BasicOps profile
2. call `list_webhooks` through that same profile
3. verify any exact matching webhook uses the same `UserId` as `get_current_user.id`
4. warn if the BasicOps `firstName` looks unrelated to the intended agent id
5. register the agent through `connect_agent` only after identity and public route checks look sane
6. verify again with `list_webhooks`

If the generated bundle includes `scripts/ensure_basicops_webhook.py`, prefer using it.

Important interpretation rule:

- hard concern: exact webhook URL exists under a different BasicOps user id
- soft concern: agent id is `odin`, but `get_current_user.firstName` looks like `Thor`

On the soft concern, stop and ask the human whether the identity is intentional before proceeding.

## Common failure patterns

### Wrong hostname in proxy config

Symptom:
- TLS fails
- Caddy or Traefik tries to issue for `srv1605924` instead of `srv1605924.example.com`

Interpretation:
- the proxy is configured with the short hostname instead of the full FQDN

### Hook path mismatch

Symptom:
- local service is running
- public request reaches proxy
- request still does not reach the target agent

Interpretation:
- proxy path, shim env, and hook mapping are not aligned

### Wrong shim port

Symptom:
- reverse proxy seems present
- request still fails before reaching OpenClaw

Interpretation:
- proxy is pointing at the wrong local port or the service is not listening on the expected port

### Missing live hooks token

Symptom:
- local hook curl fails even though the service and proxy look healthy

Interpretation:
- `hooks.token` is missing, wrong, or mismatched

## Interaction rules

- keep the human focused on the next single action
- do not dump multiple branches at once unless a real choice is needed
- if the environment is obviously wrong, say so plainly
- do not ask the human to manually inspect logs if you can inspect them yourself
- when something fails, explain what it means in one sentence
- if a safe check can settle uncertainty, run the check
- prefer generated helper scripts like `APPLY-LOCAL-FILES.sh`, `CHECK-READONLY.sh`, `START-LOCAL-SERVICE.sh`, `TEST-ROUTING.sh`, `VERIFY-LOCAL-WORKER.sh`, `VERIFY-BASICOPS-REGISTRATION.sh`, `VERIFY-END-TO-END.sh`, and the assistant-friendly `RUN-VERIFY-*` / `CHECK-VERIFY-*` pairs when present
- for focused OpenClaw agent authorization checks, use the generated `OPENCLAW-AGENT-SELFTEST.sh` helper and `CHECK-OPENCLAW-AGENT-SELFTEST.sh`. Do not extract and rerun the embedded raw `openclaw agent ...` command from inside verifier scripts.
- the self-test helper now also writes a deterministic `.openclaw-agent-selftest.<kind>.check.out` report. If a wrapped self-test run comes back with swallowed stdout, inspect that report first.
- treat the generated verifier `.result` files as the authoritative diagnosis layer. They are designed to answer what failed, why it likely failed, and what to fix next. Use the `.out` and `.direct.out` logs as supporting evidence, not the first summary.
- before trusting any OpenClaw tool card that says `No output — tool completed successfully`, run the generated `CHECK-OPENCLAW-NO-OUTPUT-HOTFIX.sh`. If it exits `20` with `STATE: needs-patch`, run `APPLY-OPENCLAW-NO-OUTPUT-HOTFIX.sh` before the next planned gateway restart so that same restart also picks up the hotfix.
- for the final verification phase in chat, do not disappear into one opaque verifier run without commentary. Prefer `RUN-VERIFY-LOCAL-WORKER.sh`, then `CHECK-VERIFY-LOCAL-WORKER.sh`, then the matching `RUN-VERIFY-BASICOPS-REGISTRATION.sh` / `CHECK-VERIFY-BASICOPS-REGISTRATION.sh`, then `RUN-VERIFY-END-TO-END.sh` / `CHECK-VERIFY-END-TO-END.sh`. The raw `VERIFY-...` scripts are still available for direct manual terminal use. If a runner is already active, the matching check script is the first place to look.
- if a shell tool ever reports `No output — tool completed successfully` for something that should obviously print, do not trust that summary. Treat it as a shell-output capture fault. Prefer reading the deterministic verifier result files first when a file-read tool is available: `.verify-local-worker.result`, `.verify-basicops-registration.result`, and `.verify-end-to-end.result`, then the corresponding `.status` / `.out` files.
- each `CHECK-VERIFY-*` run now also writes its full human-readable report to a deterministic `.check.out` file. If a delayed shell command swallows the checker's stdout, read the matching `.check.out` artifact directly.
- the generated raw `VERIFY-...` scripts now auto-delegate to the matching `RUN-VERIFY-...` plus `CHECK-VERIFY-...` flow when launched from a non-interactive shell unless both `BASICOPS_FORCE_DIRECT_VERIFY=1` and `BASICOPS_ALLOW_NONINTERACTIVE_DIRECT_VERIFY=1` are set. That makes it much harder for an assistant to accidentally force the fragile direct path.
- do not set `BASICOPS_FORCE_DIRECT_VERIFY=1` unless the human explicitly asks for a direct verifier diagnostic. In non-interactive shells, that flag alone is no longer enough to bypass the safer async path, and the second escape hatch `BASICOPS_ALLOW_NONINTERACTIVE_DIRECT_VERIFY=1` should be reserved for deliberate deep diagnostics. If direct mode was forced anyway, inspect the deterministic direct-mode files: `.verify-local-worker.direct.out`, `.verify-local-worker.direct.exit`, `.verify-basicops-registration.direct.out`, `.verify-basicops-registration.direct.exit`, `.verify-end-to-end.direct.out`, and `.verify-end-to-end.direct.exit`.
- if direct mode was forced anyway, also inspect the matching `.direct.check.out` artifact. The raw verifier now writes a human-readable direct-mode summary there so you do not have to infer state from swallowed shell output.
- do not use a standalone raw `openclaw status` or `openclaw agent` shell call as proof in this environment. Let the verifier scripts own those checks, or redirect the raw command to a file and inspect the file if you truly need a separate probe.
- `CHECK-VERIFY-*` returning exit `10` means `still running`, not `failed`. That is expected while the background verifier is active, and 60 seconds can be too soon because the worker verifier includes a direct self-test with `--timeout 120`.
- `CHECK-VERIFY-*` returning exit `12` means the verifier bookkeeping went stale: the `.status` file still said `running`, but there was no live verifier process anymore. In that case, rerun the matching `RUN-VERIFY-*` script to refresh the official artifacts before continuing.
- if a verifier's `.result` file already says `state=pass`, trust that completion even if an outer shell wrapper looked stuck or the old `.status` bookkeeping was incomplete. The newer checker logic is designed to reconcile that automatically.
- do not wrap checker calls in shell one-liners like `sleep 150; ./CHECK-VERIFY-...` when your tool already supports waiting or polling. Wait with the tool, then run the checker directly. If someone does use a delayed shell wrapper anyway, the matching `.check.out` file is the fallback artifact to inspect.
- do not prepend manual wrappers like `timeout 240 env BASICOPS_FORCE_DIRECT_VERIFY=1 BASICOPS_ALLOW_NONINTERACTIVE_DIRECT_VERIFY=1 ./VERIFY-...` when the generated scripts already provide the safer flow. If someone forces that path anyway, use the matching `.direct.check.out` artifact as the first fallback.
- do not prepend manual wrappers like `timeout 160 env OPENCLAW_AGENT_... ./OPENCLAW-AGENT-SELFTEST.sh` when the generated helper already gives you deterministic artifacts. If someone forces that path anyway, use the matching `.openclaw-agent-selftest.<kind>.check.out` artifact as the first fallback.
- when a verifier finishes with a non-zero exit, read its `.result` file before improvising repairs. The intent is scripted evidence plus assistant-driven repair, not blind re-running.
- if the final verifier appears to still be running after about 3 minutes with no new output, inspect live child processes before assuming the script is still active
- prefer MCP-backed webhook verification/creation over asking the human to paste an API-key curl command

## Approval rules

Ask before:

- destructive file changes
- removing existing proxy config
- restarting or disabling unrelated services
- public-facing changes that may affect other routes

## Completion criteria

The install is only really done when:

- the agent is registered
- the hook mapping is live
- the shim service is active
- local smoke test passes
- public HTTPS test passes
- the BasicOps webhook destination matches the public route
