#!/usr/bin/env bash
set -euo pipefail

echo 'TARGET AGENT: thor'
echo 'Installing live files for thor...'
mkdir -p ~/.config/basicops-agents ~/.config/systemd/user /home/hjhlarsen/.cache/basicops-agents /home/hjhlarsen/.config/systemd/user/openclaw-gateway.service.d /home/hjhlarsen/.openclaw/hooks/transforms
install -m 0644 /tmp/thor-bundle-test-packaged/thor.env /home/hjhlarsen/.config/basicops-agents/thor.env
install -m 0644 /tmp/thor-bundle-test-packaged/basicops-preack@.service /home/hjhlarsen/.config/systemd/user/basicops-preack@.service
install -m 0644 /tmp/thor-bundle-test-packaged/thor-structured-runtime-hook.js /home/hjhlarsen/.openclaw/hooks/transforms/thor-structured-runtime-hook.js
systemctl --user daemon-reload
test -f /home/hjhlarsen/.config/basicops-agents/thor.env && echo 'PASS live env exists: /home/hjhlarsen/.config/basicops-agents/thor.env' || (echo 'FAIL live env missing: /home/hjhlarsen/.config/basicops-agents/thor.env' && exit 1)
test -f /home/hjhlarsen/.config/systemd/user/basicops-preack@.service && echo 'PASS live service exists: /home/hjhlarsen/.config/systemd/user/basicops-preack@.service' || (echo 'FAIL live service missing: /home/hjhlarsen/.config/systemd/user/basicops-preack@.service' && exit 1)
test -f /home/hjhlarsen/.openclaw/hooks/transforms/thor-structured-runtime-hook.js && echo 'PASS live transform exists: /home/hjhlarsen/.openclaw/hooks/transforms/thor-structured-runtime-hook.js' || (echo 'FAIL live transform missing: /home/hjhlarsen/.openclaw/hooks/transforms/thor-structured-runtime-hook.js' && exit 1)
