# BasicOps Agent Bundle Handoff

Use this file if you are the person receiving this bundle.

If you are a novice user, do not start with the long manual guide.
Start with:

- `START-HERE.md`
- `INSTALL-WITH-OPENCLAW.md`

## Goal

Set up a new BasicOps-backed OpenClaw agent on a target machine without guessing.

## What this bundle contains

- `QUICKSTART.md` for the fastest safe path
- `docs/INSTALL.md` for the full manual guide
- `scripts/` for preflight, scaffolding, and hook rendering
- `templates/` for the reusable env, service, and policy files
- `examples/` for sample values and config patterns

This bundle does **not** contain live secrets or pre-generated agent output.
Generate fresh agent-specific files on the target machine.

## First 10 minutes

Recommended path for most operators:

1. Read `START-HERE.md`
2. If the machine already has OpenClaw running, use `INSTALL-WITH-OPENCLAW.md`
3. Only use the manual path if you are comfortable doing the setup yourself

Manual path reference steps:

1. Unpack the tarball on the target machine:

```bash
mkdir -p ~/basicops-agent-bundle
tar -xzf basicops-agent-replication-bundle.tar.gz -C ~/basicops-agent-bundle --strip-components=1
```

2. Check the basics:

```bash
openclaw status
python3 --version
mcporter --version
systemctl --user status --no-pager
```

3. Make sure the target machine already has:
- OpenClaw running
- the BasicOps MCP wrapper on disk
- the pre-ack webhook shim on disk
- your chosen runtime installed, for example Codex or Claude Code

4. If this is a brand new BasicOps persona, do the BasicOps-side setup first:
- create the agent user if needed
- create its API key
- add that API key to `~/.config/basicops-agents/basicops-personas.json`
- if your setup uses direct MCP server entries, add the matching `basicops-<agent>` entry too

5. Run the guided setup helper:

Important: this helper does not install prerequisites for you. The target machine still needs `openclaw`, `mcporter`, and the chosen runtime CLI, for example `codex`, installed first.

Common beginner setup example:

```bash
sudo npm install -g mcporter
npm install -g @openai/codex
mcporter --version
codex --version
```

If the Codex install fails with a permissions error, retry with:

```bash
sudo npm install -g @openai/codex
codex --version
```

If `codex --version` works but Codex still needs login/auth, finish that before continuing.

```bash
python3 ~/basicops-agent-bundle/scripts/guided_setup_agent.py \
  --agent-id helper \
  --runtime codex
```

Recommended interactive pattern: give it the agent id first, then let the helper suggest the remaining values.
`--target-home` now defaults to the current user's home automatically, so only add it when you intentionally want to install for a different Unix account.

6. Follow the generated `NEXT-STEPS.md` in order.

## Operator rules that prevent most mistakes

- Keep the agent id, BasicOps profile, and hook path consistent
- Give each agent its own shim port
- Give each agent its own public webhook path
- Make sure the reverse proxy path matches the webhook sender path
- Make sure `OPENCLAW_FORWARD_URL` points to the matching `/hooks/<hook-path>` target
- Do not leave `OPENCLAW_HOOKS_TOKEN` as `REPLACE_ME`
- Preview the hook summary before applying live changes

## Quick mental model

Request flow usually looks like this:

```text
BasicOps
  -> public webhook URL
  -> reverse proxy, for example Caddy
  -> local pre-ack shim on 127.0.0.1:<shim-port>
  -> OpenClaw hook URL on 127.0.0.1:18789/hooks/<hook-path>
  -> target OpenClaw agent
```

Example:

```text
https://YOUR_HOST_NAME/webhooks/basicops-helper
  -> 127.0.0.1:18894
  -> http://127.0.0.1:18789/hooks/basicops-helper
```

If those values do not line up, stop and fix them before testing.

## If you only read two files

Read these in order:
1. `START-HERE.md`
2. `INSTALL-WITH-OPENCLAW.md`

If you want the full manual flow after that, use:
- `docs/INSTALL.md`

## Known-good note

If you want the short version of what was validated before handoff, read:
- `VALIDATED-STATE.md`
