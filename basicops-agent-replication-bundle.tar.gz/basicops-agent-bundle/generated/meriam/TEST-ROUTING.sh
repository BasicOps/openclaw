#!/usr/bin/env bash
set -euo pipefail

DRY_RUN=0
for arg in "$@"; do
  case "$arg" in
    --dry-run) DRY_RUN=1 ;;
    *) echo "Unknown arg: $arg" >&2; exit 2 ;;
  esac
done

status=0
pass(){ printf '[PASS] %s\n' "$1"; }
fail(){ printf '[FAIL] %s\n' "$1"; status=1; }
warn(){ printf '[WARN] %s\n' "$1"; }

LOCAL_HOOK_URL="http://127.0.0.1:18789/hooks/basicops-meriam"
PUBLIC_WEBHOOK_URL="${PUBLIC_WEBHOOK_URL:-}"
OPENCLAW_CONFIG="/home/hjhlarsen/.openclaw/openclaw.json"
SMOKE_PAYLOAD='{"openclawInstallSmokeTest":true,"source":"replication-bundle"}'


echo 'TARGET AGENT: meriam'
echo 'READ ONLY: /home/hjhlarsen/basicops-agent-bundle/generated/meriam/NEXT-STEPS.md'
echo 'This script validates shim TCP reachability plus local/public hook routing only.'
echo 'It does not prove worker readiness or BasicOps reply posting.'

if (( DRY_RUN == 1 )); then
  echo "+ python3 shim TCP check for 127.0.0.1:18903"
  echo "+ curl local synthetic smoke payload to $LOCAL_HOOK_URL"
  if [[ -n "$PUBLIC_WEBHOOK_URL" ]]; then
    echo "+ curl public synthetic smoke payload to $PUBLIC_WEBHOOK_URL"
  fi
  exit 0
fi

if /usr/bin/python3 - <<'PY'
import socket, sys
s = socket.socket()
s.settimeout(1)
try:
    s.connect(('127.0.0.1', 18903))
except OSError as exc:
    print(f'[FAIL] shim TCP check failed for 127.0.0.1:18903: {exc}')
    sys.exit(1)
finally:
    s.close()
print('[PASS] shim TCP check passed for 127.0.0.1:18903')
PY
then
  :
else
  status=1
fi

HOOK_TOKEN="$(/usr/bin/python3 - <<'PY'
import json
from pathlib import Path
path = Path("/home/hjhlarsen/.openclaw/openclaw.json").expanduser()
if not path.is_file():
    print('')
    raise SystemExit(0)
data = json.loads(path.read_text())
hooks = data.get('hooks') if isinstance(data.get('hooks'), dict) else {}
value = hooks.get('token') if isinstance(hooks.get('token'), str) else ''
print(value.strip())
PY
)"
if [[ -z "$HOOK_TOKEN" ]]; then
  fail 'hooks.token missing in OpenClaw config'
else
  local_code=$(curl -o /tmp/basicops-routing-check.$$ -sS -w '%{http_code}' "$LOCAL_HOOK_URL" -H "Authorization: Bearer $HOOK_TOKEN" -H 'Content-Type: application/json' --data-binary "$SMOKE_PAYLOAD" || true)
  if [[ "$local_code" == "200" || "$local_code" == "204" ]]; then
    pass "local hook routing passes: $LOCAL_HOOK_URL (HTTP $local_code)"
  else
    fail "local hook routing failed at $LOCAL_HOOK_URL (HTTP $local_code)"
  fi
  rm -f /tmp/basicops-routing-check.$$
fi

if [[ -z "$PUBLIC_WEBHOOK_URL" ]]; then
  warn 'PUBLIC_WEBHOOK_URL not set, skipping public routing check'
elif [[ "$PUBLIC_WEBHOOK_URL" == *YOUR_HOST_NAME* ]]; then
  warn 'PUBLIC_WEBHOOK_URL still uses the placeholder host, skipping public routing check'
elif [[ -z "$HOOK_TOKEN" ]]; then
  fail 'public routing check skipped because hooks.token is missing in OpenClaw config'
else
  public_code=$(curl -o /tmp/basicops-routing-public.$$ -sS -w '%{http_code}' "$PUBLIC_WEBHOOK_URL" -H "Authorization: Bearer $HOOK_TOKEN" -H 'Content-Type: application/json' --data-binary "$SMOKE_PAYLOAD" || true)
  if [[ "$public_code" == "200" ]]; then
    pass "public hook routing passes: $PUBLIC_WEBHOOK_URL"
  else
    fail "public hook routing failed at $PUBLIC_WEBHOOK_URL (HTTP $public_code)"
  fi
  rm -f /tmp/basicops-routing-public.$$
fi

if [[ $status -eq 0 ]]; then
  echo 'RESULT: PASS. Routing checks passed.'
else
  echo 'RESULT: FAIL. Fix the routing layer above before moving on.'
fi
exit $status
