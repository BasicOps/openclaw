# Troubleshooting Checkpoints

Use this file when installation fails and you need to quickly decide what layer is broken.

## 1. Prerequisites

Check:

```bash
python3 --version
openclaw status
mcporter --version
codex --version
```

If one of these fails, stop here first.

## 2. Generated files

Check that the generated agent directory contains at least:

- `NEXT-STEPS.md`
- `<agent-id>.env`
- service file
- `<agent-id>.openclaw-agent.json`
- `install-context.json`
- `OPENCLAW-INSTALL-PROMPT.txt`

## 3. Agent registration

Failure signs:
- hook render says the agent is missing
- OpenClaw never routes to the target agent

Meaning:
- the agent is not present in `agents.list`

## 4. Hook config

Failure signs:
- local `/hooks/...` request returns `404`
- hook path looks right but OpenClaw does not answer

Meaning:
- hooks are not enabled, path/token is missing, or the hook path does not match

## 5. Shim service

Failure signs:
- reverse proxy points to a port with nothing listening
- service status is failed or inactive

Meaning:
- the local pre-ack shim is not running on the expected port

## 6. Reverse proxy

Failure signs:
- local hook works but public HTTPS route fails
- Caddy or Traefik logs mention the wrong hostname
- TLS handshake fails before HTTP routing

Meaning:
- proxy hostname, path, backend port, or certificate setup is wrong

## 7. Wrong hostname pattern

Classic example:
- proxy is issuing for `srv1605924`
- the real public hostname is `srv1605924.hstgr.cloud`

Meaning:
- the proxy config is using the short machine name instead of the FQDN

## 8. Public webhook

Failure signs:
- public curl fails but local validation passes

Meaning:
- DNS, TLS, firewall, or reverse-proxy routing is wrong

## 9. Slow tiny replies on the fast hook path

Failure signs:
- a trivial reply like "Are you there?" takes about 20s or more
- BasicOps reply posting itself is fast, but the agent command phase is much slower
- logs show a large reused OpenClaw session history for the same task/chat/project scope

Meaning:
- the generated fast hook is reusing a long-lived scope session, so even tiny replies pay for accumulated prompt history
- or the patch only hit the generated bundle copy while the gateway is still executing the live transform under `~/.openclaw/hooks/transforms/`

Default fix:
- prefer isolated per-invocation sessions for the fast hook path
- only reuse a scope session if you explicitly want continuity more than latency
- if the agent was already installed, patch the live transform copy too, not just the generated bundle file

Operator note:
- the current bundle now defaults the fast hook to isolated per-invocation sessions
- if you intentionally want the old behavior, set `BASICOPS_FAST_REUSE_SCOPE_SESSION=1` before running the hook runtime
- after changing the live transform file, restart the OpenClaw gateway before trusting timing results

## Debugging order

Always use this order:

1. prerequisites
2. generated files
3. agent registration
4. hook config
5. shim service
6. local smoke test
7. reverse proxy
8. public smoke test
9. BasicOps webhook destination

Do not start with BasicOps if the local checks are still failing.
