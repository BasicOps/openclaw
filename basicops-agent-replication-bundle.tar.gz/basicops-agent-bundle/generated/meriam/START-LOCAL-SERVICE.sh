#!/usr/bin/env bash
set -euo pipefail

DRY_RUN=0
for arg in "$@"; do
  case "$arg" in
    --dry-run) DRY_RUN=1 ;;
    *) echo "Unknown arg: $arg" >&2; exit 2 ;;
  esac
done
run() {
  printf '+ %s
' "$*"
  if (( DRY_RUN == 1 )); then
    return 0
  fi
  eval "$*"
}

echo 'TARGET AGENT: meriam'
echo 'READ ONLY: /home/hjhlarsen/basicops-agent-bundle/generated/meriam/NEXT-STEPS.md'
echo 'Starting local pre-ack service for meriam...'
echo 'This script only reloads the user service manager and starts the pre-ack service.'

run "systemctl --user daemon-reload"
run "systemctl --user enable --now basicops-preack@meriam.service"
run "systemctl --user status basicops-preack@meriam.service --no-pager"
run "journalctl --user -u basicops-preack@meriam.service -n 50 --no-pager"
