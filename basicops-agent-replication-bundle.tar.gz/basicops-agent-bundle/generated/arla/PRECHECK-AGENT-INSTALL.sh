#!/usr/bin/env bash
set -euo pipefail

status=0
pass(){ printf '[PASS] %s\n' "$1"; }
fail(){ printf '[FAIL] %s\n' "$1"; status=1; }
warn(){ printf '[WARN] %s\n' "$1"; }

echo 'TARGET AGENT: arla'
echo 'READ ONLY: /home/hjhlarsen/.openclaw/workspace-basicops/replication-bundle/generated/arla/NEXT-STEPS.md'

PERSONAS="/home/hjhlarsen/.config/basicops-agents/basicops-personas.json"
PROFILE="arla"
LIVE_ENV="/home/hjhlarsen/.config/basicops-agents/arla.env"
LIVE_SERVICE="/home/hjhlarsen/.config/systemd/user/basicops-preack@.service"
LIVE_TRANSFORM="/home/hjhlarsen/.openclaw/hooks/transforms/arla-hook-fast.js"
OPENCLAW_CONFIG="/home/hjhlarsen/.openclaw/openclaw.json"
EXPECTED_AGENT="arla"
EXPECTED_WORKSPACE="/home/hjhlarsen/.openclaw/workspace-arla"
EXPECTED_HOOK="basicops-arla"
LOCAL_HOOK_URL="http://127.0.0.1:18789/hooks/basicops-arla"

export PERSONAS PROFILE LIVE_ENV LIVE_SERVICE LIVE_TRANSFORM OPENCLAW_CONFIG EXPECTED_AGENT EXPECTED_WORKSPACE EXPECTED_HOOK LOCAL_HOOK_URL

[[ -f "$PERSONAS" ]] && pass "personas file exists: $PERSONAS" || fail "personas file missing: $PERSONAS"
/usr/bin/python3 - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ['PERSONAS']).expanduser()
profile = os.environ['PROFILE']
if not path.is_file():
    raise SystemExit(0)
try:
    data = json.loads(path.read_text())
except Exception as exc:
    print(f'[FAIL] personas file is not valid JSON: {exc}')
    raise SystemExit(2)
personas = data.get('personas') if isinstance(data, dict) else None
if isinstance(personas, dict) and profile in personas:
    print(f'[PASS] target persona profile exists: {profile}')
else:
    print(f'[FAIL] target persona profile missing: {profile}')
    raise SystemExit(1)
PY
rc=$?
if [[ $rc -eq 1 || $rc -eq 2 ]]; then status=1; fi
[[ -f "$LIVE_ENV" ]] && pass "live env copied: $LIVE_ENV" || fail "live env missing: $LIVE_ENV"
[[ -f "$LIVE_SERVICE" ]] && pass "live service copied: $LIVE_SERVICE" || fail "live service missing: $LIVE_SERVICE"
[[ -f "$LIVE_TRANSFORM" ]] && pass "live transform copied: $LIVE_TRANSFORM" || fail "live transform missing: $LIVE_TRANSFORM"
/usr/bin/python3 - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ['OPENCLAW_CONFIG']).expanduser()
agent_id = os.environ['EXPECTED_AGENT']
expected_workspace = os.environ['EXPECTED_WORKSPACE']
if not path.is_file():
    print(f'[FAIL] OpenClaw config missing: {path}')
    raise SystemExit(1)
try:
    data = json.loads(path.read_text())
except Exception as exc:
    print(f'[FAIL] OpenClaw config is not valid JSON: {exc}')
    raise SystemExit(1)
agent_list = data.get('agents', {}).get('list', []) if isinstance(data, dict) else []
agent = None
for item in agent_list:
    if isinstance(item, dict) and item.get('id') == agent_id:
        agent = item
        break
if not agent:
    print(f'[FAIL] agent not registered in agents.list: {agent_id}')
    raise SystemExit(1)
runtime = agent.get('runtime') if isinstance(agent.get('runtime'), dict) else {}
acp = runtime.get('acp') if isinstance(runtime.get('acp'), dict) else {}
if runtime.get('type') != 'acp':
    print(f'[FAIL] runtime.type is not acp for agent: {agent_id}')
    raise SystemExit(1)
if agent.get('workspace') != expected_workspace:
    print(f'[FAIL] workspace mismatch for agent: expected {expected_workspace}, found {agent.get("workspace")}')
    raise SystemExit(1)
if runtime.get('cwd'):
    print('[FAIL] runtime.cwd is set. For ACP agents, cwd must live under runtime.acp.cwd, not runtime.cwd.')
    raise SystemExit(1)
if acp.get('cwd') != expected_workspace:
    print(f'[FAIL] runtime.acp.cwd mismatch: expected {expected_workspace}, found {acp.get("cwd")}')
    raise SystemExit(1)
print(f'[PASS] agent registered with valid ACP runtime block: {agent_id}')
PY
rc=$?
if [[ $rc -ne 0 ]]; then status=1; fi
/usr/bin/python3 - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ['OPENCLAW_CONFIG']).expanduser()
hook_path = os.environ['EXPECTED_HOOK']
agent_id = os.environ['EXPECTED_AGENT']
if not path.is_file():
    raise SystemExit(0)
data = json.loads(path.read_text())
mappings = data.get('hooks', {}).get('mappings', []) if isinstance(data, dict) else []
found = False
for item in mappings:
    if not isinstance(item, dict):
        continue
    match = item.get('match') if isinstance(item.get('match'), dict) else {}
    if match.get('path') == hook_path and item.get('agentId') == agent_id:
        problems = []
        if item.get('deliver') is not False:
            problems.append('deliver is not false')
        if item.get('thinking') != 'off':
            problems.append(f"thinking is {item.get('thinking')!r} instead of 'off'")
        if item.get('sessionKey') != 'hook:arla:{{payload.event}}:{{payload.timestamp}}':
            problems.append('sessionKey does not match the fast-path template')
        transform = item.get('transform') if isinstance(item.get('transform'), dict) else {}
        if transform.get('module') != 'arla-hook-fast.js':
            problems.append('transform.module is not arla-hook-fast.js')
        if problems:
            print(f'[FAIL] hook mapping present but not on fast-path settings: {"; ".join(problems)}')
            raise SystemExit(1)
        found = True
        break
if found:
    print(f'[PASS] hook mapping present for {agent_id} at /hooks/{hook_path} with fast-path settings')
else:
    print(f'[FAIL] hook mapping missing for {agent_id} at /hooks/{hook_path}')
    raise SystemExit(1)
PY
rc=$?
if [[ $rc -ne 0 ]]; then status=1; fi
HOOK_TOKEN="$(/usr/bin/python3 - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ['OPENCLAW_CONFIG']).expanduser()
if not path.is_file():
    print('')
    raise SystemExit(0)
data = json.loads(path.read_text())
hooks = data.get('hooks') if isinstance(data.get('hooks'), dict) else {}
value = hooks.get('token') if isinstance(hooks.get('token'), str) else ''
print(value.strip())
PY
)"
if [[ -z "$HOOK_TOKEN" ]]; then
  fail "local hook check skipped because hooks.token is missing in OpenClaw config"
else
  http_code=$(curl -o /tmp/basicops-hook-check.$$ -sS -w '%{http_code}' "$LOCAL_HOOK_URL" -H "Authorization: Bearer $HOOK_TOKEN" -H 'Content-Type: application/json' --data-binary '{}' || true)
  if [[ "$http_code" == "200" ]]; then
    pass "local hook passes: $LOCAL_HOOK_URL"
  else
    fail "local hook failed at $LOCAL_HOOK_URL (HTTP $http_code)"
  fi
  rm -f /tmp/basicops-hook-check.$$
fi

if [[ $status -eq 0 ]]; then
  echo 'RESULT: PASS. This agent looks ready locally.'
else
  echo 'RESULT: FAIL. Fix the failed checks above before moving on.'
fi
exit $status
