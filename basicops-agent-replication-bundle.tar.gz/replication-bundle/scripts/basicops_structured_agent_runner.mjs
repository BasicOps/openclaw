#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const OPENCLAW_ROOT = '/home/hjhlarsen/.npm-global/lib/node_modules/openclaw';
const DIST_DIR = path.join(OPENCLAW_ROOT, 'dist');

function readStdin() {
  return new Promise((resolve, reject) => {
    const chunks = [];
    process.stdin.setEncoding('utf8');
    process.stdin.on('data', (chunk) => chunks.push(chunk));
    process.stdin.on('end', () => resolve(chunks.join('')));
    process.stdin.on('error', reject);
  });
}

function parseArgs(argv) {
  const args = { input: '-' };
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];
    if (token === '--input') {
      args.input = argv[i + 1] ?? '-';
      i += 1;
      continue;
    }
    if (!args.input || args.input === '-') {
      args.input = token;
      continue;
    }
    throw new Error(`Unexpected argument: ${token}`);
  }
  return args;
}

function loadRequest(inputPath) {
  const raw = inputPath === '-' ? null : fs.readFileSync(inputPath, 'utf8');
  return raw;
}

function resolveDistModulePath(prefix) {
  const entry = fs.readdirSync(DIST_DIR).find((name) => name.startsWith(prefix) && name.endsWith('.js'));
  if (!entry) throw new Error(`Could not locate ${prefix} module under ${DIST_DIR}`);
  return path.join(DIST_DIR, entry);
}

function resolveAgentCommandModulePath() {
  return resolveDistModulePath('agent-command-');
}

function resolveAgentEventsModulePath() {
  return resolveDistModulePath('agent-events-');
}

async function writeStdout(text) {
  await new Promise((resolve, reject) => {
    process.stdout.write(text, (err) => {
      if (err) reject(err);
      else resolve();
    });
  });
}

async function main() {
  const runnerStartedAt = Date.now();
  const { input } = parseArgs(process.argv.slice(2));
  const raw = input === '-' ? await readStdin() : loadRequest(input);
  if (!raw || !raw.trim()) throw new Error('Request JSON is required');
  const request = JSON.parse(raw);
  const moduleResolvedAt = Date.now();
  const modulePath = resolveAgentCommandModulePath();
  const agentEventsModulePath = resolveAgentEventsModulePath();
  const [mod, agentEventsMod] = await Promise.all([
    import(pathToFileURL(modulePath).href),
    import(pathToFileURL(agentEventsModulePath).href),
  ]);
  const moduleImportedAt = Date.now();
  const agentCommand = mod.n;
  const onAgentEvent = agentEventsMod.l;
  if (typeof agentCommand !== 'function') throw new Error(`agentCommand export not found in ${modulePath}`);
  if (typeof onAgentEvent !== 'function') throw new Error(`onAgentEvent export not found in ${agentEventsModulePath}`);

  const eventTrace = [];
  const streamCounts = {};
  const phaseOffsetsMs = {};
  const traceStartedAt = Date.now();
  const unsubscribe = onAgentEvent((event) => {
    if (!event || event.sessionKey !== request.sessionKey) return;
    const offsetMs = Date.now() - traceStartedAt;
    const stream = typeof event.stream === 'string' ? event.stream : 'unknown';
    streamCounts[stream] = (streamCounts[stream] || 0) + 1;
    const phase = typeof event.data?.phase === 'string' ? event.data.phase : undefined;
    const key = phase ? `${stream}:${phase}` : stream;
    if (phaseOffsetsMs[key] === undefined) phaseOffsetsMs[key] = offsetMs;
    if (eventTrace.length < 40) {
      eventTrace.push({
        runId: event.runId,
        stream,
        phase,
        offsetMs,
        dataKeys: event.data && typeof event.data === 'object' ? Object.keys(event.data).slice(0, 8) : [],
      });
    }
  });

  const quietRuntime = {
    log: () => {},
    error: () => {},
    warn: () => {},
  };
  const agentCommandStartedAt = Date.now();
  let result;
  try {
    result = await agentCommand({
      agentId: request.agentId,
      sessionKey: request.sessionKey,
      message: request.message,
      timeout: String(request.timeoutSeconds ?? 180),
      thinking: request.thinking || undefined,
      model: request.model || undefined,
      senderIsOwner: true,
      allowModelOverride: true,
    }, quietRuntime);
  } finally {
    try {
      unsubscribe?.();
    } catch {}
  }
  const agentCommandFinishedAt = Date.now();

  const envelope = {
    status: 'success',
    summary: null,
    runId: null,
    result,
    runnerTiming: {
      totalDurationMs: agentCommandFinishedAt - runnerStartedAt,
      moduleResolveDurationMs: moduleResolvedAt - runnerStartedAt,
      moduleImportDurationMs: moduleImportedAt - moduleResolvedAt,
      agentCommandDurationMs: agentCommandFinishedAt - agentCommandStartedAt,
      firstEventOffsetMs: eventTrace.length > 0 ? eventTrace[0].offsetMs : null,
      firstLifecycleStartOffsetMs: phaseOffsetsMs['lifecycle:start'] ?? null,
      firstAssistantOffsetMs: phaseOffsetsMs.assistant ?? null,
      streamCounts,
      phaseOffsetsMs,
      eventTrace,
    },
  };

  await writeStdout(`${JSON.stringify(envelope)}\n`);
}

main()
  .then(() => {
    process.exit(0);
  })
  .catch(async (error) => {
    const detail = error instanceof Error ? (error.stack || error.message) : String(error);
    try {
      await writeStdout('');
    } catch {}
    process.stderr.write(`${detail}\n`);
    process.exit(3);
  });
