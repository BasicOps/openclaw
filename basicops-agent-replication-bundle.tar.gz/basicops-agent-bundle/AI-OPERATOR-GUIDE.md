# AI Operator Guide

This file is for OpenClaw or another advanced helper.

The human operator using this bundle may be a novice with limited Linux knowledge.
Prefer doing safe validation work directly instead of making the human interpret logs or infer what a failure means.

## Primary rule

Favor:

- short instructions
- direct validation
- one checkpoint at a time
- plain language
- copy/paste commands

Avoid making the human reason about:

- reverse proxy theory
- TLS internals
- systemd details
- hook mapping structure

unless they must make a real decision.

## Files to read first

1. the generated `NEXT-STEPS.md` for the target agent
2. `START-HERE.md`
3. `README.md`
4. `docs/INSTALL.md` only when more detail is needed

If the generated install prompt starts with lines like these, treat them as hard guardrails:

- `TARGET AGENT: <agent-id>`
- `READ ONLY: generated/<agent-id>/NEXT-STEPS.md`

Do not switch to another agent's generated folder unless the human explicitly tells you to.

## What you should collect early

Confirm these values before deeper troubleshooting:

- agent id
- BasicOps profile
- hook path
- shim port
- expected public hostname
- chosen runtime CLI
- generated file directory

## Installation strategy

### If the human is starting from scratch and wants you involved from the first step

Prefer a narrow novice path:

1. ask only for the agent id unless the human already volunteered more values
2. choose safe defaults for everything else
3. run guided setup in non-interactive mode first
4. then read the generated `NEXT-STEPS.md` and continue from there

Default assumptions for this first-pass path:

- display name: default from agent id
- BasicOps profile: same as agent id
- hook path: `basicops-<agent-id>`
- runtime: `codex` unless the human clearly asked for something else
- hooks token: allow guided setup to generate one if missing

Preferred first command for this novice path:

```bash
python3 ~/basicops-agent-bundle/scripts/guided_setup_agent.py --agent-id <agent-id> --runtime codex --non-interactive --generate-hooks-token-if-missing
```

Do not jump straight into broader live mutations from memory. Scaffold first, read the generated output, then continue with one checkpoint at a time.

Use this order:

1. prerequisites exist
2. guided setup completed
3. generated files exist
4. agent registration is correct
5. hook config is correct
6. local shim service is running
7. local smoke test passes
8. reverse proxy is configured correctly
9. public smoke test passes
10. BasicOps webhook points to the correct public URL

Do not skip straight to public webhook debugging when local validation is still failing.

## Validation checkpoints

### 1. Prerequisites

Check:

```bash
python3 --version
openclaw status
mcporter --version
codex --version
```

If something is missing, stop and handle that first.

If `mcporter` is missing, install it with:

```bash
sudo npm install -g mcporter
mcporter --version
```

If `codex` is missing, install it with:

```bash
npm install -g @openai/codex
codex --version
```

If the Codex install fails with a permissions error, retry with:

```bash
sudo npm install -g @openai/codex
codex --version
```

If `codex --version` works but Codex still needs login/auth, finish that before continuing.

### 2. Guided setup output

Confirm the generated directory exists and contains the expected files.
At minimum, check for:

- `NEXT-STEPS.md`
- `<agent-id>.env`
- `basicops-preack@.service` or the matching launchd plist
- `<agent-id>.openclaw-agent.json`

### 3. Agent registration

Confirm the target agent exists in `agents.list` in `openclaw.json`.
If it does not, fix that before hook apply.

For ACP agents, validate this exact shape:

- `runtime.type = acp`
- `runtime.acp.cwd = <workspace>`

Do not put the working directory under `runtime.cwd` for ACP agents.

### 4. Hook config

Confirm these line up:

- agent id
- BasicOps profile
- hook path
- `OPENCLAW_FORWARD_URL`
- public webhook path

If local hook ingress fails, inspect `hooks.enabled`, `hooks.path`, and `hooks.token` before moving on.

### 4.5. Gateway restart boundary

If the installer restarts the OpenClaw gateway, treat that as a state boundary.

Before suggesting another restart:

- verify whether the restart already happened
- verify whether the gateway is already healthy again
- verify whether the next step is now local precheck, hook apply, or smoke test

If the human returns after a restart and says "continue" or similar, do not assume the restart still needs doing. Check first, then resume from the next unfinished step.

If the generated folder includes `AFTER-GATEWAY-RESTART.txt`, prefer having the human paste that back into OpenClaw so the resumed session gets the exact target-agent and resume-step context.

Default resume rule for this bundle:

- after the gateway restart step, resume at the agent-specific local precheck step unless current checks prove a later step is already complete
- prefer `openclaw gateway status` plus `./PRECHECK-AGENT-INSTALL.sh` as the first two post-restart checks

### 5. Shim service

On Linux, validate the user service:

```bash
systemctl --user status basicops-preack@<agent-id>.service --no-pager
journalctl --user -u basicops-preack@<agent-id>.service -n 50 --no-pager
```

Confirm the expected port is listening.

### 6. Reverse proxy

Prefer Caddy unless the machine is already clearly using Traefik.

Detect early whether the machine already has a proxy in place. Adding one route to an existing Caddy install is much safer than treating the machine like a fresh proxy install.

For Caddy, always validate:

- the full public hostname is used, not the short machine name
- the webhook path matches the generated hook path
- the reverse proxy target matches the shim port
- certificate issuance is happening for the full FQDN

### 7. Public validation

Do not call the setup complete until both of these work:

- local smoke test
- public HTTPS smoke test

### 8. BasicOps agent connection and identity safety

Do not ask the human to create the BasicOps webhook with raw curl if the configured BasicOps MCP profile is already available.

Prefer the MCP-backed path:

1. call `get_current_user` through the intended BasicOps profile
2. call `list_webhooks` through that same profile
3. verify any exact matching webhook uses the same `UserId` as `get_current_user.id`
4. warn if the BasicOps `firstName` looks unrelated to the intended agent id
5. register the agent through `connect_agent` only after identity and public route checks look sane
6. verify again with `list_webhooks`

If the generated bundle includes `scripts/ensure_basicops_webhook.py`, prefer using it.

Important interpretation rule:

- hard concern: exact webhook URL exists under a different BasicOps user id
- soft concern: agent id is `odin`, but `get_current_user.firstName` looks like `Thor`

On the soft concern, stop and ask the human whether the identity is intentional before proceeding.

## Common failure patterns

### Wrong hostname in proxy config

Symptom:
- TLS fails
- Caddy or Traefik tries to issue for `srv1605924` instead of `srv1605924.example.com`

Interpretation:
- the proxy is configured with the short hostname instead of the full FQDN

### Hook path mismatch

Symptom:
- local service is running
- public request reaches proxy
- request still does not reach the target agent

Interpretation:
- proxy path, shim env, and hook mapping are not aligned

### Wrong shim port

Symptom:
- reverse proxy seems present
- request still fails before reaching OpenClaw

Interpretation:
- proxy is pointing at the wrong local port or the service is not listening on the expected port

### Missing live hooks token

Symptom:
- local hook curl fails even though the service and proxy look healthy

Interpretation:
- `hooks.token` is missing, wrong, or mismatched

## Interaction rules

- keep the human focused on the next single action
- do not dump multiple branches at once unless a real choice is needed
- if the environment is obviously wrong, say so plainly
- do not ask the human to manually inspect logs if you can inspect them yourself
- when something fails, explain what it means in one sentence
- if a safe check can settle uncertainty, run the check
- prefer generated helper scripts like `INSTALL-LIVE-FILES.sh`, `PRECHECK-AGENT-INSTALL.sh`, and `FINISH-LOCAL-INSTALL.sh` when present
- prefer MCP-backed webhook verification/creation over asking the human to paste an API-key curl command

## Approval rules

Ask before:

- destructive file changes
- removing existing proxy config
- restarting or disabling unrelated services
- public-facing changes that may affect other routes

## Completion criteria

The install is only really done when:

- the agent is registered
- the hook mapping is live
- the shim service is active
- local smoke test passes
- public HTTPS test passes
- the BasicOps webhook destination matches the public route
