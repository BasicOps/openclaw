#!/usr/bin/env python3
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
import platform
import shlex
from pathlib import Path
import sys

from agent_naming import default_display_name, validate_agent_id


def render_text(text: str, replacements: dict[str, str]) -> str:
    for key, value in replacements.items():
        text = text.replace(key, value)
    return text


def detect_default_target_home() -> str:
    env_home = os.environ.get("HOME", "").strip()
    if env_home:
        return env_home.rstrip("/") or "/"
    return str(Path.home())


def detect_platform_name() -> str:
    return platform.system() or "Unknown"


def resolve_service_manager(requested: str, platform_name: str) -> str:
    if requested != "auto":
        return requested
    if platform_name == "Darwin":
        return "launchd"
    return "systemd"


def require_bundle_file(path: Path) -> None:
    if not path.is_file():
        raise SystemExit(f"Required bundle file not found: {path}")


def shell_block(lines: list[str]) -> str:
    return "```bash\n" + " \\\n".join(lines) + "\n```"


def command_list_block(commands: list[str]) -> str:
    return "```bash\n" + "\n".join(commands) + "\n```"


def backup_file(path: Path) -> Path:
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup_path = path.with_name(f"{path.name}.bak.{timestamp}")
    backup_path.write_text(path.read_text())
    return backup_path


def write_executable(path: Path, content: str) -> None:
    path.write_text(content)
    path.chmod(0o755)


def default_main_agent_snippet(openclaw_config_path: Path) -> dict[str, object]:
    workspace_main = openclaw_config_path.parent / "workspace-main"
    return {
        "id": "main",
        "name": "Main",
        "workspace": str(workspace_main),
        "tools": {
            "profile": "coding",
        },
    }


def discover_openclaw_gateway_port(config_path: str) -> str | None:
    path = Path(config_path).expanduser()
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text())
    except Exception:
        return None
    gateway = data.get("gateway") if isinstance(data, dict) else None
    if not isinstance(gateway, dict):
        return None
    port = gateway.get("port")
    if isinstance(port, int) and port > 0:
        return str(port)
    if isinstance(port, str) and port.strip().isdigit():
        return port.strip()
    return None


def register_agent_in_openclaw_config(openclaw_config_path: Path, agent_snippet: dict[str, object], make_backup: bool = True) -> tuple[str, Path | None]:
    if not openclaw_config_path.is_file():
        raise SystemExit(f"OpenClaw config not found: {openclaw_config_path}")

    try:
        data = json.loads(openclaw_config_path.read_text())
    except Exception as exc:
        raise SystemExit(f"Could not parse OpenClaw config JSON at {openclaw_config_path}: {exc}") from exc

    if not isinstance(data, dict):
        raise SystemExit(f"OpenClaw config root must be a JSON object: {openclaw_config_path}")

    agents = data.setdefault("agents", {})
    if not isinstance(agents, dict):
        raise SystemExit(f"Expected 'agents' to be a JSON object in {openclaw_config_path}")

    agent_list = agents.setdefault("list", [])
    if not isinstance(agent_list, list):
        raise SystemExit(f"Expected 'agents.list' to be a JSON array in {openclaw_config_path}")

    agent_id = str(agent_snippet.get("id", "")).strip()
    if not agent_id:
        raise SystemExit("Agent snippet is missing a valid id")

    for existing in agent_list:
        if isinstance(existing, dict) and str(existing.get("id", "")).strip() == agent_id:
            if existing == agent_snippet:
                return "already-present", None
            raise SystemExit(
                f"Agent id '{agent_id}' already exists in {openclaw_config_path} with different settings. "
                "Update it manually instead of overwriting automatically."
            )

    backup_path = backup_file(openclaw_config_path) if make_backup else None
    seeded_main = False
    if not agent_list and agent_id != "main":
        main_snippet = default_main_agent_snippet(openclaw_config_path)
        agent_list.append(main_snippet)
        Path(str(main_snippet["workspace"])).mkdir(parents=True, exist_ok=True)
        seeded_main = True
    agent_list.append(agent_snippet)
    openclaw_config_path.write_text(json.dumps(data, indent=2) + "\n")
    return ("added-with-main-seeded" if seeded_main else "added"), backup_path


def main() -> int:
    script_dir = Path(__file__).resolve().parent
    default_bundle_root = script_dir.parent

    parser = argparse.ArgumentParser(description="Scaffold a named BasicOps agent from the replication bundle")
    parser.add_argument("--bundle-root", default=str(default_bundle_root))
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--agent-id", required=True)
    parser.add_argument("--display-name")
    parser.add_argument("--basicops-profile", required=True)
    parser.add_argument("--hook-path")
    parser.add_argument("--mapping-name")
    parser.add_argument("--runtime-preset", choices=["standard", "structured-runtime-execute"], default="standard", help="Hook runtime preset. structured-runtime-execute generates a transform that runs the bundled agent-neutral structured runtime.")
    parser.add_argument("--shim-port", default="18891")
    parser.add_argument("--openclaw-hook-port")
    parser.add_argument("--target-home", help="Target home directory. Defaults to the current user's home.")
    parser.add_argument("--service-manager", choices=["auto", "systemd", "launchd"], default="auto")
    parser.add_argument("--path-with-mcporter")
    parser.add_argument("--wrapper-path")
    parser.add_argument("--self-context-cache-path")
    parser.add_argument("--preack-webhook-path")
    parser.add_argument("--preack-workdir")
    parser.add_argument("--openclaw-config-path")
    parser.add_argument("--hooks-token", default="REPLACE_ME")
    parser.add_argument("--hooks-token-generated", action="store_true", help="Mark that the hooks token was newly generated for this setup")
    parser.add_argument("--register-agent", action="store_true", help="Also append the generated agent to agents.list in the target OpenClaw config")
    parser.add_argument("--no-agent-config-backup", action="store_true", help="Do not create a timestamped backup before modifying the OpenClaw config")
    args = parser.parse_args()

    agent_id = validate_agent_id(args.agent_id)

    display_name = args.display_name or default_display_name(agent_id)
    hook_path = args.hook_path or f"basicops-{agent_id}"
    mapping_name = args.mapping_name or f"BasicOps {display_name} Hook"
    runtime_preset = args.runtime_preset
    default_target_home = detect_default_target_home()
    target_home = (args.target_home or default_target_home).rstrip("/") or default_target_home
    platform_name = detect_platform_name()
    service_manager = resolve_service_manager(args.service_manager, platform_name)
    bundle_root = Path(args.bundle_root).expanduser()
    path_with_mcporter = args.path_with_mcporter or f"{target_home}/.npm-global/bin:{target_home}/.local/bin:/usr/local/bin:/usr/bin:/bin"
    wrapper_path = args.wrapper_path or str((bundle_root / "scripts" / "basicops_mcp.py").resolve())
    self_context_cache = args.self_context_cache_path or f"{target_home}/.cache/basicops-agents/{agent_id}-self.json"
    preack_webhook_path = args.preack_webhook_path or str((bundle_root / "scripts" / "preack_webhook.py").resolve())
    preack_workdir = args.preack_workdir or str(bundle_root.resolve())
    openclaw_config_path = args.openclaw_config_path or f"{target_home}/.openclaw/openclaw.json"
    openclaw_hook_port = args.openclaw_hook_port or discover_openclaw_gateway_port(openclaw_config_path) or "18789"
    python_bin = sys.executable or "/usr/bin/python3"
    python_bin_shell = shlex.quote(python_bin)

    output_dir = Path(args.output_dir).expanduser()
    templates_dir = bundle_root / "templates"

    env_template = templates_dir / "env" / "agent.env.template"
    if service_manager == "launchd":
        service_template = templates_dir / "launchd" / "basicops-preack.agent.plist.template"
    else:
        service_template = templates_dir / "systemd" / "basicops-preack@.service.template"
    gateway_hooks_token_template = templates_dir / "systemd" / "openclaw-gateway-hooks-token.conf.template"
    install_doc = bundle_root / "docs" / "INSTALL.md"
    prompt_template = templates_dir / "prompts" / "basicops-worker-policy.template.md"
    renderer_script = bundle_root / "scripts" / "render_basicops_hook_config.py"
    webhook_helper_script = bundle_root / "scripts" / "ensure_basicops_webhook.py"
    structured_runtime_script = bundle_root / "scripts" / "basicops_structured_runtime.py"
    relative_install_doc = install_doc.resolve()
    relative_prompt_template = prompt_template.resolve()
    relative_renderer_script = renderer_script.resolve()
    relative_webhook_helper_script = webhook_helper_script.resolve()

    required_files = [env_template, service_template, install_doc, prompt_template, renderer_script, webhook_helper_script]
    if runtime_preset == "structured-runtime-execute":
        required_files.append(structured_runtime_script)
    if service_manager == "systemd":
        required_files.append(gateway_hooks_token_template)

    for path in required_files:
        require_bundle_file(path)

    launchd_label = f"com.openclaw.basicops-preack.{agent_id}"
    launchd_log_dir = f"{target_home}/Library/Logs/basicops-agents"
    launchd_stdout_path = f"{launchd_log_dir}/{agent_id}.log"
    launchd_stderr_path = f"{launchd_log_dir}/{agent_id}.err.log"

    replacements = {
        "{{AGENT_ID}}": agent_id,
        "{{AGENT_DISPLAY_NAME}}": display_name,
        "{{BASICOPS_PROFILE}}": args.basicops_profile,
        "{{PATH_WITH_MCPORTER}}": path_with_mcporter,
        "{{SHIM_PORT}}": args.shim_port,
        "{{OPENCLAW_HOOK_PORT}}": openclaw_hook_port,
        "{{HOOK_PATH}}": hook_path,
        "{{OPENCLAW_HOOKS_TOKEN}}": args.hooks_token,
        "{{BASICOPS_MCP_WRAPPER}}": wrapper_path,
        "{{SELF_CONTEXT_CACHE_PATH}}": self_context_cache,
        "{{PREACK_WEBHOOK_PATH}}": preack_webhook_path,
        "{{PREACK_WORKDIR}}": preack_workdir,
        "{{LAUNCHD_LABEL}}": launchd_label,
        "{{LAUNCHD_LOG_DIR}}": launchd_log_dir,
        "{{LAUNCHD_STDOUT_PATH}}": launchd_stdout_path,
        "{{LAUNCHD_STDERR_PATH}}": launchd_stderr_path,
        "{{PYTHON_BIN}}": python_bin,
    }

    output_dir.mkdir(parents=True, exist_ok=True)
    env_out = output_dir / f"{agent_id}.env"
    if service_manager == "launchd":
        service_out = output_dir / f"{launchd_label}.plist"
    else:
        service_out = output_dir / "basicops-preack@.service"
    gateway_hooks_token_out = output_dir / "openclaw-gateway-hooks-token.conf"
    values_out = output_dir / f"{agent_id}.values.env"
    agent_snippet_out = output_dir / f"{agent_id}.openclaw-agent.json"
    persona_example_out = output_dir / f"{agent_id}.basicops-personas.example.json"
    install_context_out = output_dir / "install-context.json"
    install_state_out = output_dir / "install-state.json"
    openclaw_prompt_out = output_dir / "OPENCLAW-INSTALL-PROMPT.txt"
    after_restart_prompt_out = output_dir / "AFTER-GATEWAY-RESTART.txt"
    install_live_out = output_dir / "APPLY-LOCAL-FILES.sh"
    finish_local_out = output_dir / "START-LOCAL-SERVICE.sh"
    precheck_out = output_dir / "CHECK-READONLY.sh"
    routing_test_out = output_dir / "TEST-ROUTING.sh"
    verify_live_out = output_dir / "VERIFY-END-TO-END.sh"
    readme_out = output_dir / "NEXT-STEPS.md"
    transform_module_name = f"{agent_id}-structured-runtime-hook.js"
    transform_out = output_dir / transform_module_name
    live_transform_path = f"{target_home}/.openclaw/hooks/transforms/{transform_module_name}"
    install_live_transform_dir = f"{target_home}/.openclaw/hooks/transforms"
    runtime_transform_enabled = runtime_preset == "structured-runtime-execute"
    runtime_hook_extra_args = (
        f" --message-template {shlex.quote(f'{display_name} structured runtime dispatch.')} --deliver false --thinking off"
        f" --session-key {shlex.quote(f'hook:{agent_id}:{{{{payload.event}}}}:{{{{payload.timestamp}}}}')}"
        f" --transform-module {transform_module_name}"
        if runtime_transform_enabled
        else ""
    )
    generated_transform_section = f"- {transform_out.name}\n" if runtime_transform_enabled else ""
    review_transform_text = f", `{transform_out.name}`" if runtime_transform_enabled else ""
    gateway_hooks_token_install_path = f"{target_home}/.config/systemd/user/openclaw-gateway.service.d/70-basicops-hooks-token.conf"
    generated_gateway_dropin = args.hooks_token_generated and service_manager == "systemd"

    agent_workspace = f"{target_home}/.openclaw/workspace-{agent_id}"
    agent_snippet = {
        "id": agent_id,
        "name": display_name,
        "workspace": agent_workspace,
        "identity": {
            "name": display_name,
        },
        "tools": {
            "profile": "coding",
        },
        "runtime": {
            "type": "acp",
            "acp": {
                "agent": "codex",
                "backend": "acpx",
                "mode": "persistent",
                "cwd": agent_workspace,
            },
        },
    }

    env_out.write_text(render_text(env_template.read_text(), replacements))
    service_out.write_text(render_text(service_template.read_text(), replacements))
    if generated_gateway_dropin:
        gateway_hooks_token_out.write_text(render_text(gateway_hooks_token_template.read_text(), replacements))
    values_out.write_text(
        "\n".join([
            f"AGENT_ID={agent_id}",
            f"AGENT_DISPLAY_NAME={display_name}",
            f"BASICOPS_PROFILE={args.basicops_profile}",
            f"HOOK_PATH={hook_path}",
            f"MAPPING_NAME={mapping_name}",
            f"SHIM_PORT={args.shim_port}",
            f"OPENCLAW_HOOK_PORT={openclaw_hook_port}",
            f"TARGET_HOME={target_home}",
            f"PATH_WITH_MCPORTER={path_with_mcporter}",
            f"BASICOPS_MCP_WRAPPER={wrapper_path}",
            f"SELF_CONTEXT_CACHE_PATH={self_context_cache}",
            f"PREACK_WEBHOOK_PATH={preack_webhook_path}",
            f"PREACK_WORKDIR={preack_workdir}",
            f"OPENCLAW_CONFIG_PATH={openclaw_config_path}",
            f"OPENCLAW_HOOKS_TOKEN={args.hooks_token}",
            "REQUIRE_EXPLICIT_MENTION=true",
            "SKIP_IF_OTHER_AGENT_MENTIONED=true",
            f"MENTION_TERMS={agent_id},{display_name}",
            "OTHER_AGENT_TERMS=",
            "",
        ])
    )
    agent_snippet_out.write_text(json.dumps(agent_snippet, indent=2) + "\n")
    persona_example_out.write_text(
        json.dumps({
            "personas": {
                args.basicops_profile: {
                    "headers": {
                        "Authorization": "Bearer YOUR_BASICOPS_API_KEY"
                    }
                }
            }
        }, indent=2) + "\n"
    )

    registration_state = "not-requested"
    registration_backup_path: Path | None = None
    if args.register_agent:
        registration_state, registration_backup_path = register_agent_in_openclaw_config(
            Path(openclaw_config_path).expanduser(),
            agent_snippet,
            make_backup=not args.no_agent_config_backup,
        )

    service_manager_check_cmd = (
        "launchctl print gui/$(id -u) >/dev/null && echo 'launchd ok' || echo 'launchd unavailable'"
        if service_manager == "launchd"
        else "systemctl --user status --no-pager >/dev/null && echo 'systemd user ok' || echo 'systemd user unavailable'"
    )

    dependency_check_cmd = command_list_block([
        f"{python_bin_shell} --version",
        "mcporter --version",
        "openclaw status",
        f"test -f {wrapper_path} && echo 'wrapper ok' || echo 'wrapper missing'",
        f"test -f {preack_webhook_path} && echo 'preack ok' || echo 'preack missing'",
        f"test -f {target_home}/.config/basicops-agents/basicops-personas.json && echo 'personas ok' || echo 'personas missing'",
        service_manager_check_cmd,
    ])

    self_context_cmd = shell_block([
        f"{python_bin_shell} {shlex.quote(wrapper_path)}",
        f"  --as {args.basicops_profile}",
        "  get-self-context",
        f"  --agent-id {agent_id}",
        f"  --cache-path {self_context_cache}",
        "  --refresh",
    ])

    render_preview_cmd = shell_block([
        f"{python_bin_shell} {shlex.quote(str(relative_renderer_script))}",
        f"  --template {relative_prompt_template}",
        f"  --openclaw-config {openclaw_config_path}",
        f"  --self-context-cache {self_context_cache}",
        f"  --agent-id {agent_id}",
        f"  --basicops-profile {args.basicops_profile}",
        f"  --hook-path {hook_path}",
        f"  --display-name {display_name}",
        f"  --mapping-name \"{mapping_name}\"",
        f"  --wrapper-path {wrapper_path}{runtime_hook_extra_args}",
        "  --mode render",
        "  --stdout diff",
    ])

    render_summary_cmd = shell_block([
        f"{python_bin_shell} {shlex.quote(str(relative_renderer_script))}",
        f"  --template {relative_prompt_template}",
        f"  --openclaw-config {openclaw_config_path}",
        f"  --self-context-cache {self_context_cache}",
        f"  --agent-id {agent_id}",
        f"  --basicops-profile {args.basicops_profile}",
        f"  --hook-path {hook_path}",
        f"  --display-name {display_name}",
        f"  --mapping-name \"{mapping_name}\"",
        f"  --wrapper-path {wrapper_path}{runtime_hook_extra_args}",
        "  --mode render",
        "  --stdout summary",
    ])

    apply_cmd_lines = [
        f"{python_bin_shell} {shlex.quote(str(relative_renderer_script))}",
        f"  --template {relative_prompt_template}",
        f"  --openclaw-config {openclaw_config_path}",
        f"  --self-context-cache {self_context_cache}",
        f"  --agent-id {agent_id}",
        f"  --basicops-profile {args.basicops_profile}",
        f"  --hook-path {hook_path}",
        f"  --display-name {display_name}",
        f"  --mapping-name \"{mapping_name}\"",
        f"  --wrapper-path {wrapper_path}{runtime_hook_extra_args}",
    ]
    if args.hooks_token != "REPLACE_ME":
        apply_cmd_lines.append(f"  --hooks-token {args.hooks_token}")
    apply_cmd_lines.extend([
        "  --mode apply",
        "  --backup",
    ])
    apply_cmd = shell_block(apply_cmd_lines)

    if service_manager == "launchd":
        service_install_path = f"{target_home}/Library/LaunchAgents/{service_out.name}"
        install_copy_cmd = command_list_block([
            f"mkdir -p ~/.config/basicops-agents {target_home}/Library/LaunchAgents {launchd_log_dir} {target_home}/.cache/basicops-agents" + (' ' + install_live_transform_dir if runtime_transform_enabled else ''),
            f"cp {env_out} ~/.config/basicops-agents/{agent_id}.env",
            f"cp {service_out} {service_install_path}",
            *([f"cp {transform_out} {live_transform_path}"] if runtime_transform_enabled else []),
        ])
    else:
        service_install_path = f"{target_home}/.config/systemd/user/basicops-preack@.service"
        install_copy_cmd = command_list_block([
            f"mkdir -p ~/.config/basicops-agents ~/.config/systemd/user {target_home}/.cache/basicops-agents {target_home}/.config/systemd/user/openclaw-gateway.service.d" + (' ' + install_live_transform_dir if runtime_transform_enabled else ''),
            f"cp {env_out} ~/.config/basicops-agents/{agent_id}.env",
            f"cp {service_out} {service_install_path}",
            *([f"cp {transform_out} {live_transform_path}"] if runtime_transform_enabled else []),
            *([f"cp {gateway_hooks_token_out} {gateway_hooks_token_install_path}"] if generated_gateway_dropin else []),
            "systemctl --user daemon-reload",
        ])

    live_env_path = f"{target_home}/.config/basicops-agents/{agent_id}.env"

    manual_register_agent_cmd = shell_block([
        f"{python_bin_shell} - <<'PY'",
        "import json",
        f"from pathlib import Path",
        f"config_path = Path({json.dumps(openclaw_config_path)}).expanduser()",
        f"snippet_path = Path({json.dumps(str(agent_snippet_out))}).expanduser()",
        "data = json.loads(config_path.read_text())",
        "snippet = json.loads(snippet_path.read_text())",
        "agents = data.setdefault('agents', {})",
        "agent_list = agents.setdefault('list', [])",
        "agent_id = snippet['id']",
        "workspace_main = config_path.parent / 'workspace-main'",
        "if any(isinstance(item, dict) and item.get('id') == agent_id for item in agent_list):",
        "    print(f\"agent already present: {agent_id}\")",
        "else:",
        "    if not agent_list and agent_id != 'main':",
        "        agent_list.append({",
        "            'id': 'main',",
        "            'name': 'Main',",
        "            'workspace': str(workspace_main),",
        "            'tools': {'profile': 'coding'},",
        "        })",
        "        workspace_main.mkdir(parents=True, exist_ok=True)",
        "        print('seeded main agent')",
        "    agent_list.append(snippet)",
        "    config_path.write_text(json.dumps(data, indent=2) + '\\n')",
        "    print(f\"added agent: {agent_id}\")",
        "PY",
    ])

    registration_status_lines = []
    if registration_state == "added":
        registration_status_lines.append(f"- agent registration: already added to `agents.list` in `{openclaw_config_path}`")
        if registration_backup_path is not None:
            registration_status_lines.append(f"- config backup: `{registration_backup_path}`")
    elif registration_state == "added-with-main-seeded":
        registration_status_lines.append(f"- agent registration: already added to `agents.list` in `{openclaw_config_path}`")
        registration_status_lines.append("- default control-panel agent: seeded `main` automatically because this was the first explicit non-main agent")
        if registration_backup_path is not None:
            registration_status_lines.append(f"- config backup: `{registration_backup_path}`")
    elif registration_state == "already-present":
        registration_status_lines.append(f"- agent registration: `{agent_id}` was already present in `agents.list` in `{openclaw_config_path}`")
    else:
        registration_status_lines.append(f"- agent registration: not yet applied to `{openclaw_config_path}`")

    persona_config_path = f"{target_home}/.config/basicops-agents/basicops-personas.json"
    persona_json_snippet = (
        "```json\n"
        "{\n"
        '  "personas": {\n'
        f'    "{args.basicops_profile}": {{\n'
        '      "headers": {\n'
        '        "Authorization": "Bearer YOUR_BASICOPS_API_KEY"\n'
        '      }\n'
        '    }\n'
        '  }\n'
        "}\n"
        "```"
    )

    if service_manager == "launchd":
        start_cmd = command_list_block([
            f"ls -l {live_env_path}",
            f"launchctl bootout gui/$(id -u) {service_install_path} >/dev/null 2>&1 || true",
            f"launchctl bootstrap gui/$(id -u) {service_install_path}",
            f"launchctl kickstart -k gui/$(id -u)/{launchd_label}",
            f"launchctl print gui/$(id -u)/{launchd_label}",
            f"tail -n 50 {launchd_stdout_path}",
            f"tail -n 50 {launchd_stderr_path}",
        ])
    else:
        start_cmd = command_list_block([
            f"ls -l {live_env_path}",
            "systemctl --user daemon-reload",
            "systemctl --user cat basicops-preack@.service",
            f"systemctl --user start basicops-preack@{agent_id}.service",
            f"systemctl --user enable basicops-preack@{agent_id}.service",
            f"systemctl --user status basicops-preack@{agent_id}.service --no-pager",
            f"journalctl --user -u basicops-preack@{agent_id}.service -n 50 --no-pager",
        ])

    proxy_detect_cmd = command_list_block([
        "command -v caddy >/dev/null && echo 'proxy: caddy already installed' || echo 'proxy: caddy not found'",
        "command -v nginx >/dev/null && echo 'proxy: nginx already installed' || echo 'proxy: nginx not found'",
        "command -v traefik >/dev/null && echo 'proxy: traefik already installed' || echo 'proxy: traefik not found'",
        "ss -ltnp 2>/dev/null | grep -E ':(80|443) ' || true",
    ])
    live_paths_check_cmd = command_list_block([
        f"test -f {live_env_path} && echo 'PASS live env exists: {live_env_path}' || echo 'FAIL live env missing: {live_env_path}'",
        f"test -f {service_install_path} && echo 'PASS live service exists: {service_install_path}' || echo 'FAIL live service missing: {service_install_path}'",
        *([f"test -f {gateway_hooks_token_install_path} && echo 'PASS live gateway hooks-token drop-in exists: {gateway_hooks_token_install_path}' || echo 'FAIL live gateway hooks-token drop-in missing: {gateway_hooks_token_install_path}'"] if generated_gateway_dropin else []),
    ])

    install_live_dirs = "~/Library/LaunchAgents" if service_manager == "launchd" else "~/.config/systemd/user"
    install_live_extra_dir = f"{target_home}/Library/Logs/basicops-agents" if service_manager == "launchd" else f"{target_home}/.config/systemd/user/openclaw-gateway.service.d"
    runtime_transform_enabled = runtime_preset == "structured-runtime-execute"
    install_live_transform_dir = f"{target_home}/.openclaw/hooks/transforms"
    install_live_transform_install = f"install -m 0644 {transform_out} {live_transform_path}\n" if runtime_transform_enabled else ""
    install_live_transform_check = f"test -f {live_transform_path} && echo 'PASS live transform exists: {live_transform_path}' || (echo 'FAIL live transform missing: {live_transform_path}' && exit 1)\n" if runtime_transform_enabled else ""
    install_live_dropin_install = f"install -m 0644 {gateway_hooks_token_out} {gateway_hooks_token_install_path}\n" if generated_gateway_dropin else ""
    install_live_dropin_check = f"test -f {gateway_hooks_token_install_path} && echo 'PASS live gateway hooks-token drop-in exists: {gateway_hooks_token_install_path}' || (echo 'FAIL live gateway hooks-token drop-in missing: {gateway_hooks_token_install_path}' && exit 1)\n" if generated_gateway_dropin else ""
    finish_apply_hooks_token_arg = f" --hooks-token {args.hooks_token}" if args.hooks_token != "REPLACE_ME" else ""
    runtime_hook_extra_args = (
        f" --message-template {shlex.quote(f'{display_name} structured runtime dispatch.')} --deliver false --thinking off"
        f" --session-key {shlex.quote(f'hook:{agent_id}:{{{{payload.event}}}}:{{{{payload.timestamp}}}}')}"
        f" --transform-module {transform_module_name}"
        if runtime_transform_enabled
        else ""
    )
    generated_transform_section = f"- {transform_out.name}\n" if runtime_transform_enabled else ""
    review_transform_text = f", `{transform_out.name}`" if runtime_transform_enabled else ""
    finish_service_block = (
        f"launchctl bootout gui/$(id -u) {service_install_path} >/dev/null 2>&1 || true\n"
        f"launchctl bootstrap gui/$(id -u) {service_install_path}\n"
        f"launchctl kickstart -k gui/$(id -u)/{launchd_label}\n"
        f"launchctl print gui/$(id -u)/{launchd_label}\n"
        if service_manager == "launchd"
        else f"systemctl --user daemon-reload\nsystemctl --user enable --now basicops-preack@{agent_id}.service\nsystemctl --user status basicops-preack@{agent_id}.service --no-pager\n"
    )
    precheck_dropin_var = f"LIVE_GATEWAY_DROPIN={json.dumps(gateway_hooks_token_install_path)}\n" if generated_gateway_dropin else ""
    live_gateway_dropin_shell = '${LIVE_GATEWAY_DROPIN}'
    precheck_dropin_check = (
        f"[[ -f \"{live_gateway_dropin_shell}\" ]] && pass \"live gateway hooks-token drop-in copied: {live_gateway_dropin_shell}\" || fail \"live gateway hooks-token drop-in missing: {live_gateway_dropin_shell}\"\n"
        if generated_gateway_dropin
        else ""
    )
    install_live_daemon_reload = "systemctl --user daemon-reload\n" if service_manager == "systemd" else ""
    precheck_export_dropin = "export LIVE_GATEWAY_DROPIN\n" if generated_gateway_dropin else ""

    install_live_script = f"""#!/usr/bin/env bash
set -euo pipefail

DRY_RUN=0
for arg in "$@"; do
  case "$arg" in
    --dry-run) DRY_RUN=1 ;;
    *) echo "Unknown arg: $arg" >&2; exit 2 ;;
  esac
done
run() {{
  printf '+ %s\n' "$*"
  if (( DRY_RUN == 1 )); then
    return 0
  fi
  eval "$*"
}}

echo 'TARGET AGENT: {agent_id}'
echo 'Applying local files for {agent_id}...'
echo 'This script copies files into place only. It does not restart the gateway, start services, or hit live hooks.'
run "mkdir -p ~/.config/basicops-agents {install_live_dirs} {target_home}/.cache/basicops-agents {install_live_extra_dir}{' ' + install_live_transform_dir if runtime_transform_enabled else ''}"
run "install -m 0644 {env_out} {live_env_path}"
run "install -m 0644 {service_out} {service_install_path}"
{f'run "install -m 0644 {transform_out} {live_transform_path}"\n' if runtime_transform_enabled else ''}{f'run "install -m 0644 {gateway_hooks_token_out} {gateway_hooks_token_install_path}"\n' if generated_gateway_dropin else ''}{'run "systemctl --user daemon-reload"\n' if service_manager == 'systemd' else ''}if (( DRY_RUN == 1 )); then
  echo 'DRY RUN: file copy commands were printed only, so live-path verification is skipped.'
  exit 0
fi
test -f {live_env_path} && echo 'PASS live env exists: {live_env_path}' || (echo 'FAIL live env missing: {live_env_path}' && exit 1)
test -f {service_install_path} && echo 'PASS live service exists: {service_install_path}' || (echo 'FAIL live service missing: {service_install_path}' && exit 1)
{install_live_transform_check}{install_live_dropin_check}"""

    finish_local_script = f"""#!/usr/bin/env bash
set -euo pipefail

DRY_RUN=0
for arg in "$@"; do
  case "$arg" in
    --dry-run) DRY_RUN=1 ;;
    *) echo "Unknown arg: $arg" >&2; exit 2 ;;
  esac
done
run() {{
  printf '+ %s\n' "$*"
  if (( DRY_RUN == 1 )); then
    return 0
  fi
  eval "$*"
}}

echo 'TARGET AGENT: {agent_id}'
echo 'READ ONLY: {readme_out}'
echo 'Starting local pre-ack service for {agent_id}...'
echo 'This script only reloads the user service manager and starts the pre-ack service.'

{'run "launchctl bootout gui/$(id -u) ' + service_install_path + ' >/dev/null 2>&1 || true"\nrun "launchctl bootstrap gui/$(id -u) ' + service_install_path + '"\nrun "launchctl kickstart -k gui/$(id -u)/' + launchd_label + '"\nrun "launchctl print gui/$(id -u)/' + launchd_label + '"\n' if service_manager == 'launchd' else 'run "systemctl --user daemon-reload"\nrun "systemctl --user enable --now basicops-preack@' + agent_id + '.service"\nrun "systemctl --user status basicops-preack@' + agent_id + '.service --no-pager"\nrun "journalctl --user -u basicops-preack@' + agent_id + '.service -n 50 --no-pager"\n'}"""

    precheck_script = f"""#!/usr/bin/env bash
set -euo pipefail

status=0
pass(){{ printf '[PASS] %s\\n' "$1"; }}
fail(){{ printf '[FAIL] %s\\n' "$1"; status=1; }}
warn(){{ printf '[WARN] %s\\n' "$1"; }}

echo 'TARGET AGENT: {agent_id}'
echo 'READ ONLY: {readme_out}'

PERSONAS={json.dumps(persona_config_path)}
PROFILE={json.dumps(args.basicops_profile)}
LIVE_ENV={json.dumps(live_env_path)}
LIVE_SERVICE={json.dumps(service_install_path)}
OPENCLAW_CONFIG={json.dumps(openclaw_config_path)}
EXPECTED_AGENT={json.dumps(agent_id)}
EXPECTED_WORKSPACE={json.dumps(agent_workspace)}
EXPECTED_HOOK={json.dumps(hook_path)}
LOCAL_HOOK_URL={json.dumps(f'http://127.0.0.1:{openclaw_hook_port}/hooks/{hook_path}')}
EXPECTED_TRANSFORM={json.dumps(transform_module_name if runtime_transform_enabled else '')}
LIVE_TRANSFORM={json.dumps(live_transform_path if runtime_transform_enabled else '')}
{precheck_dropin_var}
export PERSONAS PROFILE LIVE_ENV LIVE_SERVICE OPENCLAW_CONFIG EXPECTED_AGENT EXPECTED_WORKSPACE EXPECTED_HOOK LOCAL_HOOK_URL EXPECTED_TRANSFORM LIVE_TRANSFORM
{precheck_export_dropin}
[[ -f "$PERSONAS" ]] && pass "personas file exists: $PERSONAS" || fail "personas file missing: $PERSONAS"
{python_bin_shell} - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ['PERSONAS']).expanduser()
profile = os.environ['PROFILE']
if not path.is_file():
    raise SystemExit(0)
try:
    data = json.loads(path.read_text())
except Exception as exc:
    print(f'[FAIL] personas file is not valid JSON: {{exc}}')
    raise SystemExit(2)
personas = data.get('personas') if isinstance(data, dict) else None
if isinstance(personas, dict) and profile in personas:
    print(f'[PASS] target persona profile exists: {{profile}}')
else:
    print(f'[FAIL] target persona profile missing: {{profile}}')
    raise SystemExit(1)
PY
rc=$?
if [[ $rc -eq 1 || $rc -eq 2 ]]; then status=1; fi
[[ -f "$LIVE_ENV" ]] && pass "live env copied: $LIVE_ENV" || fail "live env missing: $LIVE_ENV"
[[ -f "$LIVE_SERVICE" ]] && pass "live service copied: $LIVE_SERVICE" || fail "live service missing: $LIVE_SERVICE"
if [[ -n "$EXPECTED_TRANSFORM" ]]; then
  [[ -f "$LIVE_TRANSFORM" ]] && pass "live transform copied: $LIVE_TRANSFORM" || fail "live transform missing: $LIVE_TRANSFORM"
fi
{precheck_dropin_check}{python_bin_shell} - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ['OPENCLAW_CONFIG']).expanduser()
agent_id = os.environ['EXPECTED_AGENT']
expected_workspace = os.environ['EXPECTED_WORKSPACE']
if not path.is_file():
    print(f'[FAIL] OpenClaw config missing: {{path}}')
    raise SystemExit(1)
try:
    data = json.loads(path.read_text())
except Exception as exc:
    print(f'[FAIL] OpenClaw config is not valid JSON: {{exc}}')
    raise SystemExit(1)
agent_list = data.get('agents', {{}}).get('list', []) if isinstance(data, dict) else []
agent = None
for item in agent_list:
    if isinstance(item, dict) and item.get('id') == agent_id:
        agent = item
        break
if not agent:
    print(f'[FAIL] agent not registered in agents.list: {{agent_id}}')
    raise SystemExit(1)
runtime = agent.get('runtime') if isinstance(agent.get('runtime'), dict) else {{}}
acp = runtime.get('acp') if isinstance(runtime.get('acp'), dict) else {{}}
if runtime.get('type') != 'acp':
    print(f'[FAIL] runtime.type is not acp for agent: {{agent_id}}')
    raise SystemExit(1)
if agent.get('workspace') != expected_workspace:
    print(f'[FAIL] workspace mismatch for agent: expected {{expected_workspace}}, found {{agent.get("workspace")}}')
    raise SystemExit(1)
if runtime.get('cwd'):
    print('[FAIL] runtime.cwd is set. For ACP agents, cwd must live under runtime.acp.cwd, not runtime.cwd.')
    raise SystemExit(1)
if acp.get('cwd') != expected_workspace:
    print(f'[FAIL] runtime.acp.cwd mismatch: expected {{expected_workspace}}, found {{acp.get("cwd")}}')
    raise SystemExit(1)
print(f'[PASS] agent registered with valid ACP runtime block: {{agent_id}}')
PY
rc=$?
if [[ $rc -ne 0 ]]; then status=1; fi
{python_bin_shell} - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ['OPENCLAW_CONFIG']).expanduser()
hook_path = os.environ['EXPECTED_HOOK']
agent_id = os.environ['EXPECTED_AGENT']
expected_transform = os.environ.get('EXPECTED_TRANSFORM', '').strip()
if not path.is_file():
    raise SystemExit(0)
data = json.loads(path.read_text())
mappings = data.get('hooks', {{}}).get('mappings', []) if isinstance(data, dict) else []
found = False
transform_ok = not expected_transform
for item in mappings:
    if not isinstance(item, dict):
        continue
    match = item.get('match') if isinstance(item.get('match'), dict) else {{}}
    if match.get('path') == hook_path and item.get('agentId') == agent_id:
        found = True
        transform = item.get('transform') if isinstance(item.get('transform'), dict) else {{}}
        if expected_transform:
            transform_ok = transform.get('module') == expected_transform
        break
if found:
    print(f'[PASS] hook mapping present for {{agent_id}} at /hooks/{{hook_path}}')
else:
    print(f'[FAIL] hook mapping missing for {{agent_id}} at /hooks/{{hook_path}}')
    raise SystemExit(1)
if expected_transform:
    if transform_ok:
        print(f'[PASS] hook mapping transform.module matches expected value: {{expected_transform}}')
    else:
        print(f'[FAIL] hook mapping transform.module mismatch for {{agent_id}}: expected {{expected_transform}}')
        raise SystemExit(1)
PY
rc=$?
if [[ $rc -ne 0 ]]; then status=1; fi
HOOK_TOKEN="$({python_bin_shell} - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ['OPENCLAW_CONFIG']).expanduser()
if not path.is_file():
    print('')
    raise SystemExit(0)
data = json.loads(path.read_text())
hooks = data.get('hooks') if isinstance(data.get('hooks'), dict) else {{}}
value = hooks.get('token') if isinstance(hooks.get('token'), str) else ''
print(value.strip())
PY
)"
if [[ -z "$HOOK_TOKEN" ]]; then
  fail "hooks.token missing in OpenClaw config"
else
  pass "hooks.token present in OpenClaw config"
fi

STATUS_OUT=/tmp/basicops-readonly-status.$$
if openclaw status --all >"$STATUS_OUT" 2>&1; then
  pass 'openclaw status --all completed'
  STATUS_OUT="$STATUS_OUT" {python_bin_shell} - <<'PY'
import os, re, sys
from pathlib import Path
agent_id = os.environ['EXPECTED_AGENT']
text = Path(os.environ['STATUS_OUT']).read_text()
pattern = re.compile(rf"^│\\s*{{re.escape(agent_id)}}\\b.*│\\s*(ABSENT|PRESENT)\\s*│", re.M)
match = pattern.search(text)
if not match:
    print(f"[WARN] agent row not found in openclaw status --all: {{agent_id}}")
    raise SystemExit(0)
state = match.group(1)
if state == 'ABSENT':
    print(f"[PASS] bootstrap file absent according to openclaw status: {{agent_id}}")
else:
    print(f"[WARN] bootstrap file still present according to openclaw status: {{agent_id}}. Treat service and routing checks as separate from worker readiness.")
PY
else
  warn 'openclaw status --all failed'
fi
rm -f "$STATUS_OUT"

echo 'NOTE: CHECK-READONLY.sh validates config and local wiring only. It does not prove shim routing, worker readiness, or public webhook readiness.'
if [[ $status -eq 0 ]]; then
  echo 'RESULT: PASS. Read-only config checks passed.'
else
  echo 'RESULT: FAIL. Fix the failed config checks above before moving on.'
fi
exit $status
"""

    public_webhook_host_placeholder = "YOUR_HOST_NAME"
    hook_smoke_payload = json.dumps({"openclawInstallSmokeTest": True, "source": "replication-bundle"}, separators=(",", ":"))
    hook_smoke_payload_shell = shlex.quote(hook_smoke_payload)
    public_webhook_path = f"/webhooks/{hook_path}"
    public_webhook_url = f"https://{public_webhook_host_placeholder}{public_webhook_path}"
    webhook_check_cmd = shell_block([
        f"{python_bin_shell} {shlex.quote(str(relative_webhook_helper_script))}",
        f"  --profile {args.basicops_profile}",
        f"  --agent-id {agent_id}",
        f"  --public-webhook-url {public_webhook_url}",
        f"  --wrapper-path {wrapper_path}",
    ])

    webhook_ensure_cmd = shell_block([
        f"{python_bin_shell} {shlex.quote(str(relative_webhook_helper_script))}",
        f"  --profile {args.basicops_profile}",
        f"  --agent-id {agent_id}",
        f"  --public-webhook-url {public_webhook_url}",
        f"  --wrapper-path {wrapper_path}",
        "  --create-if-missing",
    ])

    test_routing_script = f"""#!/usr/bin/env bash
set -euo pipefail

DRY_RUN=0
for arg in "$@"; do
  case "$arg" in
    --dry-run) DRY_RUN=1 ;;
    *) echo "Unknown arg: $arg" >&2; exit 2 ;;
  esac
done

status=0
pass(){{ printf '[PASS] %s\\n' "$1"; }}
fail(){{ printf '[FAIL] %s\\n' "$1"; status=1; }}
warn(){{ printf '[WARN] %s\\n' "$1"; }}

LOCAL_HOOK_URL={json.dumps(f'http://127.0.0.1:{openclaw_hook_port}/hooks/{hook_path}')}
PUBLIC_WEBHOOK_URL="${{PUBLIC_WEBHOOK_URL:-}}"
OPENCLAW_CONFIG={json.dumps(openclaw_config_path)}
SMOKE_PAYLOAD={hook_smoke_payload_shell}


echo 'TARGET AGENT: {agent_id}'
echo 'READ ONLY: {readme_out}'
echo 'This script validates shim TCP reachability plus local/public hook routing only.'
echo 'It does not prove worker readiness or BasicOps reply posting.'

if (( DRY_RUN == 1 )); then
  echo "+ python3 shim TCP check for 127.0.0.1:{args.shim_port}"
  echo "+ curl local synthetic smoke payload to $LOCAL_HOOK_URL"
  if [[ -n "$PUBLIC_WEBHOOK_URL" ]]; then
    echo "+ curl public synthetic smoke payload to $PUBLIC_WEBHOOK_URL"
  fi
  exit 0
fi

if {python_bin_shell} - <<'PY'
import socket, sys
s = socket.socket()
s.settimeout(1)
try:
    s.connect(('127.0.0.1', {args.shim_port}))
except OSError as exc:
    print(f'[FAIL] shim TCP check failed for 127.0.0.1:{args.shim_port}: {{exc}}')
    sys.exit(1)
finally:
    s.close()
print('[PASS] shim TCP check passed for 127.0.0.1:{args.shim_port}')
PY
then
  :
else
  status=1
fi

HOOK_TOKEN="$({python_bin_shell} - <<'PY'
import json
from pathlib import Path
path = Path({json.dumps(openclaw_config_path)}).expanduser()
if not path.is_file():
    print('')
    raise SystemExit(0)
data = json.loads(path.read_text())
hooks = data.get('hooks') if isinstance(data.get('hooks'), dict) else {{}}
value = hooks.get('token') if isinstance(hooks.get('token'), str) else ''
print(value.strip())
PY
)"
if [[ -z "$HOOK_TOKEN" ]]; then
  fail 'hooks.token missing in OpenClaw config'
else
  local_code=$(curl -o /tmp/basicops-routing-check.$$ -sS -w '%{{http_code}}' "$LOCAL_HOOK_URL" -H "Authorization: Bearer $HOOK_TOKEN" -H 'Content-Type: application/json' --data-binary "$SMOKE_PAYLOAD" || true)
  if [[ "$local_code" == "200" ]]; then
    pass "local hook routing passes: $LOCAL_HOOK_URL"
  else
    fail "local hook routing failed at $LOCAL_HOOK_URL (HTTP $local_code)"
  fi
  rm -f /tmp/basicops-routing-check.$$
fi

if [[ -z "$PUBLIC_WEBHOOK_URL" ]]; then
  warn 'PUBLIC_WEBHOOK_URL not set, skipping public routing check'
elif [[ "$PUBLIC_WEBHOOK_URL" == *YOUR_HOST_NAME* ]]; then
  warn 'PUBLIC_WEBHOOK_URL still uses the placeholder host, skipping public routing check'
elif [[ -z "$HOOK_TOKEN" ]]; then
  fail 'public routing check skipped because hooks.token is missing in OpenClaw config'
else
  public_code=$(curl -o /tmp/basicops-routing-public.$$ -sS -w '%{{http_code}}' "$PUBLIC_WEBHOOK_URL" -H "Authorization: Bearer $HOOK_TOKEN" -H 'Content-Type: application/json' --data-binary "$SMOKE_PAYLOAD" || true)
  if [[ "$public_code" == "200" ]]; then
    pass "public hook routing passes: $PUBLIC_WEBHOOK_URL"
  else
    fail "public hook routing failed at $PUBLIC_WEBHOOK_URL (HTTP $public_code)"
  fi
  rm -f /tmp/basicops-routing-public.$$
fi

if [[ $status -eq 0 ]]; then
  echo 'RESULT: PASS. Routing checks passed.'
else
  echo 'RESULT: FAIL. Fix the routing layer above before moving on.'
fi
exit $status
"""

    if runtime_transform_enabled:
        transform_script = f"""import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {{ spawn }} from 'node:child_process';

const RUNTIME_PATH = path.join(os.homedir(), 'basicops-agent-bundle', 'scripts', 'basicops_structured_runtime.py');
const SELF_CONTEXT_PATH = {json.dumps(self_context_cache)};
const LOG_PATH = path.join(os.tmpdir(), {json.dumps(f'{agent_id}-structured-runtime-hook.log')});
const AGENT_ID = {json.dumps(agent_id)};
const AGENT_NAME = {json.dumps(display_name)};
const PROFILE = {json.dumps(args.basicops_profile)};

function loadSelfUserId() {{
  try {{
    const raw = JSON.parse(fs.readFileSync(SELF_CONTEXT_PATH, 'utf8'));
    const value = raw?.selfContext?.userId ?? raw?.userId ?? null;
    if (value === null || value === undefined || value === '') return null;
    return String(value);
  }} catch {{
    return null;
  }}
}}

export default async function transform(ctx) {{
  const payload = ctx?.payload ?? null;
  const eventType = payload?.event ?? payload?.events?.[0]?.event ?? 'unknown-event';
  const context = payload?.context ?? payload?.events?.[0]?.data ?? {{}};
  const currentEntityId = context?.replyId ?? context?.id ?? context?.Id ?? context?.messageId ?? context?.taskId ?? context?.projectId ?? context?.chatId ?? context?.groupChatId ?? context?.groupchatId ?? context?.channelId ?? 'no-entity';
  const fileToken = `${{eventType}}-${{currentEntityId}}-${{Date.now()}}`.replace(/[^a-zA-Z0-9._-]+/g, '_');
  const payloadPath = path.join(os.tmpdir(), `${{AGENT_ID}}-hook-${{fileToken}}.json`);
  fs.writeFileSync(payloadPath, JSON.stringify(payload, null, 2), 'utf8');

  const fd = fs.openSync(LOG_PATH, 'a');
  fs.writeSync(fd, `\n=== ${{new Date().toISOString()}} event=${{eventType}} entity=${{currentEntityId}} ===\n`);
  fs.writeSync(fd, `payload=${{payloadPath}}\n`);

  const isSyntheticHookSmoke = Boolean(
    payload &&
    typeof payload === 'object' &&
    !Array.isArray(payload) &&
    (payload.openclawInstallSmokeTest === true || Object.keys(payload).length === 0)
  );
  if (isSyntheticHookSmoke) {{
    fs.writeSync(fd, 'syntheticSmokeBypassedWorker=1\n');
    fs.closeSync(fd);
    return null;
  }}

  const args = [RUNTIME_PATH, payloadPath, '--execute', '--agent-id', AGENT_ID, '--agent-name', AGENT_NAME, '--profile', PROFILE];
  const selfUserId = loadSelfUserId();
  if (selfUserId) {{
    args.push('--self-user-id', selfUserId);
  }}

  const child = spawn('python3', args, {{
    detached: true,
    stdio: ['ignore', fd, fd],
  }});
  child.unref();
  fs.closeSync(fd);

  return null;
}}
"""
        transform_out.write_text(transform_script)

    install_context = {
        "agentId": agent_id,
        "displayName": display_name,
        "basicopsProfile": args.basicops_profile,
        "runtimePreset": runtime_preset,
        "hookPath": hook_path,
        "mappingName": mapping_name,
        "shimPort": int(args.shim_port),
        "openclawHookPort": int(openclaw_hook_port),
        "openclawHookUrl": f"http://127.0.0.1:{openclaw_hook_port}/hooks/{hook_path}",
        "publicWebhookPath": public_webhook_path,
        "publicWebhookUrlTemplate": public_webhook_url,
        "serviceManager": service_manager,
        "targetHome": target_home,
        "generatedFiles": {
            "nextSteps": readme_out.name,
            "env": env_out.name,
            "service": service_out.name,
            **({"transform": transform_out.name} if runtime_transform_enabled else {}),
            "values": values_out.name,
            "agentSnippet": agent_snippet_out.name,
            "personaExample": persona_example_out.name,
            "installContext": install_context_out.name,
            "installState": install_state_out.name,
            "openclawInstallPrompt": openclaw_prompt_out.name,
            "afterGatewayRestartPrompt": after_restart_prompt_out.name,
            "applyLocalFilesScript": install_live_out.name,
            "startLocalServiceScript": finish_local_out.name,
            "checkReadonlyScript": precheck_out.name,
            "testRoutingScript": routing_test_out.name,
            "verifyEndToEndScript": verify_live_out.name,
        },
        "livePaths": {
            "env": live_env_path,
            "service": service_install_path,
            **({"transform": live_transform_path} if runtime_transform_enabled else {}),
        },
        "runtimeValidation": {
            "runtimeType": "acp",
            "requiredCwdPath": "runtime.acp.cwd",
            "expectedCwd": agent_workspace,
        },
    }
    if generated_gateway_dropin:
        install_context["generatedFiles"]["gatewayHooksTokenDropin"] = gateway_hooks_token_out.name
        install_context["livePaths"]["gatewayHooksTokenDropin"] = gateway_hooks_token_install_path
    install_state = {
        "phase": "scaffolded",
        "agentId": agent_id,
        "layers": {
            "config": {"script": precheck_out.name, "status": "pending"},
            "routing": {"script": routing_test_out.name, "status": "pending"},
            "worker": {"script": verify_live_out.name, "status": "pending"},
            "service": {"script": finish_local_out.name, "status": "pending"},
        },
    }
    install_context_out.write_text(json.dumps(install_context, indent=2) + "\n")
    install_state_out.write_text(json.dumps(install_state, indent=2) + "\n")
    write_executable(install_live_out, install_live_script)
    write_executable(finish_local_out, finish_local_script)
    write_executable(precheck_out, precheck_script)
    write_executable(routing_test_out, test_routing_script)
    openclaw_prompt_out.write_text(
        f"TARGET AGENT: {agent_id}\n"
        f"READ ONLY: {readme_out}\n"
        "DO NOT USE ANY OTHER AGENT'S NEXT-STEPS FILE.\n\n"
        "Please help me finish installing this BasicOps agent bundle on this machine. I am a novice user. Read these files first:\n"
        f"1. {readme_out}\n"
        f"2. {install_context_out}\n"
        f"3. {install_state_out}\n"
        f"4. {Path('~/basicops-agent-bundle/AI-OPERATOR-GUIDE.md').expanduser()}\n"
        "Then help me finish the install. Run safe validation checks directly when possible, validate outputs, and stop to ask before risky, destructive, or public-facing changes. If something already looks wrong, tell me plainly and fix the simplest thing first.\n"
        "If a step requires `openclaw gateway restart`, explain why, have the human do it, confirm the gateway is healthy again, and then continue from the next unfinished step.\n"
    )
    after_restart_prompt_out.write_text(
        f"TARGET AGENT: {agent_id}\n"
        f"READ ONLY: {readme_out}\n"
        "RESUME MODE: the OpenClaw gateway restart step has already been run during this install.\n"
        "Do not restart the gateway again unless you first confirm a new config change requires another restart.\n"
        f"First, verify current state instead of repeating earlier steps.\n"
        f"Run these checks before anything else:\n"
        f"1. openclaw gateway status\n"
        f"2. ./{precheck_out.name}\n"
        f"3. ./{routing_test_out.name} --dry-run\n"
        f"4. systemctl --user status basicops-preack@{agent_id}.service --no-pager\n"
        f"After that, continue from the first unfinished step in {readme_out.name}. If the current chat stalled during restart, you can use this file to resume cleanly, but a fresh chat is optional. Usually the remaining work is:\n"
        f"- confirm config-level checks still pass\n"
        f"- start the pre-ack service if it is still inactive\n"
        f"- complete the public reverse-proxy step\n"
        f"- set a real PUBLIC_WEBHOOK_URL\n"
        f"- run ./{verify_live_out.name} and require RESULT: PASS before the first real BasicOps test\n"
        f"Confirm specifically whether:\n"
        f"- target agent `{agent_id}` is already registered\n"
        f"- hook path `/hooks/{hook_path}` is already present\n"
        f"- read-only config checks already pass\n"
        f"- the public webhook hostname/path is configured, not still using a placeholder\n"
    )
    caddy_single_agent_example = (
        "```caddyfile\n"
        f"{public_webhook_host_placeholder} {{\n"
        f"    handle_path {public_webhook_path}* {{\n"
        f"        reverse_proxy 127.0.0.1:{args.shim_port}\n"
        "    }\n"
        "}\n"
        "```"
    )
    caddy_multi_agent_example = (
        "```caddyfile\n"
        f"{public_webhook_host_placeholder} {{\n"
        "    handle_path /webhooks/basicops-worker* {\n"
        "        reverse_proxy 127.0.0.1:18891\n"
        "    }\n\n"
        f"    handle_path {public_webhook_path}* {{\n"
        f"        reverse_proxy 127.0.0.1:{args.shim_port}\n"
        "    }\n"
        "}\n"
        "```"
    )

    registration_status_text = "\n".join(registration_status_lines)
    generated_token_section = (
        f"## Generated OpenClaw hooks token\n\n"
        + (
            f"For your information only: guided setup generated a new hooks token for this setup and already wired it into the generated files below. You do not need to create a separate token by hand.\n\n"
            if generated_gateway_dropin
            else f"For your information only: guided setup generated a new hooks token for this setup and already wired it into the generated hook-apply commands below. You do not need to create a separate token by hand.\n\n"
        )
        + (
            f"A systemd gateway drop-in was also generated for Linux installs:\n"
            f"- `{gateway_hooks_token_out.name}`\n"
            f"- install target: `{gateway_hooks_token_install_path}`\n\n"
            if generated_gateway_dropin else ""
        )
        if args.hooks_token_generated else ""
    )
    generated_files_line = f"{generated_transform_section}" + (f"- {gateway_hooks_token_out.name}\n" if generated_gateway_dropin else "")
    review_generated_files_text = f"{review_transform_text}" + (f" and `{gateway_hooks_token_out.name}`" if generated_gateway_dropin else "")
    copy_generated_files_step = (
        "6. Copy the generated env, service, and gateway hooks-token files into their final locations.\n"
        if generated_gateway_dropin
        else "6. Copy the generated env and service files into their final locations.\n"
    )
    suggested_flow_step7 = (
        "7. The OpenClaw agent registration is already done in `agents.list`.\n"
        if registration_state in {"added", "added-with-main-seeded", "already-present"}
        else f"7. Register the OpenClaw agent in `agents.list` in `{openclaw_config_path}`.\n"
    )
    register_agent_section_body = (
        f"This step is already complete for `{agent_id}`.\n\n"
        if registration_state in {"added", "added-with-main-seeded", "already-present"}
        else (
            f"Add this object under `agents.list` in `{openclaw_config_path}`:\n\n"
            f"```json\n{json.dumps(agent_snippet, indent=2)}\n```\n\n"
            f"You can also copy it directly from `{agent_snippet_out}` or run this helper command:\n\n"
            f"{manual_register_agent_cmd}\n\n"
        )
    )
    gateway_restart_cmd = command_list_block([
        "openclaw gateway restart",
        "openclaw gateway status",
    ])
    hook_runtime_prereq_cmd = command_list_block([
        f"{python_bin_shell} - <<'PY'",
        "import json",
        "from pathlib import Path",
        f"cfg = json.loads(Path({json.dumps(openclaw_config_path)}).expanduser().read_text())",
        "hooks = cfg.get('hooks') if isinstance(cfg.get('hooks'), dict) else {}",
        "gateway = cfg.get('gateway') if isinstance(cfg.get('gateway'), dict) else {}",
        "auth = gateway.get('auth') if isinstance(gateway.get('auth'), dict) else {}",
        "hooks_enabled = hooks.get('enabled')",
        "hooks_token = hooks.get('token') if isinstance(hooks.get('token'), str) else None",
        "gateway_token = auth.get('token') if isinstance(auth.get('token'), str) else None",
        "print(f'hooks.enabled={hooks_enabled!r}')",
        "print(f'hooks.token in config={bool(hooks_token and hooks_token.strip())}')",
        "print(f'gateway.auth.token in config={bool(gateway_token and gateway_token.strip())}')",
        "if hooks_token and gateway_token:",
        "    print(f'hooks.token matches gateway.auth.token={hooks_token.strip() == gateway_token.strip()}')",
        "else:",
        "    print('hooks.token matches gateway.auth.token=unknown (one or both may come from env or SecretRef)')",
        "ok = True",
        "if hooks_enabled is not True:",
        "    ok = False",
        "if not (hooks_token and hooks_token.strip()):",
        "    ok = False",
        "if hooks_token and gateway_token and hooks_token.strip() == gateway_token.strip():",
        "    ok = False",
        "print('PASSED' if ok else 'FAILED')",
        "PY",
    ])
    print_hooks_token_from_config_cmd = command_list_block([
        f"{python_bin_shell} - <<'PY'",
        "import json",
        "from pathlib import Path",
        f"cfg = json.loads(Path({json.dumps(openclaw_config_path)}).expanduser().read_text())",
        "hooks = cfg.get('hooks') if isinstance(cfg.get('hooks'), dict) else {}",
        "value = hooks.get('token') if isinstance(hooks.get('token'), str) else ''",
        "print(value.strip())",
        "PY",
    ])
    load_hooks_token_from_config_cmd = command_list_block([
        f"export OPENCLAW_HOOKS_TOKEN=\"$({python_bin_shell} - <<'PY'",
        "import json",
        "from pathlib import Path",
        f"cfg = json.loads(Path({json.dumps(openclaw_config_path)}).expanduser().read_text())",
        "hooks = cfg.get('hooks') if isinstance(cfg.get('hooks'), dict) else {}",
        "value = hooks.get('token') if isinstance(hooks.get('token'), str) else ''",
        "print(value.strip())",
        "PY",
        ")\"",
        "printf '%s\\n' \"${OPENCLAW_HOOKS_TOKEN:+token_loaded}\"",
    ])
    load_hooks_token_section = (
        f"## Find or load OPENCLAW_HOOKS_TOKEN for curl smoke tests\n\n"
        f"You only need `OPENCLAW_HOOKS_TOKEN` in your current shell for the curl smoke tests below. After the apply step, the simplest source of truth is `hooks.token` in `{openclaw_config_path}`.\n\n"
        f"If you just want to print the raw token value so you can inspect or copy it, use:\n\n"
        f"{print_hooks_token_from_config_cmd}\n\n"
        f"If you want to load it into your current shell, use:\n\n"
        f"{load_hooks_token_from_config_cmd}\n\n"
    )
    local_hook_smoke_cmd = command_list_block([
        f"curl -i -sS http://127.0.0.1:{openclaw_hook_port}/hooks/{hook_path} \\",
        "  -H \"Authorization: Bearer ${OPENCLAW_HOOKS_TOKEN:?set OPENCLAW_HOOKS_TOKEN first}\" \\",
        "  -H 'Content-Type: application/json' \\",
        f"  --data-binary {hook_smoke_payload_shell}",
    ])
    external_hook_smoke_cmd = command_list_block([
        f"curl -i -sS {public_webhook_url} \\",
        "  -H \"Authorization: Bearer ${OPENCLAW_HOOKS_TOKEN:?set OPENCLAW_HOOKS_TOKEN first}\" \\",
        "  -H 'Content-Type: application/json' \\",
        f"  --data-binary {hook_smoke_payload_shell}",
    ])

    verify_service_check = (
        f"if launchctl print gui/$(id -u)/{launchd_label} >/dev/null 2>&1; then\n"
        f"  pass \"pre-ack service is loaded: {launchd_label}\"\n"
        "else\n"
        f"  fail \"pre-ack service is not loaded: {launchd_label}\"\n"
        "fi\n"
        if service_manager == "launchd"
        else f"if systemctl --user is-active --quiet basicops-preack@{agent_id}.service; then\n"
        f"  pass \"pre-ack service is active: basicops-preack@{agent_id}.service\"\n"
        "else\n"
        f"  fail \"pre-ack service is not active: basicops-preack@{agent_id}.service\"\n"
        "fi\n"
    )

    verify_live_script = f"""#!/usr/bin/env bash
set -euo pipefail

status=0
pass(){{ printf '[PASS] %s\\n' \"$1\"; }}
fail(){{ printf '[FAIL] %s\\n' \"$1\"; status=1; }}
warn(){{ printf '[WARN] %s\\n' \"$1\"; }}

SCRIPT_DIR=\"$(cd \"$(dirname \"$0\")\" && pwd)\"
STATUS_OUT=\"$(mktemp)\"
DIRECT_TEST_JSON=\"$(mktemp)\"
MODEL_TEST_JSON=\"$(mktemp)\"
PUBLIC_BODY=\"$(mktemp)\"
cleanup() {{ rm -f \"$STATUS_OUT\" \"$DIRECT_TEST_JSON\" \"$MODEL_TEST_JSON\" \"$PUBLIC_BODY\"; }}
trap cleanup EXIT

EXPECTED_AGENT={json.dumps(agent_id)}
OPENCLAW_CONFIG={json.dumps(openclaw_config_path)}
LOCAL_HOOK_URL={json.dumps(f'http://127.0.0.1:{openclaw_hook_port}/hooks/{hook_path}')}
BOOTSTRAP_FILE={json.dumps(f'{agent_workspace}/BOOTSTRAP.md')}
PUBLIC_WEBHOOK_URL=\"${{PUBLIC_WEBHOOK_URL:-{public_webhook_url}}}\"
export EXPECTED_AGENT OPENCLAW_CONFIG LOCAL_HOOK_URL BOOTSTRAP_FILE STATUS_OUT DIRECT_TEST_JSON PUBLIC_WEBHOOK_URL

echo 'TARGET AGENT: {agent_id}'
echo 'READ ONLY: {readme_out}'
echo 'Running final readiness gate for {agent_id}...'

if \"$SCRIPT_DIR/{precheck_out.name}\"; then
  pass \"read-only config check passes\"
else
  fail \"read-only config check failed\"
fi

if [[ \"$PUBLIC_WEBHOOK_URL\" == *YOUR_HOST_NAME* ]]; then
  fail 'PUBLIC_WEBHOOK_URL still uses the YOUR_HOST_NAME placeholder. Re-run with PUBLIC_WEBHOOK_URL set to the real public webhook URL.'
fi

if PUBLIC_WEBHOOK_URL=\"$PUBLIC_WEBHOOK_URL\" \"$SCRIPT_DIR/{routing_test_out.name}\"; then
  pass \"routing test passes\"
else
  fail \"routing test failed\"
fi

if openclaw status --all >\"$STATUS_OUT\" 2>&1; then
  pass 'openclaw status --all completed'
else
  fail 'openclaw status --all failed'
fi

if {python_bin_shell} - <<'PY'
import os, re, sys
from pathlib import Path
agent_id = os.environ['EXPECTED_AGENT']
text = Path(os.environ['STATUS_OUT']).read_text()
pattern = re.compile(rf"^│\\s*{{re.escape(agent_id)}}\\b.*│\\s*(ABSENT|PRESENT)\\s*│", re.M)
match = pattern.search(text)
if not match:
    print(f"[WARN] agent row not found in openclaw status --all: {{agent_id}}")
    sys.exit(0)
state = match.group(1)
if state != 'ABSENT':
    print(f"[WARN] openclaw status shows Bootstrap file {{state}} for {{agent_id}}. That can be normal before the first successful bootstrap run.")
    sys.exit(0)
print(f"[PASS] openclaw status shows Bootstrap file ABSENT for {{agent_id}}")
PY
then
  :
fi

if [[ -f \"$BOOTSTRAP_FILE\" ]]; then
  warn \"bootstrap file still present on disk: $BOOTSTRAP_FILE (advisory until the agent finishes bootstrap cleanly)\"
else
  pass \"bootstrap file absent on disk: $BOOTSTRAP_FILE\"
fi

{verify_service_check}

if openclaw agent --agent \"$EXPECTED_AGENT\" --message \"reply OK\" --json --timeout 120 >\"$DIRECT_TEST_JSON\"; then
  if {python_bin_shell} - <<'PY'
import json, os, sys
from pathlib import Path
data = json.loads(Path(os.environ['DIRECT_TEST_JSON']).read_text())
texts = []
def walk(node):
    if isinstance(node, dict):
        for key, value in node.items():
            if key in {'finalAssistantVisibleText', 'finalAssistantRawText'} and isinstance(value, str):
                texts.append(value.strip())
            walk(value)
    elif isinstance(node, list):
        for item in node:
            walk(item)
walk(data)
reply = next((item for item in texts if item and item != 'NO_REPLY'), '')
if not reply:
    print('[FAIL] direct OpenClaw agent test did not produce a visible reply')
    sys.exit(1)
print(f"[PASS] direct OpenClaw agent test returned a visible reply: {{reply[:120]}}")
PY
  then
    :
  else
    status=1
  fi
else
  fail 'direct OpenClaw agent test command failed'
fi

HOOK_MODEL=\"$({python_bin_shell} - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ['OPENCLAW_CONFIG']).expanduser()
hook_path = {json.dumps(hook_path)}
agent_id = os.environ['EXPECTED_AGENT']
if not path.is_file():
    print('')
    raise SystemExit(0)
data = json.loads(path.read_text())
mappings = data.get('hooks', {{}}).get('mappings', []) if isinstance(data, dict) else []
for item in mappings:
    if not isinstance(item, dict):
        continue
    match = item.get('match') if isinstance(item.get('match'), dict) else {{}}
    if match.get('path') == hook_path and item.get('agentId') == agent_id:
        value = item.get('model')
        print(value.strip() if isinstance(value, str) else '')
        raise SystemExit(0)
print('')
PY
)\"
if [[ -n \"$HOOK_MODEL\" ]]; then
  if openclaw agent --agent \"$EXPECTED_AGENT\" --message \"reply OK\" --model \"$HOOK_MODEL\" --json --timeout 120 >\"$MODEL_TEST_JSON\"; then
    if MODEL_TEST_JSON=\"$MODEL_TEST_JSON\" {python_bin_shell} - <<'PY'
import json, os, sys
from pathlib import Path
data = json.loads(Path(os.environ['MODEL_TEST_JSON']).read_text())
texts = []
def walk(node):
    if isinstance(node, dict):
        for key, value in node.items():
            if key in {'finalAssistantVisibleText', 'finalAssistantRawText'} and isinstance(value, str):
                texts.append(value.strip())
            walk(value)
    elif isinstance(node, list):
        for item in node:
            walk(item)
walk(data)
reply = next((item for item in texts if item and item != 'NO_REPLY'), '')
if not reply:
    print('[FAIL] explicit hook model override direct test did not produce a visible reply')
    sys.exit(1)
print(f"[PASS] explicit hook model override is authorized via direct test: {{reply[:120]}}")
PY
    then
      pass \"hook model override direct test succeeded: $HOOK_MODEL\"
    else
      status=1
    fi
  else
    fail \"hook model override direct test failed: $HOOK_MODEL\"
  fi
else
  pass 'no explicit hook model override configured'
fi

if [[ \"$PUBLIC_WEBHOOK_URL\" != *YOUR_HOST_NAME* ]]; then
  if {python_bin_shell} {shlex.quote(str(relative_webhook_helper_script))} --profile {args.basicops_profile} --agent-id {agent_id} --public-webhook-url "$PUBLIC_WEBHOOK_URL" --wrapper-path {wrapper_path}; then
    pass 'BasicOps registration check passed'
  else
    fail 'BasicOps registration check failed'
  fi
fi

echo
echo 'Expected evidence chain for the first real BasicOps test:'
echo '1. public webhook returns 200'
echo '2. pre-ack logs show the incoming event'
echo '3. OpenClaw hook responds successfully'
echo '4. the target agent session store updates'
echo '5. BasicOps shows the reply'
echo
echo 'Important: use a real BasicOps message for the first end-to-end replay.'
echo 'Synthetic payloads or fake IDs can prove session creation, but reply posting may still fail with "Message not found".'

if [[ $status -eq 0 ]]; then
  echo 'RESULT: PASS. The install looks ready for the first real BasicOps message.'
else
  echo 'RESULT: FAIL. Fix the failing layer above before testing in BasicOps.'
fi
exit $status
"""

    readme_text = (
        f"# Next steps for {agent_id}\n\n"
        f"Generated files in this folder:\n"
        f"- {env_out.name}\n"
        f"- {service_out.name}\n"
        f"{generated_files_line}"
        f"- {values_out.name}\n"
        f"- {agent_snippet_out.name}\n"
        f"- {persona_example_out.name}\n"
        f"- {install_context_out.name}\n"
        f"- {install_state_out.name}\n"
        f"- {openclaw_prompt_out.name}\n"
        f"- {after_restart_prompt_out.name}\n"
        f"- {install_live_out.name}\n"
        f"- {finish_local_out.name}\n"
        f"- {routing_test_out.name}\n"
        f"- {verify_live_out.name}\n"
        f"- {precheck_out.name}\n\n"
        f"## Key values\n\n"
        f"- BasicOps profile: `{args.basicops_profile}`\n"
        f"- hook runtime preset: `{runtime_preset}`\n"
        f"- public webhook path: `{public_webhook_path}`\n"
        f"- local shim target: `127.0.0.1:{args.shim_port}`\n"
        f"- OpenClaw hook target: `127.0.0.1:{openclaw_hook_port}/hooks/{hook_path}`\n\n"
        f"## Before you begin\n\n"
        f"Important: files in this generated folder are not live yet. They do not affect the running service until you copy them into their final locations.\n\n"
        f"If you want the local OpenClaw assistant to guide the rest of the install, paste the contents of `{openclaw_prompt_out.name}` into that assistant after you skim this file once.\n\n"
        f"Target agent safety rail:\n"
        f"- TARGET AGENT: `{agent_id}`\n"
        f"- READ ONLY: `{readme_out}`\n"
        f"- do not use another agent's generated folder for this install\n\n"
        f"Read this file top to bottom once, then work through the steps in order:\n\n"
        f"1. Finish BasicOps account and persona setup.\n"
        f"2. Run the quick sanity checks and detect whether a reverse proxy already exists.\n"
        f"3. Copy the generated files into place with `{install_live_out.name}`.\n"
        f"4. Register the OpenClaw agent if needed, then restart the gateway.\n"
        f"5. Run `{precheck_out.name}` for a strict read-only config check.\n"
        f"6. Refresh self-context, preview the hook mapping, and apply it only after the summary looks right.\n"
        f"7. Start the local pre-ack service with `{finish_local_out.name}`.\n"
        f"8. Run `{routing_test_out.name}` to validate shim and hook routing without waking the worker.\n"
        f"9. Configure the public reverse proxy.\n"
        f"10. Re-run `{routing_test_out.name}` with `PUBLIC_WEBHOOK_URL` set to test the public route.\n"
        f"11. Point BasicOps at that same public webhook path.\n"
        f"12. Run `{verify_live_out.name}` and only continue if it finishes with `RESULT: PASS`.\n\n"
        f"## Registration status\n\n"
        f"{registration_status_text}\n\n"
        f"## 1. BasicOps login and persona setup\n\n"
        f"If this is a brand new BasicOps-backed agent, do these steps first:\n\n"
        f"1. Log in to BasicOps in the browser.\n"
        f"2. Create the agent user if it does not already exist.\n"
        f"3. Create an API key for that agent user.\n"
        f"4. Copy the API key somewhere safe.\n\n"
        f"The bundle cannot do those BasicOps-side account steps for you.\n\n"
        f"Next you will create or update `basicops-personas.json`. That file establishes the connection between this OpenClaw agent and the BasicOps agent user by storing the BasicOps API key under the selected profile name.\n\n"
        f"Typical persona file path:\n\n"
        f"```bash\n{persona_config_path}\n```\n\n"
        f"Create the directory first if needed:\n\n"
        f"```bash\nmkdir -p {target_home}/.config/basicops-agents\n```\n\n"
        f"If this is the first agent on the machine, you can start from the generated example file in this folder. It already uses profile `{args.basicops_profile}`, so you only need to replace `YOUR_BASICOPS_API_KEY`:\n\n"
        f"```bash\ncp {persona_example_out} {persona_config_path}\n```\n\n"
        f"Add or update the persona entry for profile `{args.basicops_profile}` so it uses the real API key:\n\n"
        f"{persona_json_snippet}\n\n"
        f"Keep the profile name `{args.basicops_profile}` exactly consistent with the commands in this bundle.\n\n"
        f"## 2. Quick sanity checks\n\n"
        f"{dependency_check_cmd}\n\n"
        f"Before planning any public setup work, also detect whether the machine already has a reverse proxy installed and listening:\n\n"
        f"{proxy_detect_cmd}\n\n"
        f"If any of those commands fail, go back to `QUICKSTART.md` and fix the prerequisites before continuing.\n"
        f"If `personas missing` appears above, do not continue to `get-self-context` until `{persona_config_path}` exists and contains the `{args.basicops_profile}` profile.\n\n"
        f"## 3. Review and copy the generated files into place\n\n"
        f"Review and edit `{env_out.name}`{review_generated_files_text} if any placeholder paths or tokens still need changes.\n\n"
        f"This is the step that makes the new values live. If you skip it, the running service may still use older values from an already-installed env file.\n\n"
        f"Recommended idempotent install command:\n\n"
        f"```bash\n./{install_live_out.name}\n```\n\n"
        f"Manual equivalent:\n\n"
        f"{install_copy_cmd}\n\n"
        f"After the copy step, confirm the exact live paths now exist:\n\n"
        f"{live_paths_check_cmd}\n\n"
        f"{generated_token_section}"
        f"## 4. Register the OpenClaw agent and restart the gateway\n\n"
        f"The hook renderer validates that `{agent_id}` already exists in `agents.list`. That prevents a broken route where a hook exists for an agent ID that OpenClaw does not actually know about.\n\n"
        f"{register_agent_section_body}"
        f"Minimum checks before moving on:\n"
        f"- `agents.list` contains an object with `id` = `{agent_id}`\n"
        f"- its `workspace` is `{agent_workspace}`\n"
        f"- its runtime `cwd` is `{agent_workspace}` under `runtime.acp.cwd`\n"
        f"- for ACP agents, do **not** put `cwd` under `runtime.cwd`\n\n"
        f"If you added or changed `agents.list`, restart the OpenClaw gateway before live testing so the runtime definitely picks up the updated config:\n\n"
        f"{gateway_restart_cmd}\n\n"
        f"Important restart boundary: restarting the gateway can interrupt the assistant session that is guiding the install. If that happens, do not restart it again by reflex. Paste `{after_restart_prompt_out.name}` into the assistant, run the checks it lists, and resume at Step 5 unless those checks prove you are already farther along.\n\n"
        f"## 5. Read-only config check\n\n"
        f"Run this before you do any deeper troubleshooting. It checks the exact agent profile, live copied files, agent registration shape, hook mapping, token presence, and current bootstrap state. It does not POST to the live hook:\n\n"
        f"```bash\n./{precheck_out.name}\n```\n\n"
        f"## 6. Create self-context\n\n"
        f"This calls the BasicOps MCP server using the authorization from `basicops-personas.json` and returns information about the connected BasicOps agent user. That information is cached and reused in the later hook-rendering steps.\n\n"
        f"{self_context_cmd}\n\n"
        f"Expected output should include `userId`, `displayName`, `email`, `timeZone`, `dateFormat`, and `timeFormat`.\n\n"
        f"Hard stop check: confirm the resolved `displayName` and `email` belong to the intended BasicOps agent user for this setup. If it resolves to a previous agent user or the wrong person, stop immediately, fix the API key in `basicops-personas.json`, and rerun this step before you touch hook mappings or webhooks.\n\n"
        f"## 7. Preview and apply the OpenClaw hook mapping\n\n"
        f"Start with the compact summary first. It is easier to read than the full diff:\n\n"
        f"{render_summary_cmd}\n\n"
        f"Quick checklist for the summary output:\n"
        f"- hookPath should be `{hook_path}`\n"
        f"- agentId should be `{agent_id}`\n"
        f"- agentRegistered should be `true`\n"
        f"- mappingName should be `{mapping_name}`\n"
        f"- basicopsProfile should be `{args.basicops_profile}`\n"
        f"- warnings should be empty, or clearly understood before you continue\n"
        f"- if summary `model` is non-empty, run the same direct test with that `--model` before you trust the webhook path\n\n"
        f"If you want the full diff as well, run:\n\n"
        f"{render_preview_cmd}\n\n"
        f"When the summary looks right, apply the hook mapping with backup:\n\n"
        f"{apply_cmd}\n\n"
        f"## 8. Validate hook prerequisites and load OPENCLAW_HOOKS_TOKEN\n\n"
        f"Quick checks:\n\n"
        f"{hook_runtime_prereq_cmd}\n\n"
        f"After the apply step and gateway restart, you want `hooks.enabled=True` and `hooks.token in config=True`.\n"
        f"If both hook and gateway auth tokens are present, they should not match. The check ends with `PASSED` or `FAILED` so it is easier to scan quickly.\n\n"
        f"{load_hooks_token_section}"
        f"## 9. Routing tests\n\n"
        f"After the hook mapping is applied and the service is running, validate the local shim plus OpenClaw hook routing layer without waking the real worker:\n\n"
        f"```bash\n./{routing_test_out.name}\n```\n\n"
        f"This script performs three separate checks:\n"
        f"- shim TCP reachability on `127.0.0.1:{args.shim_port}`\n"
        f"- local OpenClaw hook auth and routing using a synthetic ingress-only payload\n"
        f"- optional public route check when `PUBLIC_WEBHOOK_URL` is set\n\n"
        f"If you want to see the exact commands without running them, use:\n\n"
        f"```bash\n./{routing_test_out.name} --dry-run\n```\n\n"
        f"If you prefer the raw curl command, it is:\n\n"
        f"{local_hook_smoke_cmd}\n\n"
        f"## 10. Start the pre-ack service and check logs\n\n"
        f"Start the service explicitly with the generated helper:\n\n"
        f"```bash\n./{finish_local_out.name}\n```\n\n"
        f"If you want to inspect the underlying commands first, they are:\n\n"
        f"{start_cmd}\n\n"
        f"If `systemctl --user cat basicops-preack@.service` says the unit is not found, the copied service file is not visible to the user service manager yet. In that case, go back to step 3, confirm the file really exists at `{service_install_path}`, rerun `systemctl --user daemon-reload`, and then retry this step.\n\n"
        f"If `systemctl --user` fails with a user-bus or session error on headless Linux, the user systemd instance is not available in the current shell yet. A common fix is to run `loginctl enable-linger $(whoami)`, start a fresh login shell, confirm `systemctl --user status --no-pager` works, and then retry this step.\n\n"
        f"## 11. Configure the public reverse proxy\n\n"
        f"Reserve `{public_webhook_path}` for this agent and route it to `127.0.0.1:{args.shim_port}`.\n\n"
        f"This matters because BasicOps will send webhook payloads to your public webhook URL, and the reverse proxy is what forwards that request from the public internet to the local pre-ack service on this machine.\n\n"
        f"At this point the pre-ack service is already running, so port `{args.shim_port}` should normally be in use. That is expected. The earlier preflight and guided setup are the steps that should catch a real port conflict before you reach this point.\n\n"
        f"If you want to confirm the shim is listening locally before you touch the reverse proxy, use this TCP connect check instead:\n\n"
        f"```bash\n"
        f"{python_bin_shell} - <<'PY'\n"
        f"import socket\n"
        f"s = socket.socket()\n"
        f"s.settimeout(1)\n"
        f"try:\n"
        f"    s.connect(('127.0.0.1', {args.shim_port}))\n"
        f"    print('shim port is accepting connections')\n"
        f"except OSError as exc:\n"
        f"    print('shim port is not accepting connections: {args.shim_port} (' + str(exc) + ')')\n"
        f"finally:\n"
        f"    s.close()\n"
        f"PY\n"
        f"```\n\n"
        f"You need some public reverse proxy in front of the shim. The examples below use Caddy, but Caddy is not required. If you already have nginx, Traefik, HAProxy, or another edge proxy, adapt the route there instead.\n\n"
        f"### If you plan to use Caddy on Debian or Ubuntu\n\n"
        f"Use the official Caddy repo so you get a current release instead of an older distro package:\n\n"
        f"```bash\n"
        f"sudo apt update\n"
        f"sudo apt install -y debian-keyring debian-archive-keyring apt-transport-https curl gnupg\n"
        f"curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | sudo gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg\n"
        f"curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | sudo tee /etc/apt/sources.list.d/caddy-stable.list >/dev/null\n"
        f"sudo apt update\n"
        f"sudo apt install -y caddy\n"
        f"sudo systemctl enable --now caddy\n"
        f"sudo systemctl status --no-pager caddy\n"
        f"```\n\n"
        f"### Caddy example, single agent route\n\n"
        f"Replace `{public_webhook_host_placeholder}` with your real hostname:\n\n"
        f"{caddy_single_agent_example}\n\n"
        f"### Caddy example, alongside an existing worker route\n\n"
        f"{caddy_multi_agent_example}\n\n"
        f"After editing `/etc/caddy/Caddyfile`, verify and reload it:\n\n"
        f"```bash\n"
        f"caddy validate --config /etc/caddy/Caddyfile\n"
        f"sudo systemctl reload caddy\n"
        f"```\n\n"
        f"## 12. External routing test\n\n"
        f"After the local routing test works and the pre-ack service is running, test the public route from outside the server, for example from your laptop. This uses the same synthetic ingress-only payload and should not create a real agent run:\n\n"
        f"```bash\nPUBLIC_WEBHOOK_URL=https://YOUR_REAL_HOST_NAME{public_webhook_path} ./{routing_test_out.name}\n```\n\n"
        f"If you prefer the raw curl command, it is:\n\n"
        f"{external_hook_smoke_cmd}\n\n"
        f"How to read the result:\n"
        f"- `200 OK` means the public route answered successfully\n"
        f"- DNS, TLS, timeout, or connection errors mean the public hostname or reverse proxy path is still wrong\n"
        f"- `404 Not Found` usually means the public reverse proxy path is not routing to the shim you expected\n"
        f"- `401 Unauthorized` means the caller token does not match what the public endpoint expects\n\n"
        f"## 13. Register or verify the BasicOps agent connection\n\n"
        f"Only do this after the external webhook smoke test works. The URL here must match the same public webhook path you just tested.\n\n"
        f"Use the configured BasicOps MCP profile for this agent instead of a raw curl command. That reuses the API key already stored in `basicops-personas.json`.\n\n"
        f"First, verify identity and current connection state without changing anything:\n\n"
        f"{webhook_check_cmd}\n\n"
        f"What this check does:\n"
        f"- calls `get_current_user` through the configured BasicOps profile\n"
        f"- calls `list_webhooks` through the same profile\n"
        f"- verifies that any exact matching connection belongs to the same BasicOps user id\n"
        f"- warns if the BasicOps first name looks unrelated to the intended agent id `{agent_id}`\n\n"
        f"If it warns about an identity mismatch, pause there and resolve that before you create anything. Example: setting up agent `{agent_id}`, but the BasicOps user firstName is different.\n\n"
        f"If the check says no exact connect_agent registration exists, register it and verify it in one step:\n\n"
        f"{webhook_ensure_cmd}\n\n"
        f"This helper is intentionally conservative. If the same URL already exists with the wrong user id, it will stop and ask for review. If the same URL already exists under the current user but with the wrong event set, `--create-if-missing` refreshes it through `connect_agent` instead of creating a duplicate.\n\n"
        f"## 14. Verify end-to-end readiness\n\n"
        f"Before the first real BasicOps test, run the final readiness gate:\n\n"
        f"```bash\nPUBLIC_WEBHOOK_URL=https://YOUR_REAL_HOST_NAME{public_webhook_path} ./{verify_live_out.name}\n```\n\n"
        f"That script gives one clear `RESULT: PASS` or `RESULT: FAIL` and tells you which layer failed. It checks the local precheck, `openclaw status --all`, reports bootstrap state without hard-failing on it, checks the direct OpenClaw agent path, any explicit hook-model authorization path, the pre-ack service, the local hook, and the public webhook route.\n\n"
        f"## 15. Ready to test in BasicOps\n\n"
        f"If `{verify_live_out.name}` finishes with `RESULT: PASS`, you should now be ready to try this in BasicOps.\n\n"
        f"A simple first test message is:\n"
        f"- `@{display_name} are you there?`\n\n"
        f"Use a real BasicOps message for this first end-to-end test. Synthetic payloads or fake ids can prove that OpenClaw sessions are being created, but reply posting can still fail later with `Message not found`.\n\n"
        f"If your workspace uses a different mention format, adapt the agent name accordingly.\n\n"
        f"## Common friction points\n\n"
        f"- `{persona_config_path}` must exist before `get-self-context` can work\n"
        f"- the BasicOps profile name must stay `{args.basicops_profile}` everywhere\n"
        f"- the hook path `{hook_path}` and public webhook path `{public_webhook_path}` must stay aligned\n"
        f"- if you changed `agents.list`, restart the gateway before testing hooks\n"
        f"- if local hook tests return `401`, re-check `OPENCLAW_HOOKS_TOKEN`\n"
        f"- if public tests fail but local tests work, the problem is almost always DNS, TLS, or reverse-proxy routing\n\n"
        f"## References\n\n"
        f"- Manual guide: `{relative_install_doc}`\n"
        f"- Values file: `{values_out}`\n"
        f"- Env file: `{env_out}`\n"
        f"- Webhook helper: `{relative_webhook_helper_script}`\n"
        f"- Service file: `{service_out}`\n"
    )

    readme_out.write_text(readme_text)
    write_executable(verify_live_out, verify_live_script)

    print(f"Scaffolded agent bundle files in: {output_dir}")
    print(f"- {env_out}")
    print(f"- {service_out}")
    if runtime_transform_enabled:
        print(f"- {transform_out}")
    if args.hooks_token_generated:
        print(f"- {gateway_hooks_token_out}")
    print(f"- {values_out}")
    print(f"- {agent_snippet_out}")
    print(f"- {persona_example_out}")
    print(f"- {install_context_out}")
    print(f"- {install_state_out}")
    print(f"- {openclaw_prompt_out}")
    print(f"- {after_restart_prompt_out}")
    print(f"- {install_live_out}")
    print(f"- {finish_local_out}")
    print(f"- {routing_test_out}")
    print(f"- {verify_live_out}")
    print(f"- {precheck_out}")
    print(f"- {readme_out}")
    if registration_state == "added":
        print(f"Registered agent '{agent_id}' in {openclaw_config_path}")
        if registration_backup_path is not None:
            print(f"Backup written to: {registration_backup_path}")
    elif registration_state == "added-with-main-seeded":
        print(f"Registered agent '{agent_id}' in {openclaw_config_path}")
        print("Seeded default 'main' agent as well, to preserve web control-panel chat on fresh installs")
        if registration_backup_path is not None:
            print(f"Backup written to: {registration_backup_path}")
    elif registration_state == "already-present":
        print(f"Agent '{agent_id}' was already present in {openclaw_config_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
