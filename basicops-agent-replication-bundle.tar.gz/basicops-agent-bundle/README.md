# BasicOps Agent Replication Bundle

This directory is a portable starting point for reproducing a BasicOps-backed OpenClaw agent on another machine.

Current status for this test bundle:
- novice-friendly install flow is now centered on `START-HERE.md` and `INSTALL-WITH-OPENCLAW.md`
- user-facing OpenClaw commands use `openclaw gateway ...`
- Linux installs use `systemctl --user` for the local pre-ack shim
- macOS installs use `launchd` / `launchctl` for the local pre-ack shim

## Purpose

It is designed for two use cases:

1. **Manual replication**
   - another operator copies the bundle to a server and follows the included steps

2. **Guided replication with OpenClaw**
   - another operator gives OpenClaw the bundle and asks for step-by-step help setting up an agent with a chosen name/profile/path

## What is included

- reusable prompt template
- env template
- systemd service template
- bundled BasicOps MCP wrapper script
- bundled self-context helper script
- bundled pre-ack webhook shim script
- bundled BasicOps webhook ensure/verify helper script
- OpenClaw hook renderer/updater script
- generated OpenClaw install prompt for novice-assisted installs
- generated machine-readable install context for AI validation
- installation guide
- example values file
- MCP server config example for new BasicOps agent profiles
- reverse-proxy guidance including Caddy examples

## What is intentionally NOT included

- live secrets
- active hooks token values
- real BasicOps credentials
- a live `openclaw.json`
- copied production caches

## Expected workflow

1. copy or zip this directory
2. move it to the target server
3. unpack it
4. fill in placeholders
5. register the chosen agent in `agents.list` in `openclaw.json`
6. generate self-context for the chosen agent
7. load a real `OPENCLAW_HOOKS_TOKEN` into your shell or provide it explicitly
8. preview the OpenClaw hook diff
9. apply the hook mapping with backup, which should also set `hooks.enabled`, `hooks.path`, and `hooks.token`
10. install/start the systemd user service
11. verify logs and run a live test

## Architecture at a glance

For webhook-driven BasicOps agents, the request path usually looks like this:

```text
BasicOps or external sender
  -> public webhook URL on your server
  -> reverse proxy, for example Caddy
  -> local pre-ack webhook shim on 127.0.0.1:<shim-port>
  -> OpenClaw hook URL on 127.0.0.1:<openclaw-port>/hooks/<hook-path>
  -> target OpenClaw agent
```

Example:

```text
BasicOps
  -> https://YOUR_HOST_NAME/webhooks/basicops-helper
  -> Caddy route for /webhooks/basicops-helper
  -> 127.0.0.1:18894
  -> http://127.0.0.1:<OpenClaw gateway.port>/hooks/basicops-helper
  -> helper agent
```

Use the actual local OpenClaw gateway port from `~/.openclaw/openclaw.json` or `openclaw gateway status`. Do not assume it is always `18789`.

This bundle helps generate the OpenClaw-side pieces, but the operator still needs to make sure the reverse proxy path and the BasicOps webhook destination are aligned.

## Main entry points

- start here: `START-HERE.md`
- install with local OpenClaw: `INSTALL-WITH-OPENCLAW.md`
- AI helper playbook: `AI-OPERATOR-GUIDE.md`
- troubleshooting map: `TROUBLESHOOTING-CHECKPOINTS.md`
- handoff checklist: `HANDOFF.md`
- validated-state note: `VALIDATED-STATE.md`
- recipient note: `RECIPIENT-NOTE.md`
- manual quickstart: `QUICKSTART.md`
- full manual install guide: `docs/INSTALL.md`
- example values: `examples/worker-values.example.env`
- MCP server example: `examples/basicops-mcp-server.example.json`
- prompt template: `templates/prompts/basicops-worker-policy.template.md`
- env template: `templates/env/agent.env.template`
- systemd service template: `templates/systemd/basicops-preack@.service.template`
- hook renderer: `scripts/render_basicops_hook_config.py`
- named-agent scaffolder: `scripts/scaffold_agent_from_bundle.py`
- guided setup helper: `scripts/guided_setup_agent.py`
- preflight checker: `scripts/preflight_replication_bundle.py`
- webhook helper: `scripts/ensure_basicops_webhook.py`

## Handoff note

This handoff bundle is template-first. It intentionally does not include pre-generated agent output under `generated/`.
The recipient should run the scaffolder or guided setup on the target machine to produce fresh agent-specific files there.

Recommended operator split:

- novice or assisted install: `INSTALL-WITH-OPENCLAW.md`
- advanced manual install: `QUICKSTART.md` and `docs/INSTALL.md`

Important: the bundle can scaffold hook mappings, env files, and service files, but the target agent must already exist in `agents.list` in `~/.openclaw/openclaw.json` before the hook mapping is applied.

On a fresh OpenClaw install, if the bundle registers the first explicit non-main agent, it also seeds a safe default `main` agent so the web control panel keeps working.
By default, if the bundle updates `~/.openclaw/openclaw.json`, it creates a timestamped backup first.
By default, the generated hook mapping does not force a hook model override anymore. If you intentionally want to force a specific route, set an explicit `--hook-model` yourself only after a direct test like `openclaw agent --agent <id> --message "reply OK" --model <that-model>` succeeds on that machine.
The renderer now validates the target agent registration so it cannot silently create a hook that points at a missing agent.

## Recommended packaging

Run the guarded packaging script instead of calling `tar` or `zip` directly.

Verification only:

```bash
bash replication-bundle/scripts/scaffold_bundle.sh --verify-only
```

Create a clean tarball for handoff:

```bash
bash replication-bundle/scripts/scaffold_bundle.sh --tar
```

Create both tarball and zip:

```bash
bash replication-bundle/scripts/scaffold_bundle.sh --tar --zip
```

The helper script refuses to continue if the bundle tree contains stale `generated/` output, Python bytecode caches, or likely secret-bearing files such as `openclaw-gateway-hooks-token.conf`, `basicops-personas.json`, `mcporter.json`, or non-example `*.basicops-personas.json` files.

For a short release checklist, see `CLEAN-BUNDLE-CHECKLIST.md`.

### After copying the tarball to another machine

Unpack it like this:

```bash
mkdir -p ~/basicops-agent-bundle
tar -xzf basicops-agent-replication-bundle.tar.gz -C ~/basicops-agent-bundle --strip-components=1
```

After that, commands using paths like:

```bash
~/basicops-agent-bundle/scripts/guided_setup_agent.py
```

will make sense.

Recommended interactive pattern:

Important: this helper does not install prerequisites for you. The target machine still needs `openclaw`, `mcporter`, and the chosen runtime CLI, for example `codex`, installed first.

Common beginner setup example:

```bash
sudo npm install -g mcporter
npm install -g @openai/codex
mcporter --version
codex --version
```

If the Codex install fails with a permissions error, retry with:

```bash
sudo npm install -g @openai/codex
codex --version
```

If `codex --version` works but Codex still needs login/auth, finish that before continuing.

```bash
python3 ~/basicops-agent-bundle/scripts/guided_setup_agent.py \
  --agent-id helper \
  --runtime codex
```

Set the agent id up front, then let the helper suggest the rest.
The helper now defaults `--target-home` to the current user's home, so only add that flag when you intentionally want to install for a different Unix account.

This bundle intentionally omits `replication-bundle/generated/` so recipients generate fresh agent-specific output on the target machine.
