#!/usr/bin/env python3
import argparse
import html
import json
import re
import sys
from typing import Any

EVENT_SURFACES = {
    "basicops.task.message.created": "task_message",
    "basicops.task.message.updated": "task_message",
    "basicops.task.reply.created": "task_reply",
    "basicops.task.reply.updated": "task_reply",
    "basicops.task.created": "task_lifecycle",
    "basicops.task.updated": "task_lifecycle",
    "basicops.project.message.created": "project_message",
    "basicops.project.message.updated": "project_message",
    "basicops.project.reply.created": "project_message",
    "basicops.project.reply.updated": "project_message",
    "basicops.chat.message.created": "chat_message",
    "basicops.chat.message.updated": "chat_message",
    "basicops.chat.reply.created": "chat_message",
    "basicops.chat.reply.updated": "chat_message",
    "basicops.groupchat.message.created": "groupchat_message",
    "basicops.groupchat.message.updated": "groupchat_message",
    "basicops.groupchat.reply.created": "groupchat_message",
    "basicops.groupchat.reply.updated": "groupchat_message",
    "basicops.channel.message.created": "channel_message",
    "basicops.channel.message.updated": "channel_message",
    "basicops.channel.reply.created": "channel_message",
    "basicops.channel.reply.updated": "channel_message",
}

TASK_LIFECYCLE_EVENTS = {
    "basicops.task.created",
    "basicops.task.updated",
}

MESSAGE_SURFACES = {
    "task_message",
    "task_reply",
    "project_message",
    "chat_message",
    "groupchat_message",
    "channel_message",
}

REPLY_EVENT_TYPES = {
    "basicops.task.reply.created",
    "basicops.task.reply.updated",
    "basicops.project.reply.created",
    "basicops.project.reply.updated",
    "basicops.chat.reply.created",
    "basicops.chat.reply.updated",
    "basicops.groupchat.reply.created",
    "basicops.groupchat.reply.updated",
    "basicops.channel.reply.created",
    "basicops.channel.reply.updated",
}


def _coerce_primary_event(payload: dict[str, Any]) -> dict[str, Any]:
    events = payload.get("events")
    if isinstance(events, list) and events and isinstance(events[0], dict):
        return events[0]

    context = _as_dict(payload.get("context"))
    event_type = _first_present(context.get("event"), payload.get("event"))
    if not isinstance(event_type, str) or not event_type.strip():
        raise ValueError("payload.events[0].event missing")

    user_id = _first_present(context.get("userId"), context.get("UserId"))
    reply_id = _first_present(
        context.get("replyId"),
        context.get("ReplyId"),
        context.get("id"),
        context.get("Id"),
    )
    message_id = _first_present(context.get("messageId"), context.get("MessageId"))

    data = dict(context)
    if reply_id is not None:
        data.setdefault("id", reply_id)
    elif message_id is not None:
        data.setdefault("id", message_id)
    if event_type in REPLY_EVENT_TYPES and message_id is not None:
        data.setdefault("messageId", message_id)
    if isinstance(payload.get("request"), str) and "message" not in data and "Message" not in data:
        data["message"] = payload.get("request")

    coerced_event = {
        "event": event_type,
        "timestamp": payload.get("timestamp"),
        "companyId": payload.get("companyId"),
        "webhookId": payload.get("webhookId"),
        "updates": payload.get("updates"),
        "data": data,
    }
    if user_id is not None:
        coerced_event["user"] = {"id": user_id}
    if isinstance(payload.get("instructions"), str):
        coerced_event["instructions"] = payload.get("instructions")
    if isinstance(payload.get("agentInstructions"), str):
        coerced_event["agentInstructions"] = payload.get("agentInstructions")
    return coerced_event


def html_to_text(value: str) -> str:
    if not value:
        return ""
    text = re.sub(r"<br\s*/?>", "\n", value, flags=re.I)
    text = re.sub(r"</p\s*>", "\n", text, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = html.unescape(text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def _as_dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _first_present(*values: Any) -> Any:
    for value in values:
        if value is None:
            continue
        if isinstance(value, str) and value == "":
            continue
        return value
    return None


def _clean_terms(terms: list[str] | set[str] | tuple[str, ...] | None) -> list[str]:
    cleaned = []
    seen = set()
    for term in terms or []:
        if not isinstance(term, str):
            continue
        value = term.strip()
        if not value:
            continue
        key = value.casefold()
        if key in seen:
            continue
        seen.add(key)
        cleaned.append(value)
    return cleaned


def _has_any_term(text: str, terms: list[str]) -> bool:
    if not text or not terms:
        return False
    for term in terms:
        pattern = rf"(?<!\w)@?{re.escape(term)}(?!\w)"
        if re.search(pattern, text, flags=re.I):
            return True
    return False


def _is_project_team_membership_notice(text: str, self_terms: list[str]) -> bool:
    if not text or not self_terms:
        return False
    for term in self_terms:
        added_pattern = rf"\badded\s+@?{re.escape(term)}\s+to\s+the\s+project\s+team\b"
        removed_pattern = rf"\bremoved\s+@?{re.escape(term)}\s+from\s+the\s+project\s+team\b"
        if re.search(added_pattern, text, flags=re.I) or re.search(removed_pattern, text, flags=re.I):
            return True
    return False


def _pick_task_object(data: Any) -> dict[str, Any]:
    if isinstance(data, list) and data and isinstance(data[0], dict):
        return data[0]
    if isinstance(data, dict) and any(
        key in data
        for key in (
            "title",
            "Title",
            "status",
            "Status",
            "description",
            "Description",
            "project",
            "assignee",
            "change",
            "url",
            "Url",
        )
    ):
        return data
    return {}


def _normalize_task_snapshot(task_obj: dict[str, Any]) -> dict[str, Any] | None:
    if not task_obj:
        return None
    assignee = _as_dict(task_obj.get("assignee"))
    project = _as_dict(task_obj.get("project"))
    change = _as_dict(task_obj.get("change"))
    assignee_change = _as_dict(change.get("assignee"))
    change_to = _as_dict(assignee_change.get("to"))
    change_from = _as_dict(assignee_change.get("from"))
    snapshot = {
        "id": _first_present(task_obj.get("id"), task_obj.get("Id"), task_obj.get("taskId"), task_obj.get("TaskId")),
        "title": _first_present(task_obj.get("title"), task_obj.get("Title")),
        "url": _first_present(task_obj.get("url"), task_obj.get("Url")),
        "status": _first_present(task_obj.get("status"), task_obj.get("Status")),
        "descriptionHtml": _first_present(task_obj.get("description"), task_obj.get("Description")),
        "project": {
            "id": _first_present(project.get("id"), project.get("Id"), task_obj.get("projectId"), task_obj.get("ProjectId")),
            "title": _first_present(project.get("title"), project.get("Title"), project.get("name"), project.get("Name")),
        },
        "assignee": {
            "id": _first_present(assignee.get("id"), assignee.get("Id")),
            "name": _first_present(
                assignee.get("name"),
                " ".join(part for part in [assignee.get("firstName"), assignee.get("lastName")] if isinstance(part, str) and part.strip()) or None,
            ),
        },
        "assigneeChange": {
            "fromId": _first_present(change_from.get("id"), change_from.get("Id")),
            "toId": _first_present(change_to.get("id"), change_to.get("Id")),
        },
    }
    return snapshot


def normalize_basicops_skill_payload(payload: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValueError("payload must be a dict")

    if isinstance(payload.get("context"), dict) and "events" not in payload:
        context = dict(payload["context"])
        if not isinstance(context.get("event"), str) and isinstance(payload.get("event"), str):
            context["event"] = payload["event"]
        skill_payload: dict[str, Any] = {
            "context": context,
            "request": payload.get("request") if isinstance(payload.get("request"), str) else "",
        }
        if isinstance(payload.get("instructions"), str):
            skill_payload["instructions"] = payload["instructions"]
        if isinstance(payload.get("agentInstructions"), str):
            skill_payload["agentInstructions"] = payload["agentInstructions"]
        return skill_payload

    event = _coerce_primary_event(payload)
    event_type = event.get("event")
    surface = EVENT_SURFACES.get(event_type, "unknown")

    event_user = _as_dict(event.get("user"))
    data = event.get("data")
    data_dict = _as_dict(data)
    task_obj = _pick_task_object(data)
    task_from_data = _as_dict(data_dict.get("task"))
    project_from_data = _as_dict(data_dict.get("project"))

    author_user_id = _first_present(
        data_dict.get("userId"),
        data_dict.get("UserId"),
        event_user.get("id"),
        event_user.get("Id"),
        _as_dict(data_dict.get("user")).get("id"),
        _as_dict(data_dict.get("user")).get("Id"),
    )
    task_id = _first_present(
        data_dict.get("taskId"),
        data_dict.get("TaskId"),
        task_from_data.get("id"),
        task_from_data.get("Id"),
        task_obj.get("id"),
        task_obj.get("Id"),
    )
    project_id = _first_present(
        data_dict.get("projectId"),
        data_dict.get("ProjectId"),
        project_from_data.get("id"),
        project_from_data.get("Id"),
        _as_dict(task_obj.get("project")).get("id"),
        _as_dict(task_obj.get("project")).get("Id"),
    )
    chat_id = _first_present(data_dict.get("chatId"), data_dict.get("ChatId"))
    groupchat_id = _first_present(
        data_dict.get("groupChatId"),
        data_dict.get("GroupChatId"),
        data_dict.get("groupchatId"),
        data_dict.get("GroupchatId"),
    )
    channel_id = _first_present(data_dict.get("channelId"), data_dict.get("ChannelId"))

    current_message_or_reply_id = _first_present(data_dict.get("id"), data_dict.get("Id"))
    parent_message_id = _first_present(data_dict.get("messageId"), data_dict.get("MessageId"))

    context: dict[str, Any] = {
        "event": event_type,
        "userId": author_user_id,
    }
    if task_id is not None:
        context["taskId"] = task_id
    if project_id is not None:
        context["projectId"] = project_id
    if chat_id is not None:
        context["chatId"] = chat_id
    if groupchat_id is not None:
        context["groupChatId"] = groupchat_id
    if channel_id is not None:
        context["channelId"] = channel_id

    if surface in MESSAGE_SURFACES or event_type in REPLY_EVENT_TYPES:
        context["messageId"] = parent_message_id if event_type in REPLY_EVENT_TYPES and parent_message_id is not None else current_message_or_reply_id
    if event_type in REPLY_EVENT_TYPES and current_message_or_reply_id is not None:
        context["replyId"] = current_message_or_reply_id

    request_html = _first_present(data_dict.get("message"), data_dict.get("Message"), "")
    skill_payload = {
        "context": context,
        "request": request_html if isinstance(request_html, str) else "",
    }

    instructions = event.get("instructions") if isinstance(event.get("instructions"), str) else payload.get("instructions")
    if isinstance(instructions, str):
        skill_payload["instructions"] = instructions

    agent_instructions = event.get("agentInstructions") if isinstance(event.get("agentInstructions"), str) else payload.get("agentInstructions")
    if isinstance(agent_instructions, str):
        skill_payload["agentInstructions"] = agent_instructions

    return skill_payload


def normalize_basicops_event(
    payload: dict[str, Any],
    *,
    agent_id: str,
    agent_name: str | None = None,
    self_user_id: int | str | None = None,
    mention_terms: list[str] | set[str] | tuple[str, ...] | None = None,
    other_agent_terms: list[str] | set[str] | tuple[str, ...] | None = None,
) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValueError("payload must be a dict")

    event = _coerce_primary_event(payload)
    event_type = event.get("event")

    surface = EVENT_SURFACES.get(event_type, "unknown")
    event_user = _as_dict(event.get("user"))
    data = event.get("data")
    data_dict = _as_dict(data)
    task_obj = _pick_task_object(data)
    task_from_data = _as_dict(data_dict.get("task"))
    project_from_data = _as_dict(data_dict.get("project"))

    is_task_lifecycle = event_type in TASK_LIFECYCLE_EVENTS

    original_id = _first_present(
        data_dict.get("id"),
        task_obj.get("id"),
        data_dict.get("Id"),
        task_obj.get("Id"),
    )
    original_id_fallback = _first_present(
        data_dict.get("Id"),
        task_obj.get("Id"),
        data_dict.get("id"),
        task_obj.get("id"),
    )

    message_entity_id = _first_present(data_dict.get("id"), data_dict.get("Id")) if surface in MESSAGE_SURFACES else None
    reply_target_message_id = _first_present(
        data_dict.get("messageId"),
        data_dict.get("MessageId"),
        message_entity_id if surface in MESSAGE_SURFACES else None,
    )

    author_user_id = _first_present(
        data_dict.get("userId"),
        data_dict.get("UserId"),
        event_user.get("id"),
        event_user.get("Id"),
        _as_dict(data_dict.get("user")).get("id"),
        _as_dict(data_dict.get("user")).get("Id"),
    )

    task_id = _first_present(
        data_dict.get("taskId"),
        data_dict.get("TaskId"),
        task_from_data.get("id"),
        task_from_data.get("Id"),
        task_obj.get("id"),
        task_obj.get("Id"),
    )
    project_id = _first_present(
        data_dict.get("projectId"),
        data_dict.get("ProjectId"),
        project_from_data.get("id"),
        project_from_data.get("Id"),
        _as_dict(task_obj.get("project")).get("id"),
        _as_dict(task_obj.get("project")).get("Id"),
    )
    chat_id = _first_present(data_dict.get("chatId"), data_dict.get("ChatId"))
    groupchat_id = _first_present(
        data_dict.get("groupChatId"),
        data_dict.get("GroupChatId"),
        data_dict.get("groupchatId"),
        data_dict.get("GroupchatId"),
    )
    channel_id = _first_present(data_dict.get("channelId"), data_dict.get("ChannelId"))

    assignee_user_id = _first_present(
        _as_dict(task_obj.get("assignee")).get("id"),
        _as_dict(task_obj.get("assignee")).get("Id"),
        _as_dict(_as_dict(_as_dict(task_obj.get("change")).get("assignee")).get("to")).get("id"),
        _as_dict(_as_dict(_as_dict(task_obj.get("change")).get("assignee")).get("to")).get("Id"),
    )

    message_html = _first_present(data_dict.get("message"), data_dict.get("Message"), "") if not is_task_lifecycle else ""
    message_text = html_to_text(message_html)

    self_terms = _clean_terms([
        agent_id,
        agent_name or agent_id,
        *(_clean_terms(mention_terms)),
    ])
    other_terms = _clean_terms(other_agent_terms)

    mentions_self = _has_any_term(message_text, self_terms)
    mentions_other_agents = _has_any_term(message_text, other_terms)
    project_team_membership_notice = surface == "project_message" and _is_project_team_membership_notice(message_text, self_terms)

    trigger = {
        "originalEvent": event_type,
        "originalId": original_id,
        "originalIdFallback": original_id_fallback,
        "messageEntityId": message_entity_id,
        "replyTargetMessageId": reply_target_message_id,
        "authorUserId": author_user_id,
        "actorUserId": _first_present(event_user.get("id"), event_user.get("Id")),
        "selfUserId": self_user_id,
        "isSelfMessage": self_user_id is not None and author_user_id == self_user_id,
        "taskId": task_id,
        "projectId": project_id,
        "chatId": chat_id,
        "groupChatId": groupchat_id,
        "channelId": channel_id,
        "assigneeUserId": assignee_user_id,
    }

    normalized = {
        "schemaVersion": "thor.v2.input/1",
        "agent": {
            "id": agent_id,
            "name": agent_name or agent_id,
            "selfUserId": self_user_id,
        },
        "event": {
            "type": event_type,
            "surface": surface,
            "timestamp": event.get("timestamp"),
            "companyId": event.get("companyId"),
            "webhookId": event.get("webhookId"),
            "updates": event.get("updates"),
        },
        "trigger": trigger,
        "request": {
            "html": message_html,
            "text": message_text,
            "mentionsSelf": mentions_self,
            "mentionsOtherAgents": mentions_other_agents,
            "isProjectTeamMembershipNotice": project_team_membership_notice,
        },
        "context": {
            "task": _normalize_task_snapshot(task_obj if is_task_lifecycle else (task_from_data or task_obj)),
            "project": {
                "id": project_id,
                "title": _first_present(
                    project_from_data.get("title"),
                    project_from_data.get("Title"),
                    project_from_data.get("name"),
                    project_from_data.get("Name"),
                    _as_dict(task_obj.get("project")).get("title"),
                    _as_dict(task_obj.get("project")).get("Title"),
                ),
            } if project_id is not None else None,
            "message": {
                "id": message_entity_id,
                "replyTargetMessageId": reply_target_message_id,
                "created": _first_present(data_dict.get("created"), data_dict.get("Created")),
            } if surface in MESSAGE_SURFACES else None,
        },
        "capabilities": {
            "hasTaskId": task_id is not None,
            "hasProjectId": project_id is not None,
            "hasChatId": chat_id is not None,
            "hasGroupChatId": groupchat_id is not None,
            "hasChannelId": channel_id is not None,
            "hasReplyTargetMessageId": reply_target_message_id is not None,
            "canReplyInMessage": reply_target_message_id is not None,
            "canCreateTaskMessage": task_id is not None,
            "canCreateProjectMessage": project_id is not None and surface == "project_message",
            "canCreateChatMessage": chat_id is not None and surface == "chat_message",
            "canCreateGroupchatMessage": groupchat_id is not None and surface == "groupchat_message",
            "canCreateChannelMessage": channel_id is not None and surface == "channel_message",
            "canUpdateCurrentTask": task_id is not None,
        },
        "rawRefs": {
            "dataShape": "list" if isinstance(data, list) else "dict" if isinstance(data, dict) else type(data).__name__,
        },
    }

    return normalized


def main() -> int:
    parser = argparse.ArgumentParser(description="Normalize a BasicOps webhook payload for Thor v2")
    parser.add_argument("payload", nargs="?", help="Optional path to a JSON payload file. Defaults to stdin.")
    parser.add_argument("--agent-id", default="thor")
    parser.add_argument("--agent-name", default="Thor")
    parser.add_argument("--self-user-id", type=int)
    parser.add_argument("--mention-term", action="append", default=[])
    parser.add_argument("--other-agent-term", action="append", default=[])
    parser.add_argument("--pretty", action="store_true")
    args = parser.parse_args()

    if args.payload:
        with open(args.payload, "r", encoding="utf-8") as f:
            payload = json.load(f)
    else:
        payload = json.load(sys.stdin)

    normalized = normalize_basicops_event(
        payload,
        agent_id=args.agent_id,
        agent_name=args.agent_name,
        self_user_id=args.self_user_id,
        mention_terms=args.mention_term,
        other_agent_terms=args.other_agent_term,
    )

    if args.pretty:
        print(json.dumps(normalized, indent=2))
    else:
        print(json.dumps(normalized))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
