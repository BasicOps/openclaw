#!/usr/bin/env python3
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
import platform
import shlex
from pathlib import Path
import sys

from agent_naming import default_display_name, validate_agent_id


def render_text(text: str, replacements: dict[str, str]) -> str:
    for key, value in replacements.items():
        text = text.replace(key, value)
    return text


def detect_default_target_home() -> str:
    env_home = os.environ.get("HOME", "").strip()
    if env_home:
        return env_home.rstrip("/") or "/"
    return str(Path.home())


def detect_platform_name() -> str:
    return platform.system() or "Unknown"


def resolve_service_manager(requested: str, platform_name: str) -> str:
    if requested != "auto":
        return requested
    if platform_name == "Darwin":
        return "launchd"
    return "systemd"


def require_bundle_file(path: Path) -> None:
    if not path.is_file():
        raise SystemExit(f"Required bundle file not found: {path}")


def shell_block(lines: list[str]) -> str:
    return "```bash\n" + " \\\n".join(lines) + "\n```"


def command_list_block(commands: list[str]) -> str:
    return "```bash\n" + "\n".join(commands) + "\n```"


def backup_file(path: Path) -> Path:
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup_path = path.with_name(f"{path.name}.bak.{timestamp}")
    backup_path.write_text(path.read_text())
    return backup_path


def write_executable(path: Path, content: str) -> None:
    path.write_text(content)
    path.chmod(0o755)


def default_main_agent_snippet(openclaw_config_path: Path) -> dict[str, object]:
    workspace_main = openclaw_config_path.parent / "workspace-main"
    return {
        "id": "main",
        "name": "Main",
        "workspace": str(workspace_main),
        "tools": {
            "profile": "coding",
        },
    }


def discover_openclaw_gateway_port(config_path: str) -> str | None:
    path = Path(config_path).expanduser()
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text())
    except Exception:
        return None
    gateway = data.get("gateway") if isinstance(data, dict) else None
    if not isinstance(gateway, dict):
        return None
    port = gateway.get("port")
    if isinstance(port, int) and port > 0:
        return str(port)
    if isinstance(port, str) and port.strip().isdigit():
        return port.strip()
    return None


def register_agent_in_openclaw_config(openclaw_config_path: Path, agent_snippet: dict[str, object], make_backup: bool = True) -> tuple[str, Path | None]:
    if not openclaw_config_path.is_file():
        raise SystemExit(f"OpenClaw config not found: {openclaw_config_path}")

    try:
        data = json.loads(openclaw_config_path.read_text())
    except Exception as exc:
        raise SystemExit(f"Could not parse OpenClaw config JSON at {openclaw_config_path}: {exc}") from exc

    if not isinstance(data, dict):
        raise SystemExit(f"OpenClaw config root must be a JSON object: {openclaw_config_path}")

    agents = data.setdefault("agents", {})
    if not isinstance(agents, dict):
        raise SystemExit(f"Expected 'agents' to be a JSON object in {openclaw_config_path}")

    agent_list = agents.setdefault("list", [])
    if not isinstance(agent_list, list):
        raise SystemExit(f"Expected 'agents.list' to be a JSON array in {openclaw_config_path}")

    agent_id = str(agent_snippet.get("id", "")).strip()
    if not agent_id:
        raise SystemExit("Agent snippet is missing a valid id")

    for existing in agent_list:
        if isinstance(existing, dict) and str(existing.get("id", "")).strip() == agent_id:
            if existing == agent_snippet:
                return "already-present", None
            raise SystemExit(
                f"Agent id '{agent_id}' already exists in {openclaw_config_path} with different settings. "
                "Update it manually instead of overwriting automatically."
            )

    backup_path = backup_file(openclaw_config_path) if make_backup else None
    seeded_main = False
    if not agent_list and agent_id != "main":
        main_snippet = default_main_agent_snippet(openclaw_config_path)
        agent_list.append(main_snippet)
        Path(str(main_snippet["workspace"])).mkdir(parents=True, exist_ok=True)
        seeded_main = True
    agent_list.append(agent_snippet)
    openclaw_config_path.write_text(json.dumps(data, indent=2) + "\n")
    return ("added-with-main-seeded" if seeded_main else "added"), backup_path


def main() -> int:
    script_dir = Path(__file__).resolve().parent
    default_bundle_root = script_dir.parent

    parser = argparse.ArgumentParser(description="Scaffold a named BasicOps agent from the replication bundle")
    parser.add_argument("--bundle-root", default=str(default_bundle_root))
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--agent-id", required=True)
    parser.add_argument("--display-name")
    parser.add_argument("--basicops-profile", required=True)
    parser.add_argument("--hook-path")
    parser.add_argument("--mapping-name")
    parser.add_argument("--shim-port", default="18891")
    parser.add_argument("--openclaw-hook-port")
    parser.add_argument("--target-home", help="Target home directory. Defaults to the current user's home.")
    parser.add_argument("--service-manager", choices=["auto", "systemd", "launchd"], default="auto")
    parser.add_argument("--path-with-mcporter")
    parser.add_argument("--wrapper-path")
    parser.add_argument("--self-context-cache-path")
    parser.add_argument("--preack-webhook-path")
    parser.add_argument("--preack-workdir")
    parser.add_argument("--openclaw-config-path")
    parser.add_argument("--hooks-token", default="REPLACE_ME")
    parser.add_argument("--hooks-token-generated", action="store_true", help="Mark that the hooks token was newly generated for this setup")
    parser.add_argument("--register-agent", action="store_true", help="Also append the generated agent to agents.list in the target OpenClaw config")
    parser.add_argument("--no-agent-config-backup", action="store_true", help="Do not create a timestamped backup before modifying the OpenClaw config")
    args = parser.parse_args()

    agent_id = validate_agent_id(args.agent_id)

    display_name = args.display_name or default_display_name(agent_id)
    hook_path = args.hook_path or f"basicops-{agent_id}"
    mapping_name = args.mapping_name or f"BasicOps {display_name} Hook"
    default_target_home = detect_default_target_home()
    target_home = (args.target_home or default_target_home).rstrip("/") or default_target_home
    platform_name = detect_platform_name()
    service_manager = resolve_service_manager(args.service_manager, platform_name)
    bundle_root = Path(args.bundle_root).expanduser()
    path_with_mcporter = args.path_with_mcporter or f"{target_home}/.npm-global/bin:{target_home}/.local/bin:/usr/local/bin:/usr/bin:/bin"
    wrapper_path = args.wrapper_path or str((bundle_root / "scripts" / "basicops_mcp.py").resolve())
    self_context_cache = args.self_context_cache_path or f"{target_home}/.cache/basicops-agents/{agent_id}-self.json"
    preack_webhook_path = args.preack_webhook_path or str((bundle_root / "scripts" / "preack_webhook.py").resolve())
    preack_workdir = args.preack_workdir or str(bundle_root.resolve())
    openclaw_config_path = args.openclaw_config_path or f"{target_home}/.openclaw/openclaw.json"
    openclaw_hook_port = args.openclaw_hook_port or discover_openclaw_gateway_port(openclaw_config_path) or "18789"
    python_bin = sys.executable or "/usr/bin/python3"
    python_bin_shell = shlex.quote(python_bin)

    output_dir = Path(args.output_dir).expanduser()
    templates_dir = bundle_root / "templates"

    env_template = templates_dir / "env" / "agent.env.template"
    if service_manager == "launchd":
        service_template = templates_dir / "launchd" / "basicops-preack.agent.plist.template"
    else:
        service_template = templates_dir / "systemd" / "basicops-preack@.service.template"
    gateway_hooks_token_template = templates_dir / "systemd" / "openclaw-gateway-hooks-token.conf.template"
    install_doc = bundle_root / "docs" / "INSTALL.md"
    prompt_template = templates_dir / "prompts" / "basicops-worker-policy.template.md"
    renderer_script = bundle_root / "scripts" / "render_basicops_hook_config.py"
    webhook_helper_script = bundle_root / "scripts" / "ensure_basicops_webhook.py"
    relative_install_doc = install_doc.resolve()
    relative_prompt_template = prompt_template.resolve()
    relative_renderer_script = renderer_script.resolve()
    relative_webhook_helper_script = webhook_helper_script.resolve()

    required_files = [env_template, service_template, install_doc, prompt_template, renderer_script, webhook_helper_script]
    if service_manager == "systemd":
        required_files.append(gateway_hooks_token_template)

    for path in required_files:
        require_bundle_file(path)

    launchd_label = f"com.openclaw.basicops-preack.{agent_id}"
    launchd_log_dir = f"{target_home}/Library/Logs/basicops-agents"
    launchd_stdout_path = f"{launchd_log_dir}/{agent_id}.log"
    launchd_stderr_path = f"{launchd_log_dir}/{agent_id}.err.log"

    replacements = {
        "{{AGENT_ID}}": agent_id,
        "{{AGENT_DISPLAY_NAME}}": display_name,
        "{{BASICOPS_PROFILE}}": args.basicops_profile,
        "{{PATH_WITH_MCPORTER}}": path_with_mcporter,
        "{{SHIM_PORT}}": args.shim_port,
        "{{OPENCLAW_HOOK_PORT}}": openclaw_hook_port,
        "{{HOOK_PATH}}": hook_path,
        "{{OPENCLAW_HOOKS_TOKEN}}": args.hooks_token,
        "{{BASICOPS_MCP_WRAPPER}}": wrapper_path,
        "{{SELF_CONTEXT_CACHE_PATH}}": self_context_cache,
        "{{PREACK_WEBHOOK_PATH}}": preack_webhook_path,
        "{{PREACK_WORKDIR}}": preack_workdir,
        "{{LAUNCHD_LABEL}}": launchd_label,
        "{{LAUNCHD_LOG_DIR}}": launchd_log_dir,
        "{{LAUNCHD_STDOUT_PATH}}": launchd_stdout_path,
        "{{LAUNCHD_STDERR_PATH}}": launchd_stderr_path,
        "{{PYTHON_BIN}}": python_bin,
    }

    output_dir.mkdir(parents=True, exist_ok=True)
    env_out = output_dir / f"{agent_id}.env"
    if service_manager == "launchd":
        service_out = output_dir / f"{launchd_label}.plist"
    else:
        service_out = output_dir / "basicops-preack@.service"
    gateway_hooks_token_out = output_dir / "openclaw-gateway-hooks-token.conf"
    values_out = output_dir / f"{agent_id}.values.env"
    agent_snippet_out = output_dir / f"{agent_id}.openclaw-agent.json"
    persona_example_out = output_dir / f"{agent_id}.basicops-personas.example.json"
    install_context_out = output_dir / "install-context.json"
    openclaw_prompt_out = output_dir / "OPENCLAW-INSTALL-PROMPT.txt"
    after_restart_prompt_out = output_dir / "AFTER-GATEWAY-RESTART.txt"
    install_live_out = output_dir / "INSTALL-LIVE-FILES.sh"
    finish_local_out = output_dir / "FINISH-LOCAL-INSTALL.sh"
    precheck_out = output_dir / "PRECHECK-AGENT-INSTALL.sh"
    readme_out = output_dir / "NEXT-STEPS.md"
    gateway_hooks_token_install_path = f"{target_home}/.config/systemd/user/openclaw-gateway.service.d/70-basicops-hooks-token.conf"
    generated_gateway_dropin = args.hooks_token_generated and service_manager == "systemd"

    agent_workspace = f"{target_home}/.openclaw/workspace-{agent_id}"
    agent_snippet = {
        "id": agent_id,
        "name": display_name,
        "workspace": agent_workspace,
        "identity": {
            "name": display_name,
        },
        "tools": {
            "profile": "coding",
        },
        "runtime": {
            "type": "acp",
            "acp": {
                "agent": "codex",
                "backend": "acpx",
                "mode": "persistent",
                "cwd": agent_workspace,
            },
        },
    }

    env_out.write_text(render_text(env_template.read_text(), replacements))
    service_out.write_text(render_text(service_template.read_text(), replacements))
    if generated_gateway_dropin:
        gateway_hooks_token_out.write_text(render_text(gateway_hooks_token_template.read_text(), replacements))
    values_out.write_text(
        "\n".join([
            f"AGENT_ID={agent_id}",
            f"AGENT_DISPLAY_NAME={display_name}",
            f"BASICOPS_PROFILE={args.basicops_profile}",
            f"HOOK_PATH={hook_path}",
            f"MAPPING_NAME={mapping_name}",
            f"SHIM_PORT={args.shim_port}",
            f"OPENCLAW_HOOK_PORT={openclaw_hook_port}",
            f"TARGET_HOME={target_home}",
            f"PATH_WITH_MCPORTER={path_with_mcporter}",
            f"BASICOPS_MCP_WRAPPER={wrapper_path}",
            f"SELF_CONTEXT_CACHE_PATH={self_context_cache}",
            f"PREACK_WEBHOOK_PATH={preack_webhook_path}",
            f"PREACK_WORKDIR={preack_workdir}",
            f"OPENCLAW_CONFIG_PATH={openclaw_config_path}",
            f"OPENCLAW_HOOKS_TOKEN={args.hooks_token}",
            "REQUIRE_EXPLICIT_MENTION=true",
            "SKIP_IF_OTHER_AGENT_MENTIONED=true",
            f"MENTION_TERMS={agent_id},{display_name}",
            "OTHER_AGENT_TERMS=",
            "",
        ])
    )
    agent_snippet_out.write_text(json.dumps(agent_snippet, indent=2) + "\n")
    persona_example_out.write_text(
        json.dumps({
            "personas": {
                args.basicops_profile: {
                    "headers": {
                        "Authorization": "Bearer YOUR_BASICOPS_API_KEY"
                    }
                }
            }
        }, indent=2) + "\n"
    )

    registration_state = "not-requested"
    registration_backup_path: Path | None = None
    if args.register_agent:
        registration_state, registration_backup_path = register_agent_in_openclaw_config(
            Path(openclaw_config_path).expanduser(),
            agent_snippet,
            make_backup=not args.no_agent_config_backup,
        )

    service_manager_check_cmd = (
        "launchctl print gui/$(id -u) >/dev/null && echo 'launchd ok' || echo 'launchd unavailable'"
        if service_manager == "launchd"
        else "systemctl --user status --no-pager >/dev/null && echo 'systemd user ok' || echo 'systemd user unavailable'"
    )

    dependency_check_cmd = command_list_block([
        f"{python_bin_shell} --version",
        "mcporter --version",
        "openclaw status",
        f"test -f {wrapper_path} && echo 'wrapper ok' || echo 'wrapper missing'",
        f"test -f {preack_webhook_path} && echo 'preack ok' || echo 'preack missing'",
        f"test -f {target_home}/.config/basicops-agents/basicops-personas.json && echo 'personas ok' || echo 'personas missing'",
        service_manager_check_cmd,
    ])

    self_context_cmd = shell_block([
        f"{python_bin_shell} {shlex.quote(wrapper_path)}",
        f"  --as {args.basicops_profile}",
        "  get-self-context",
        f"  --agent-id {agent_id}",
        f"  --cache-path {self_context_cache}",
        "  --refresh",
    ])

    webhook_check_cmd = shell_block([
        f"{python_bin_shell} {shlex.quote(str(relative_webhook_helper_script))}",
        f"  --profile {args.basicops_profile}",
        f"  --agent-id {agent_id}",
        f"  --public-webhook-url {public_webhook_url}",
        f"  --wrapper-path {wrapper_path}",
    ])

    webhook_ensure_cmd = shell_block([
        f"{python_bin_shell} {shlex.quote(str(relative_webhook_helper_script))}",
        f"  --profile {args.basicops_profile}",
        f"  --agent-id {agent_id}",
        f"  --public-webhook-url {public_webhook_url}",
        f"  --wrapper-path {wrapper_path}",
        "  --create-if-missing",
    ])

    render_preview_cmd = shell_block([
        f"{python_bin_shell} {shlex.quote(str(relative_renderer_script))}",
        f"  --template {relative_prompt_template}",
        f"  --openclaw-config {openclaw_config_path}",
        f"  --self-context-cache {self_context_cache}",
        f"  --agent-id {agent_id}",
        f"  --basicops-profile {args.basicops_profile}",
        f"  --hook-path {hook_path}",
        f"  --display-name {display_name}",
        f"  --mapping-name \"{mapping_name}\"",
        f"  --wrapper-path {wrapper_path}",
        "  --mode render",
        "  --stdout diff",
    ])

    render_summary_cmd = shell_block([
        f"{python_bin_shell} {shlex.quote(str(relative_renderer_script))}",
        f"  --template {relative_prompt_template}",
        f"  --openclaw-config {openclaw_config_path}",
        f"  --self-context-cache {self_context_cache}",
        f"  --agent-id {agent_id}",
        f"  --basicops-profile {args.basicops_profile}",
        f"  --hook-path {hook_path}",
        f"  --display-name {display_name}",
        f"  --mapping-name \"{mapping_name}\"",
        f"  --wrapper-path {wrapper_path}",
        "  --mode render",
        "  --stdout summary",
    ])

    apply_cmd_lines = [
        f"{python_bin_shell} {shlex.quote(str(relative_renderer_script))}",
        f"  --template {relative_prompt_template}",
        f"  --openclaw-config {openclaw_config_path}",
        f"  --self-context-cache {self_context_cache}",
        f"  --agent-id {agent_id}",
        f"  --basicops-profile {args.basicops_profile}",
        f"  --hook-path {hook_path}",
        f"  --display-name {display_name}",
        f"  --mapping-name \"{mapping_name}\"",
        f"  --wrapper-path {wrapper_path}",
    ]
    if args.hooks_token != "REPLACE_ME":
        apply_cmd_lines.append(f"  --hooks-token {args.hooks_token}")
    apply_cmd_lines.extend([
        "  --mode apply",
        "  --backup",
    ])
    apply_cmd = shell_block(apply_cmd_lines)

    if service_manager == "launchd":
        service_install_path = f"{target_home}/Library/LaunchAgents/{service_out.name}"
        install_copy_cmd = command_list_block([
            f"mkdir -p ~/.config/basicops-agents {target_home}/Library/LaunchAgents {launchd_log_dir} {target_home}/.cache/basicops-agents",
            f"cp {env_out} ~/.config/basicops-agents/{agent_id}.env",
            f"cp {service_out} {service_install_path}",
        ])
    else:
        service_install_path = f"{target_home}/.config/systemd/user/basicops-preack@.service"
        install_copy_cmd = command_list_block([
            f"mkdir -p ~/.config/basicops-agents ~/.config/systemd/user {target_home}/.cache/basicops-agents {target_home}/.config/systemd/user/openclaw-gateway.service.d",
            f"cp {env_out} ~/.config/basicops-agents/{agent_id}.env",
            f"cp {service_out} {service_install_path}",
            *([f"cp {gateway_hooks_token_out} {gateway_hooks_token_install_path}"] if generated_gateway_dropin else []),
            "systemctl --user daemon-reload",
        ])

    live_env_path = f"{target_home}/.config/basicops-agents/{agent_id}.env"

    manual_register_agent_cmd = shell_block([
        f"{python_bin_shell} - <<'PY'",
        "import json",
        f"from pathlib import Path",
        f"config_path = Path({json.dumps(openclaw_config_path)}).expanduser()",
        f"snippet_path = Path({json.dumps(str(agent_snippet_out))}).expanduser()",
        "data = json.loads(config_path.read_text())",
        "snippet = json.loads(snippet_path.read_text())",
        "agents = data.setdefault('agents', {})",
        "agent_list = agents.setdefault('list', [])",
        "agent_id = snippet['id']",
        "workspace_main = config_path.parent / 'workspace-main'",
        "if any(isinstance(item, dict) and item.get('id') == agent_id for item in agent_list):",
        "    print(f\"agent already present: {agent_id}\")",
        "else:",
        "    if not agent_list and agent_id != 'main':",
        "        agent_list.append({",
        "            'id': 'main',",
        "            'name': 'Main',",
        "            'workspace': str(workspace_main),",
        "            'tools': {'profile': 'coding'},",
        "        })",
        "        workspace_main.mkdir(parents=True, exist_ok=True)",
        "        print('seeded main agent')",
        "    agent_list.append(snippet)",
        "    config_path.write_text(json.dumps(data, indent=2) + '\\n')",
        "    print(f\"added agent: {agent_id}\")",
        "PY",
    ])

    registration_status_lines = []
    if registration_state == "added":
        registration_status_lines.append(f"- agent registration: already added to `agents.list` in `{openclaw_config_path}`")
        if registration_backup_path is not None:
            registration_status_lines.append(f"- config backup: `{registration_backup_path}`")
    elif registration_state == "added-with-main-seeded":
        registration_status_lines.append(f"- agent registration: already added to `agents.list` in `{openclaw_config_path}`")
        registration_status_lines.append("- default control-panel agent: seeded `main` automatically because this was the first explicit non-main agent")
        if registration_backup_path is not None:
            registration_status_lines.append(f"- config backup: `{registration_backup_path}`")
    elif registration_state == "already-present":
        registration_status_lines.append(f"- agent registration: `{agent_id}` was already present in `agents.list` in `{openclaw_config_path}`")
    else:
        registration_status_lines.append(f"- agent registration: not yet applied to `{openclaw_config_path}`")

    persona_config_path = f"{target_home}/.config/basicops-agents/basicops-personas.json"
    persona_json_snippet = (
        "```json\n"
        "{\n"
        '  "personas": {\n'
        f'    "{args.basicops_profile}": {{\n'
        '      "headers": {\n'
        '        "Authorization": "Bearer YOUR_BASICOPS_API_KEY"\n'
        '      }\n'
        '    }\n'
        '  }\n'
        "}\n"
        "```"
    )

    if service_manager == "launchd":
        start_cmd = command_list_block([
            f"ls -l {live_env_path}",
            f"launchctl bootout gui/$(id -u) {service_install_path} >/dev/null 2>&1 || true",
            f"launchctl bootstrap gui/$(id -u) {service_install_path}",
            f"launchctl kickstart -k gui/$(id -u)/{launchd_label}",
            f"launchctl print gui/$(id -u)/{launchd_label}",
            f"tail -n 50 {launchd_stdout_path}",
            f"tail -n 50 {launchd_stderr_path}",
        ])
    else:
        start_cmd = command_list_block([
            f"ls -l {live_env_path}",
            "systemctl --user daemon-reload",
            "systemctl --user cat basicops-preack@.service",
            f"systemctl --user start basicops-preack@{agent_id}.service",
            f"systemctl --user enable basicops-preack@{agent_id}.service",
            f"systemctl --user status basicops-preack@{agent_id}.service --no-pager",
            f"journalctl --user -u basicops-preack@{agent_id}.service -n 50 --no-pager",
        ])

    proxy_detect_cmd = command_list_block([
        "command -v caddy >/dev/null && echo 'proxy: caddy already installed' || echo 'proxy: caddy not found'",
        "command -v nginx >/dev/null && echo 'proxy: nginx already installed' || echo 'proxy: nginx not found'",
        "command -v traefik >/dev/null && echo 'proxy: traefik already installed' || echo 'proxy: traefik not found'",
        "ss -ltnp 2>/dev/null | grep -E ':(80|443) ' || true",
    ])
    live_paths_check_cmd = command_list_block([
        f"test -f {live_env_path} && echo 'PASS live env exists: {live_env_path}' || echo 'FAIL live env missing: {live_env_path}'",
        f"test -f {service_install_path} && echo 'PASS live service exists: {service_install_path}' || echo 'FAIL live service missing: {service_install_path}'",
        *([f"test -f {gateway_hooks_token_install_path} && echo 'PASS live gateway hooks-token drop-in exists: {gateway_hooks_token_install_path}' || echo 'FAIL live gateway hooks-token drop-in missing: {gateway_hooks_token_install_path}'"] if generated_gateway_dropin else []),
    ])

    install_live_dirs = "~/Library/LaunchAgents" if service_manager == "launchd" else "~/.config/systemd/user"
    install_live_extra_dir = f"{target_home}/Library/Logs/basicops-agents" if service_manager == "launchd" else f"{target_home}/.config/systemd/user/openclaw-gateway.service.d"
    install_live_dropin_install = f"install -m 0644 {gateway_hooks_token_out} {gateway_hooks_token_install_path}\n" if generated_gateway_dropin else ""
    install_live_dropin_check = f"test -f {gateway_hooks_token_install_path} && echo 'PASS live gateway hooks-token drop-in exists: {gateway_hooks_token_install_path}' || (echo 'FAIL live gateway hooks-token drop-in missing: {gateway_hooks_token_install_path}' && exit 1)\n" if generated_gateway_dropin else ""
    finish_apply_hooks_token_arg = f" --hooks-token {args.hooks_token}" if args.hooks_token != "REPLACE_ME" else ""
    finish_service_block = (
        f"launchctl bootout gui/$(id -u) {service_install_path} >/dev/null 2>&1 || true\n"
        f"launchctl bootstrap gui/$(id -u) {service_install_path}\n"
        f"launchctl kickstart -k gui/$(id -u)/{launchd_label}\n"
        f"launchctl print gui/$(id -u)/{launchd_label}\n"
        if service_manager == "launchd"
        else f"systemctl --user daemon-reload\nsystemctl --user enable --now basicops-preack@{agent_id}.service\nsystemctl --user status basicops-preack@{agent_id}.service --no-pager\n"
    )
    precheck_dropin_var = f"LIVE_GATEWAY_DROPIN={json.dumps(gateway_hooks_token_install_path)}\n" if generated_gateway_dropin else ""
    precheck_dropin_check = "[[ -f \"$LIVE_GATEWAY_DROPIN\" ]] && pass \"live gateway hooks-token drop-in copied: $LIVE_GATEWAY_DROPIN\" || fail \"live gateway hooks-token drop-in missing: $LIVE_GATEWAY_DROPIN\"\n" if generated_gateway_dropin else ""
    install_live_daemon_reload = "systemctl --user daemon-reload\n" if service_manager == "systemd" else ""
    precheck_export_dropin = "export LIVE_GATEWAY_DROPIN\n" if generated_gateway_dropin else ""

    install_live_script = f"""#!/usr/bin/env bash
set -euo pipefail

echo 'TARGET AGENT: {agent_id}'
echo 'Installing live files for {agent_id}...'
mkdir -p ~/.config/basicops-agents {install_live_dirs} {target_home}/.cache/basicops-agents {install_live_extra_dir}
install -m 0644 {env_out} {live_env_path}
install -m 0644 {service_out} {service_install_path}
{install_live_dropin_install}{install_live_daemon_reload}test -f {live_env_path} && echo 'PASS live env exists: {live_env_path}' || (echo 'FAIL live env missing: {live_env_path}' && exit 1)
test -f {service_install_path} && echo 'PASS live service exists: {service_install_path}' || (echo 'FAIL live service missing: {service_install_path}' && exit 1)
{install_live_dropin_check}"""

    finish_local_script = f"""#!/usr/bin/env bash
set -euo pipefail

echo 'TARGET AGENT: {agent_id}'
echo 'READ ONLY: {readme_out}'
echo 'Finishing local install for {agent_id}...'

{python_bin_shell} {shlex.quote(wrapper_path)} --as {args.basicops_profile} get-self-context --agent-id {agent_id} --cache-path {self_context_cache} --refresh

{python_bin_shell} {shlex.quote(str(relative_renderer_script))} --template {relative_prompt_template} --openclaw-config {openclaw_config_path} --self-context-cache {self_context_cache} --agent-id {agent_id} --basicops-profile {args.basicops_profile} --hook-path {hook_path} --display-name {display_name} --mapping-name \"{mapping_name}\" --wrapper-path {wrapper_path} --mode render --stdout summary

{python_bin_shell} {shlex.quote(str(relative_renderer_script))} --template {relative_prompt_template} --openclaw-config {openclaw_config_path} --self-context-cache {self_context_cache} --agent-id {agent_id} --basicops-profile {args.basicops_profile} --hook-path {hook_path} --display-name {display_name} --mapping-name \"{mapping_name}\" --wrapper-path {wrapper_path}{finish_apply_hooks_token_arg} --mode apply --backup

openclaw gateway restart
openclaw gateway status

{finish_service_block}
export OPENCLAW_HOOKS_TOKEN="$({python_bin_shell} - <<'PY'
import json
from pathlib import Path
cfg = json.loads(Path({json.dumps(openclaw_config_path)}).expanduser().read_text())
hooks = cfg.get('hooks') if isinstance(cfg.get('hooks'), dict) else {{}}
value = hooks.get('token') if isinstance(hooks.get('token'), str) else ''
print(value.strip())
PY
)"
curl -i -sS http://127.0.0.1:{openclaw_hook_port}/hooks/{hook_path} -H "Authorization: Bearer ${{OPENCLAW_HOOKS_TOKEN:?set OPENCLAW_HOOKS_TOKEN first}}" -H 'Content-Type: application/json' --data-binary '{{}}'
"""

    precheck_script = f"""#!/usr/bin/env bash
set -euo pipefail

status=0
pass(){{ printf '[PASS] %s\\n' "$1"; }}
fail(){{ printf '[FAIL] %s\\n' "$1"; status=1; }}
warn(){{ printf '[WARN] %s\\n' "$1"; }}

echo 'TARGET AGENT: {agent_id}'
echo 'READ ONLY: {readme_out}'

PERSONAS={json.dumps(persona_config_path)}
PROFILE={json.dumps(args.basicops_profile)}
LIVE_ENV={json.dumps(live_env_path)}
LIVE_SERVICE={json.dumps(service_install_path)}
OPENCLAW_CONFIG={json.dumps(openclaw_config_path)}
EXPECTED_AGENT={json.dumps(agent_id)}
EXPECTED_WORKSPACE={json.dumps(agent_workspace)}
EXPECTED_HOOK={json.dumps(hook_path)}
LOCAL_HOOK_URL={json.dumps(f'http://127.0.0.1:{openclaw_hook_port}/hooks/{hook_path}')}
{precheck_dropin_var}
export PERSONAS PROFILE LIVE_ENV LIVE_SERVICE OPENCLAW_CONFIG EXPECTED_AGENT EXPECTED_WORKSPACE EXPECTED_HOOK LOCAL_HOOK_URL
{precheck_export_dropin}
[[ -f "$PERSONAS" ]] && pass "personas file exists: $PERSONAS" || fail "personas file missing: $PERSONAS"
{python_bin_shell} - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ['PERSONAS']).expanduser()
profile = os.environ['PROFILE']
if not path.is_file():
    raise SystemExit(0)
try:
    data = json.loads(path.read_text())
except Exception as exc:
    print(f'[FAIL] personas file is not valid JSON: {{exc}}')
    raise SystemExit(2)
personas = data.get('personas') if isinstance(data, dict) else None
if isinstance(personas, dict) and profile in personas:
    print(f'[PASS] target persona profile exists: {{profile}}')
else:
    print(f'[FAIL] target persona profile missing: {{profile}}')
    raise SystemExit(1)
PY
rc=$?
if [[ $rc -eq 1 || $rc -eq 2 ]]; then status=1; fi
[[ -f "$LIVE_ENV" ]] && pass "live env copied: $LIVE_ENV" || fail "live env missing: $LIVE_ENV"
[[ -f "$LIVE_SERVICE" ]] && pass "live service copied: $LIVE_SERVICE" || fail "live service missing: $LIVE_SERVICE"
{precheck_dropin_check}{python_bin_shell} - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ['OPENCLAW_CONFIG']).expanduser()
agent_id = os.environ['EXPECTED_AGENT']
expected_workspace = os.environ['EXPECTED_WORKSPACE']
if not path.is_file():
    print(f'[FAIL] OpenClaw config missing: {{path}}')
    raise SystemExit(1)
try:
    data = json.loads(path.read_text())
except Exception as exc:
    print(f'[FAIL] OpenClaw config is not valid JSON: {{exc}}')
    raise SystemExit(1)
agent_list = data.get('agents', {{}}).get('list', []) if isinstance(data, dict) else []
agent = None
for item in agent_list:
    if isinstance(item, dict) and item.get('id') == agent_id:
        agent = item
        break
if not agent:
    print(f'[FAIL] agent not registered in agents.list: {{agent_id}}')
    raise SystemExit(1)
runtime = agent.get('runtime') if isinstance(agent.get('runtime'), dict) else {{}}
acp = runtime.get('acp') if isinstance(runtime.get('acp'), dict) else {{}}
if runtime.get('type') != 'acp':
    print(f'[FAIL] runtime.type is not acp for agent: {{agent_id}}')
    raise SystemExit(1)
if agent.get('workspace') != expected_workspace:
    print(f'[FAIL] workspace mismatch for agent: expected {{expected_workspace}}, found {{agent.get("workspace")}}')
    raise SystemExit(1)
if runtime.get('cwd'):
    print('[FAIL] runtime.cwd is set. For ACP agents, cwd must live under runtime.acp.cwd, not runtime.cwd.')
    raise SystemExit(1)
if acp.get('cwd') != expected_workspace:
    print(f'[FAIL] runtime.acp.cwd mismatch: expected {{expected_workspace}}, found {{acp.get("cwd")}}')
    raise SystemExit(1)
print(f'[PASS] agent registered with valid ACP runtime block: {{agent_id}}')
PY
rc=$?
if [[ $rc -ne 0 ]]; then status=1; fi
{python_bin_shell} - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ['OPENCLAW_CONFIG']).expanduser()
hook_path = os.environ['EXPECTED_HOOK']
agent_id = os.environ['EXPECTED_AGENT']
if not path.is_file():
    raise SystemExit(0)
data = json.loads(path.read_text())
mappings = data.get('hooks', {{}}).get('mappings', []) if isinstance(data, dict) else []
found = False
for item in mappings:
    if not isinstance(item, dict):
        continue
    match = item.get('match') if isinstance(item.get('match'), dict) else {{}}
    if match.get('path') == hook_path and item.get('agentId') == agent_id:
        found = True
        break
if found:
    print(f'[PASS] hook mapping present for {{agent_id}} at /hooks/{{hook_path}}')
else:
    print(f'[FAIL] hook mapping missing for {{agent_id}} at /hooks/{{hook_path}}')
    raise SystemExit(1)
PY
rc=$?
if [[ $rc -ne 0 ]]; then status=1; fi
HOOK_TOKEN="$({python_bin_shell} - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ['OPENCLAW_CONFIG']).expanduser()
if not path.is_file():
    print('')
    raise SystemExit(0)
data = json.loads(path.read_text())
hooks = data.get('hooks') if isinstance(data.get('hooks'), dict) else {{}}
value = hooks.get('token') if isinstance(hooks.get('token'), str) else ''
print(value.strip())
PY
)"
if [[ -z "$HOOK_TOKEN" ]]; then
  fail "local hook check skipped because hooks.token is missing in OpenClaw config"
else
  http_code=$(curl -o /tmp/basicops-hook-check.$$ -sS -w '%{{http_code}}' "$LOCAL_HOOK_URL" -H "Authorization: Bearer $HOOK_TOKEN" -H 'Content-Type: application/json' --data-binary '{{}}' || true)
  if [[ "$http_code" == "200" ]]; then
    pass "local hook passes: $LOCAL_HOOK_URL"
  else
    fail "local hook failed at $LOCAL_HOOK_URL (HTTP $http_code)"
  fi
  rm -f /tmp/basicops-hook-check.$$
fi

if [[ $status -eq 0 ]]; then
  echo 'RESULT: PASS. This agent looks ready locally.'
else
  echo 'RESULT: FAIL. Fix the failed checks above before moving on.'
fi
exit $status
"""

    public_webhook_host_placeholder = "YOUR_HOST_NAME"
    public_webhook_path = f"/webhooks/{hook_path}"
    public_webhook_url = f"https://{public_webhook_host_placeholder}{public_webhook_path}"
    install_context = {
        "agentId": agent_id,
        "displayName": display_name,
        "basicopsProfile": args.basicops_profile,
        "hookPath": hook_path,
        "mappingName": mapping_name,
        "shimPort": int(args.shim_port),
        "openclawHookPort": int(openclaw_hook_port),
        "openclawHookUrl": f"http://127.0.0.1:{openclaw_hook_port}/hooks/{hook_path}",
        "publicWebhookPath": public_webhook_path,
        "publicWebhookUrlTemplate": public_webhook_url,
        "serviceManager": service_manager,
        "targetHome": target_home,
        "generatedFiles": {
            "nextSteps": readme_out.name,
            "env": env_out.name,
            "service": service_out.name,
            "values": values_out.name,
            "agentSnippet": agent_snippet_out.name,
            "personaExample": persona_example_out.name,
            "installContext": install_context_out.name,
            "openclawInstallPrompt": openclaw_prompt_out.name,
            "afterGatewayRestartPrompt": after_restart_prompt_out.name,
            "installLiveFilesScript": install_live_out.name,
            "finishLocalInstallScript": finish_local_out.name,
            "precheckScript": precheck_out.name,
        },
        "livePaths": {
            "env": live_env_path,
            "service": service_install_path,
        },
        "runtimeValidation": {
            "runtimeType": "acp",
            "requiredCwdPath": "runtime.acp.cwd",
            "expectedCwd": agent_workspace,
        },
    }
    if generated_gateway_dropin:
        install_context["generatedFiles"]["gatewayHooksTokenDropin"] = gateway_hooks_token_out.name
        install_context["livePaths"]["gatewayHooksTokenDropin"] = gateway_hooks_token_install_path
    install_context_out.write_text(json.dumps(install_context, indent=2) + "\n")
    write_executable(install_live_out, install_live_script)
    write_executable(finish_local_out, finish_local_script)
    write_executable(precheck_out, precheck_script)
    openclaw_prompt_out.write_text(
        f"TARGET AGENT: {agent_id}\n"
        f"READ ONLY: {readme_out}\n"
        "DO NOT USE ANY OTHER AGENT'S NEXT-STEPS FILE.\n\n"
        "Please help me finish installing this BasicOps agent bundle on this machine. I am a novice user. Read these files first:\n"
        f"1. {readme_out}\n"
        f"2. {install_context_out}\n"
        f"3. {Path('~/basicops-agent-bundle/AI-OPERATOR-GUIDE.md').expanduser()}\n"
        "Then guide me one checkpoint at a time. Run safe validation checks directly when possible, validate outputs, and stop to ask before risky, destructive, or public-facing changes. If something already looks wrong, tell me plainly and fix the simplest thing first.\n"
    )
    after_restart_prompt_out.write_text(
        f"TARGET AGENT: {agent_id}\n"
        f"READ ONLY: {readme_out}\n"
        "RESUME MODE: the OpenClaw gateway restart step has already been run during this install.\n"
        "Do not restart the gateway again unless you first confirm a new config change requires another restart.\n"
        f"Default resume point: Step 5 in {readme_out.name}.\n"
        f"First, verify current state instead of repeating earlier steps.\n"
        f"Run these checks before anything else:\n"
        f"1. openclaw gateway status\n"
        f"2. ./{precheck_out.name}\n"
        f"Then continue from the first unfinished step at or after Step 5.\n"
        f"Confirm specifically whether:\n"
        f"- target agent `{agent_id}` is already registered\n"
        f"- hook path `/hooks/{hook_path}` is already present\n"
        f"- local precheck already passes\n"
    )
    caddy_single_agent_example = (
        "```caddyfile\n"
        f"{public_webhook_host_placeholder} {{\n"
        f"    handle_path {public_webhook_path}* {{\n"
        f"        reverse_proxy 127.0.0.1:{args.shim_port}\n"
        "    }\n"
        "}\n"
        "```"
    )
    caddy_multi_agent_example = (
        "```caddyfile\n"
        f"{public_webhook_host_placeholder} {{\n"
        "    handle_path /webhooks/basicops-worker* {\n"
        "        reverse_proxy 127.0.0.1:18891\n"
        "    }\n\n"
        f"    handle_path {public_webhook_path}* {{\n"
        f"        reverse_proxy 127.0.0.1:{args.shim_port}\n"
        "    }\n"
        "}\n"
        "```"
    )

    registration_status_text = "\n".join(registration_status_lines)
    generated_token_section = (
        f"## Generated OpenClaw hooks token\n\n"
        + (
            f"For your information only: guided setup generated a new hooks token for this setup and already wired it into the generated files below. You do not need to create a separate token by hand.\n\n"
            if generated_gateway_dropin
            else f"For your information only: guided setup generated a new hooks token for this setup and already wired it into the generated hook-apply commands below. You do not need to create a separate token by hand.\n\n"
        )
        + (
            f"A systemd gateway drop-in was also generated for Linux installs:\n"
            f"- `{gateway_hooks_token_out.name}`\n"
            f"- install target: `{gateway_hooks_token_install_path}`\n\n"
            if generated_gateway_dropin else ""
        )
        if args.hooks_token_generated else ""
    )
    generated_files_line = f"- {gateway_hooks_token_out.name}\n" if generated_gateway_dropin else ""
    review_generated_files_text = f" and `{gateway_hooks_token_out.name}`" if generated_gateway_dropin else ""
    copy_generated_files_step = (
        "6. Copy the generated env, service, and gateway hooks-token files into their final locations.\n"
        if generated_gateway_dropin
        else "6. Copy the generated env and service files into their final locations.\n"
    )
    suggested_flow_step7 = (
        "7. The OpenClaw agent registration is already done in `agents.list`.\n"
        if registration_state in {"added", "added-with-main-seeded", "already-present"}
        else f"7. Register the OpenClaw agent in `agents.list` in `{openclaw_config_path}`.\n"
    )
    register_agent_section_body = (
        f"This step is already complete for `{agent_id}`.\n\n"
        if registration_state in {"added", "added-with-main-seeded", "already-present"}
        else (
            f"Add this object under `agents.list` in `{openclaw_config_path}`:\n\n"
            f"```json\n{json.dumps(agent_snippet, indent=2)}\n```\n\n"
            f"You can also copy it directly from `{agent_snippet_out}` or run this helper command:\n\n"
            f"{manual_register_agent_cmd}\n\n"
        )
    )
    gateway_restart_cmd = command_list_block([
        "openclaw gateway restart",
        "openclaw gateway status",
    ])
    hook_runtime_prereq_cmd = command_list_block([
        f"{python_bin_shell} - <<'PY'",
        "import json",
        "from pathlib import Path",
        f"cfg = json.loads(Path({json.dumps(openclaw_config_path)}).expanduser().read_text())",
        "hooks = cfg.get('hooks') if isinstance(cfg.get('hooks'), dict) else {}",
        "gateway = cfg.get('gateway') if isinstance(cfg.get('gateway'), dict) else {}",
        "auth = gateway.get('auth') if isinstance(gateway.get('auth'), dict) else {}",
        "hooks_enabled = hooks.get('enabled')",
        "hooks_token = hooks.get('token') if isinstance(hooks.get('token'), str) else None",
        "gateway_token = auth.get('token') if isinstance(auth.get('token'), str) else None",
        "print(f'hooks.enabled={hooks_enabled!r}')",
        "print(f'hooks.token in config={bool(hooks_token and hooks_token.strip())}')",
        "print(f'gateway.auth.token in config={bool(gateway_token and gateway_token.strip())}')",
        "if hooks_token and gateway_token:",
        "    print(f'hooks.token matches gateway.auth.token={hooks_token.strip() == gateway_token.strip()}')",
        "else:",
        "    print('hooks.token matches gateway.auth.token=unknown (one or both may come from env or SecretRef)')",
        "ok = True",
        "if hooks_enabled is not True:",
        "    ok = False",
        "if not (hooks_token and hooks_token.strip()):",
        "    ok = False",
        "if hooks_token and gateway_token and hooks_token.strip() == gateway_token.strip():",
        "    ok = False",
        "print('PASSED' if ok else 'FAILED')",
        "PY",
    ])
    print_hooks_token_from_config_cmd = command_list_block([
        f"{python_bin_shell} - <<'PY'",
        "import json",
        "from pathlib import Path",
        f"cfg = json.loads(Path({json.dumps(openclaw_config_path)}).expanduser().read_text())",
        "hooks = cfg.get('hooks') if isinstance(cfg.get('hooks'), dict) else {}",
        "value = hooks.get('token') if isinstance(hooks.get('token'), str) else ''",
        "print(value.strip())",
        "PY",
    ])
    load_hooks_token_from_config_cmd = command_list_block([
        f"export OPENCLAW_HOOKS_TOKEN=\"$({python_bin_shell} - <<'PY'",
        "import json",
        "from pathlib import Path",
        f"cfg = json.loads(Path({json.dumps(openclaw_config_path)}).expanduser().read_text())",
        "hooks = cfg.get('hooks') if isinstance(cfg.get('hooks'), dict) else {}",
        "value = hooks.get('token') if isinstance(hooks.get('token'), str) else ''",
        "print(value.strip())",
        "PY",
        ")\"",
        "printf '%s\\n' \"${OPENCLAW_HOOKS_TOKEN:+token_loaded}\"",
    ])
    load_hooks_token_section = (
        f"## Find or load OPENCLAW_HOOKS_TOKEN for curl smoke tests\n\n"
        f"You only need `OPENCLAW_HOOKS_TOKEN` in your current shell for the curl smoke tests below. After the apply step, the simplest source of truth is `hooks.token` in `{openclaw_config_path}`.\n\n"
        f"If you just want to print the raw token value so you can inspect or copy it, use:\n\n"
        f"{print_hooks_token_from_config_cmd}\n\n"
        f"If you want to load it into your current shell, use:\n\n"
        f"{load_hooks_token_from_config_cmd}\n\n"
    )
    local_hook_smoke_cmd = command_list_block([
        f"curl -i -sS http://127.0.0.1:{openclaw_hook_port}/hooks/{hook_path} \\",
        "  -H \"Authorization: Bearer ${OPENCLAW_HOOKS_TOKEN:?set OPENCLAW_HOOKS_TOKEN first}\" \\",
        "  -H 'Content-Type: application/json' \\",
        "  --data-binary '{}'",
    ])
    external_hook_smoke_cmd = command_list_block([
        f"curl -i -sS {public_webhook_url} \\",
        "  -H \"Authorization: Bearer ${OPENCLAW_HOOKS_TOKEN:?set OPENCLAW_HOOKS_TOKEN first}\" \\",
        "  -H 'Content-Type: application/json' \\",
        "  --data-binary '{}'",
    ])

    readme_text = (
        f"# Next steps for {agent_id}\n\n"
        f"Generated files in this folder:\n"
        f"- {env_out.name}\n"
        f"- {service_out.name}\n"
        f"{generated_files_line}"
        f"- {values_out.name}\n"
        f"- {agent_snippet_out.name}\n"
        f"- {persona_example_out.name}\n"
        f"- {install_context_out.name}\n"
        f"- {openclaw_prompt_out.name}\n"
        f"- {after_restart_prompt_out.name}\n"
        f"- {install_live_out.name}\n"
        f"- {finish_local_out.name}\n"
        f"- {precheck_out.name}\n\n"
        f"## Key values\n\n"
        f"- BasicOps profile: `{args.basicops_profile}`\n"
        f"- public webhook path: `{public_webhook_path}`\n"
        f"- local shim target: `127.0.0.1:{args.shim_port}`\n"
        f"- OpenClaw hook target: `127.0.0.1:{openclaw_hook_port}/hooks/{hook_path}`\n\n"
        f"## Before you begin\n\n"
        f"Important: files in this generated folder are not live yet. They do not affect the running service until you copy them into their final locations.\n\n"
        f"If you want the local OpenClaw assistant to guide the rest of the install, paste the contents of `{openclaw_prompt_out.name}` into that assistant after you skim this file once.\n\n"
        f"Target agent safety rail:\n"
        f"- TARGET AGENT: `{agent_id}`\n"
        f"- READ ONLY: `{readme_out}`\n"
        f"- do not use another agent's generated folder for this install\n\n"
        f"Read this file top to bottom once, then work through the steps in order:\n\n"
        f"1. Finish BasicOps account and persona setup.\n"
        f"2. Run the quick sanity checks and detect whether a reverse proxy already exists.\n"
        f"3. Copy the generated files into place with `{install_live_out.name}`.\n"
        f"4. Register the OpenClaw agent if needed, then restart the gateway.\n"
        f"5. Run `{precheck_out.name}` and clear any FAIL lines.\n"
        f"6. Finish local install with `{finish_local_out.name}`.\n"
        f"7. Re-run `{precheck_out.name}` until local checks pass.\n"
        f"8. Configure the public reverse proxy.\n"
        f"9. Test the public webhook path from outside the server.\n"
        f"10. Point BasicOps at that same public webhook path.\n\n"
        f"## Registration status\n\n"
        f"{registration_status_text}\n\n"
        f"## 1. BasicOps login and persona setup\n\n"
        f"If this is a brand new BasicOps-backed agent, do these steps first:\n\n"
        f"1. Log in to BasicOps in the browser.\n"
        f"2. Create the agent user if it does not already exist.\n"
        f"3. Create an API key for that agent user.\n"
        f"4. Copy the API key somewhere safe.\n\n"
        f"The bundle cannot do those BasicOps-side account steps for you.\n\n"
        f"Next you will create or update `basicops-personas.json`. That file establishes the connection between this OpenClaw agent and the BasicOps agent user by storing the BasicOps API key under the selected profile name.\n\n"
        f"Typical persona file path:\n\n"
        f"```bash\n{persona_config_path}\n```\n\n"
        f"Create the directory first if needed:\n\n"
        f"```bash\nmkdir -p {target_home}/.config/basicops-agents\n```\n\n"
        f"If this is the first agent on the machine, you can start from the generated example file in this folder. It already uses profile `{args.basicops_profile}`, so you only need to replace `YOUR_BASICOPS_API_KEY`:\n\n"
        f"```bash\ncp {persona_example_out} {persona_config_path}\n```\n\n"
        f"Add or update the persona entry for profile `{args.basicops_profile}` so it uses the real API key:\n\n"
        f"{persona_json_snippet}\n\n"
        f"Keep the profile name `{args.basicops_profile}` exactly consistent with the commands in this bundle.\n\n"
        f"## 2. Quick sanity checks\n\n"
        f"{dependency_check_cmd}\n\n"
        f"Before planning any public setup work, also detect whether the machine already has a reverse proxy installed and listening:\n\n"
        f"{proxy_detect_cmd}\n\n"
        f"If any of those commands fail, go back to `QUICKSTART.md` and fix the prerequisites before continuing.\n"
        f"If `personas missing` appears above, do not continue to `get-self-context` until `{persona_config_path}` exists and contains the `{args.basicops_profile}` profile.\n\n"
        f"## 3. Review and copy the generated files into place\n\n"
        f"Review and edit `{env_out.name}`{review_generated_files_text} if any placeholder paths or tokens still need changes.\n\n"
        f"This is the step that makes the new values live. If you skip it, the running service may still use older values from an already-installed env file.\n\n"
        f"Recommended idempotent install command:\n\n"
        f"```bash\n./{install_live_out.name}\n```\n\n"
        f"Manual equivalent:\n\n"
        f"{install_copy_cmd}\n\n"
        f"After the copy step, confirm the exact live paths now exist:\n\n"
        f"{live_paths_check_cmd}\n\n"
        f"{generated_token_section}"
        f"## 4. Register the OpenClaw agent and restart the gateway\n\n"
        f"The hook renderer validates that `{agent_id}` already exists in `agents.list`. That prevents a broken route where a hook exists for an agent ID that OpenClaw does not actually know about.\n\n"
        f"{register_agent_section_body}"
        f"Minimum checks before moving on:\n"
        f"- `agents.list` contains an object with `id` = `{agent_id}`\n"
        f"- its `workspace` is `{agent_workspace}`\n"
        f"- its runtime `cwd` is `{agent_workspace}` under `runtime.acp.cwd`\n"
        f"- for ACP agents, do **not** put `cwd` under `runtime.cwd`\n\n"
        f"If you added or changed `agents.list`, restart the OpenClaw gateway before live testing so the runtime definitely picks up the updated config:\n\n"
        f"{gateway_restart_cmd}\n\n"
        f"Important restart boundary: restarting the gateway can interrupt the assistant session that is guiding the install. If that happens, do not restart it again by reflex. Paste `{after_restart_prompt_out.name}` into the assistant, run the checks it lists, and resume at Step 5 unless those checks prove you are already farther along.\n\n"
        f"## 5. Agent-specific local precheck\n\n"
        f"Run this before you do any deeper troubleshooting. It checks the exact agent profile, live copied files, agent registration shape, hook mapping, and local hook path:\n\n"
        f"```bash\n./{precheck_out.name}\n```\n\n"
        f"## 6. Create self-context\n\n"
        f"This calls the BasicOps MCP server using the authorization from `basicops-personas.json` and returns information about the connected BasicOps agent user. That information is cached and reused in the later hook-rendering steps.\n\n"
        f"{self_context_cmd}\n\n"
        f"Expected output should include `userId`, `displayName`, `email`, `timeZone`, `dateFormat`, and `timeFormat`.\n\n"
        f"Hard stop check: confirm the resolved `displayName` and `email` belong to the intended BasicOps agent user for this setup. If it resolves to a previous agent user or the wrong person, stop immediately, fix the API key in `basicops-personas.json`, and rerun this step before you touch hook mappings or webhooks.\n\n"
        f"## 7. Preview and apply the OpenClaw hook mapping\n\n"
        f"Start with the compact summary first. It is easier to read than the full diff:\n\n"
        f"{render_summary_cmd}\n\n"
        f"Quick checklist for the summary output:\n"
        f"- hookPath should be `{hook_path}`\n"
        f"- agentId should be `{agent_id}`\n"
        f"- agentRegistered should be `true`\n"
        f"- mappingName should be `{mapping_name}`\n"
        f"- basicopsProfile should be `{args.basicops_profile}`\n"
        f"- warnings should be empty, or clearly understood before you continue\n\n"
        f"If you want the full diff as well, run:\n\n"
        f"{render_preview_cmd}\n\n"
        f"When the summary looks right, apply the hook mapping with backup:\n\n"
        f"{apply_cmd}\n\n"
        f"## 8. Validate hook prerequisites and load OPENCLAW_HOOKS_TOKEN\n\n"
        f"Quick checks:\n\n"
        f"{hook_runtime_prereq_cmd}\n\n"
        f"After the apply step and gateway restart, you want `hooks.enabled=True` and `hooks.token in config=True`.\n"
        f"If both hook and gateway auth tokens are present, they should not match. The check ends with `PASSED` or `FAILED` so it is easier to scan quickly.\n\n"
        f"{load_hooks_token_section}"
        f"## 9. Local hook smoke test\n\n"
        f"Before involving the public reverse proxy or BasicOps, send a local POST directly to the OpenClaw hook endpoint:\n\n"
        f"{local_hook_smoke_cmd}\n\n"
        f"How to read the result:\n"
        f"- `200 OK` means the local hook endpoint answered successfully\n"
        f"- `Connection refused` means the gateway is down or not listening yet\n"
        f"- `404 Not Found` means the hook path is not active, hooks are disabled, or the mapping was not loaded\n"
        f"- `401 Unauthorized` means the caller token does not match the gateway hooks token\n\n"
        f"If you want one agent-specific command to do the local finish sequence in order, use:\n\n"
        f"```bash\n./{finish_local_out.name}\n```\n\n"
        f"## 10. Start the pre-ack service and check logs\n\n"
        f"{start_cmd}\n\n"
        f"If `systemctl --user cat basicops-preack@.service` says the unit is not found, the copied service file is not visible to the user service manager yet. In that case, go back to step 3, confirm the file really exists at `{service_install_path}`, rerun `systemctl --user daemon-reload`, and then retry this step.\n\n"
        f"If `systemctl --user` fails with a user-bus or session error on headless Linux, the user systemd instance is not available in the current shell yet. A common fix is to run `loginctl enable-linger $(whoami)`, start a fresh login shell, confirm `systemctl --user status --no-pager` works, and then retry this step.\n\n"
        f"## 11. Configure the public reverse proxy\n\n"
        f"Reserve `{public_webhook_path}` for this agent and route it to `127.0.0.1:{args.shim_port}`.\n\n"
        f"This matters because BasicOps will send webhook payloads to your public webhook URL, and the reverse proxy is what forwards that request from the public internet to the local pre-ack service on this machine.\n\n"
        f"At this point the pre-ack service is already running, so port `{args.shim_port}` should normally be in use. That is expected. The earlier preflight and guided setup are the steps that should catch a real port conflict before you reach this point.\n\n"
        f"If you want to confirm the shim is listening locally before you touch the reverse proxy, use this TCP connect check instead:\n\n"
        f"```bash\n"
        f"{python_bin_shell} - <<'PY'\n"
        f"import socket\n"
        f"s = socket.socket()\n"
        f"s.settimeout(1)\n"
        f"try:\n"
        f"    s.connect(('127.0.0.1', {args.shim_port}))\n"
        f"    print('shim port is accepting connections')\n"
        f"except OSError as exc:\n"
        f"    print('shim port is not accepting connections: {args.shim_port} (' + str(exc) + ')')\n"
        f"finally:\n"
        f"    s.close()\n"
        f"PY\n"
        f"```\n\n"
        f"You need some public reverse proxy in front of the shim. The examples below use Caddy, but Caddy is not required. If you already have nginx, Traefik, HAProxy, or another edge proxy, adapt the route there instead.\n\n"
        f"### If you plan to use Caddy on Debian or Ubuntu\n\n"
        f"Use the official Caddy repo so you get a current release instead of an older distro package:\n\n"
        f"```bash\n"
        f"sudo apt update\n"
        f"sudo apt install -y debian-keyring debian-archive-keyring apt-transport-https curl gnupg\n"
        f"curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | sudo gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg\n"
        f"curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | sudo tee /etc/apt/sources.list.d/caddy-stable.list >/dev/null\n"
        f"sudo apt update\n"
        f"sudo apt install -y caddy\n"
        f"sudo systemctl enable --now caddy\n"
        f"sudo systemctl status --no-pager caddy\n"
        f"```\n\n"
        f"### Caddy example, single agent route\n\n"
        f"Replace `{public_webhook_host_placeholder}` with your real hostname:\n\n"
        f"{caddy_single_agent_example}\n\n"
        f"### Caddy example, alongside an existing worker route\n\n"
        f"{caddy_multi_agent_example}\n\n"
        f"After editing `/etc/caddy/Caddyfile`, verify and reload it:\n\n"
        f"```bash\n"
        f"caddy validate --config /etc/caddy/Caddyfile\n"
        f"sudo systemctl reload caddy\n"
        f"```\n\n"
        f"## 12. External webhook smoke test\n\n"
        f"After the local hook smoke test works and the pre-ack service is running, test the public route from outside the server, for example from your laptop:\n\n"
        f"{external_hook_smoke_cmd}\n\n"
        f"How to read the result:\n"
        f"- `200 OK` means the public route answered successfully\n"
        f"- DNS, TLS, timeout, or connection errors mean the public hostname or reverse proxy path is still wrong\n"
        f"- `404 Not Found` usually means the public reverse proxy path is not routing to the shim you expected\n"
        f"- `401 Unauthorized` means the caller token does not match what the public endpoint expects\n\n"
        f"## 13. Create or verify the BasicOps webhook\n\n"
        f"Only do this after the external webhook smoke test works. The URL here must match the same public webhook path you just tested.\n\n"
        f"Use the configured BasicOps MCP profile for this agent instead of a raw curl command. That reuses the API key already stored in `basicops-personas.json`.\n\n"
        f"First, verify identity and current webhook state without changing anything:\n\n"
        f"{webhook_check_cmd}\n\n"
        f"What this check does:\n"
        f"- calls `get_current_user` through the configured BasicOps profile\n"
        f"- calls `list_webhooks` through the same profile\n"
        f"- verifies that any exact matching webhook belongs to the same BasicOps user id\n"
        f"- warns if the BasicOps first name looks unrelated to the intended agent id `{agent_id}`\n\n"
        f"If it warns about an identity mismatch, pause there and resolve that before you create anything. Example: setting up agent `{agent_id}`, but the BasicOps user firstName is different.\n\n"
        f"If the check says no exact webhook exists, create it and verify it in one step:\n\n"
        f"{webhook_ensure_cmd}\n\n"
        f"This helper is intentionally conservative. If the same URL already exists with the wrong user id or the wrong event set, it will stop and ask for review instead of creating duplicates silently.\n\n"
        f"## 14. Ready to test in BasicOps\n\n"
        f"If the local hook smoke test worked, the service is running, and the external webhook smoke test also works, you should now be ready to try this in BasicOps.\n\n"
        f"A simple first test message is:\n"
        f"- `@{display_name} are you there?`\n\n"
        f"If your workspace uses a different mention format, adapt the agent name accordingly.\n\n"
        f"## Common friction points\n\n"
        f"- `{persona_config_path}` must exist before `get-self-context` can work\n"
        f"- the BasicOps profile name must stay `{args.basicops_profile}` everywhere\n"
        f"- the hook path `{hook_path}` and public webhook path `{public_webhook_path}` must stay aligned\n"
        f"- if you changed `agents.list`, restart the gateway before testing hooks\n"
        f"- if local hook tests return `401`, re-check `OPENCLAW_HOOKS_TOKEN`\n"
        f"- if public tests fail but local tests work, the problem is almost always DNS, TLS, or reverse-proxy routing\n\n"
        f"## References\n\n"
        f"- Manual guide: `{relative_install_doc}`\n"
        f"- Values file: `{values_out}`\n"
        f"- Env file: `{env_out}`\n"
        f"- Webhook helper: `{relative_webhook_helper_script}`\n"
        f"- Service file: `{service_out}`\n"
    )

    readme_out.write_text(readme_text)

    print(f"Scaffolded agent bundle files in: {output_dir}")
    print(f"- {env_out}")
    print(f"- {service_out}")
    if args.hooks_token_generated:
        print(f"- {gateway_hooks_token_out}")
    print(f"- {values_out}")
    print(f"- {agent_snippet_out}")
    print(f"- {persona_example_out}")
    print(f"- {install_context_out}")
    print(f"- {openclaw_prompt_out}")
    print(f"- {after_restart_prompt_out}")
    print(f"- {install_live_out}")
    print(f"- {finish_local_out}")
    print(f"- {precheck_out}")
    print(f"- {readme_out}")
    if registration_state == "added":
        print(f"Registered agent '{agent_id}' in {openclaw_config_path}")
        if registration_backup_path is not None:
            print(f"Backup written to: {registration_backup_path}")
    elif registration_state == "added-with-main-seeded":
        print(f"Registered agent '{agent_id}' in {openclaw_config_path}")
        print("Seeded default 'main' agent as well, to preserve web control-panel chat on fresh installs")
        if registration_backup_path is not None:
            print(f"Backup written to: {registration_backup_path}")
    elif registration_state == "already-present":
        print(f"Agent '{agent_id}' was already present in {openclaw_config_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
