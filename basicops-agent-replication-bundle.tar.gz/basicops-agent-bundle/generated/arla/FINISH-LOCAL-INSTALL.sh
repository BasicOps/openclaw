#!/usr/bin/env bash
set -euo pipefail

echo 'TARGET AGENT: arla'
echo 'READ ONLY: /home/hjhlarsen/.openclaw/workspace-basicops/replication-bundle/generated/arla/NEXT-STEPS.md'
echo 'Finishing local install for arla...'

/usr/bin/python3 /home/hjhlarsen/.openclaw/workspace-basicops/replication-bundle/scripts/basicops_mcp.py --as arla get-self-context --agent-id arla --cache-path /home/hjhlarsen/.cache/basicops-agents/arla-self.json --refresh

/usr/bin/python3 /home/hjhlarsen/.openclaw/workspace-basicops/replication-bundle/scripts/render_basicops_hook_config.py --template /home/hjhlarsen/.openclaw/workspace-basicops/replication-bundle/templates/prompts/basicops-worker-policy.template.md --openclaw-config /home/hjhlarsen/.openclaw/openclaw.json --self-context-cache /home/hjhlarsen/.cache/basicops-agents/arla-self.json --agent-id arla --basicops-profile arla --hook-path basicops-arla --display-name Arla --mapping-name "BasicOps Arla Hook" --wrapper-path /home/hjhlarsen/.openclaw/workspace-basicops/replication-bundle/scripts/basicops_mcp.py --message-template 'Arla live webhook.' --deliver false --thinking off --session-key 'hook:arla:{{payload.event}}:{{payload.timestamp}}' --transform-module arla-hook-fast.js --mode render --stdout summary

/usr/bin/python3 /home/hjhlarsen/.openclaw/workspace-basicops/replication-bundle/scripts/render_basicops_hook_config.py --template /home/hjhlarsen/.openclaw/workspace-basicops/replication-bundle/templates/prompts/basicops-worker-policy.template.md --openclaw-config /home/hjhlarsen/.openclaw/openclaw.json --self-context-cache /home/hjhlarsen/.cache/basicops-agents/arla-self.json --agent-id arla --basicops-profile arla --hook-path basicops-arla --display-name Arla --mapping-name "BasicOps Arla Hook" --wrapper-path /home/hjhlarsen/.openclaw/workspace-basicops/replication-bundle/scripts/basicops_mcp.py --message-template 'Arla live webhook.' --deliver false --thinking off --session-key 'hook:arla:{{payload.event}}:{{payload.timestamp}}' --transform-module arla-hook-fast.js --hooks-token 082533d9f6b900e05ed9884ac8c655db6715370ee5909a40 --mode apply --backup

openclaw gateway restart
openclaw gateway status

systemctl --user daemon-reload
systemctl --user enable --now basicops-preack@arla.service
systemctl --user status basicops-preack@arla.service --no-pager

export OPENCLAW_HOOKS_TOKEN="$(/usr/bin/python3 - <<'PY'
import json
from pathlib import Path
cfg = json.loads(Path("/home/hjhlarsen/.openclaw/openclaw.json").expanduser().read_text())
hooks = cfg.get('hooks') if isinstance(cfg.get('hooks'), dict) else {}
value = hooks.get('token') if isinstance(hooks.get('token'), str) else ''
print(value.strip())
PY
)"
curl -i -sS http://127.0.0.1:18789/hooks/basicops-arla -H "Authorization: Bearer ${OPENCLAW_HOOKS_TOKEN:?set OPENCLAW_HOOKS_TOKEN first}" -H 'Content-Type: application/json' --data-binary '{}'
