#!/usr/bin/env bash
set -euo pipefail

status=0
pass(){ printf '[PASS] %s\n' "$1"; }
fail(){ printf '[FAIL] %s\n' "$1"; status=1; }
warn(){ printf '[WARN] %s\n' "$1"; }

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
STATUS_OUT="$(mktemp)"
DIRECT_TEST_JSON="$(mktemp)"
MODEL_TEST_JSON="$(mktemp)"
PUBLIC_BODY="$(mktemp)"
cleanup() { rm -f "$STATUS_OUT" "$DIRECT_TEST_JSON" "$MODEL_TEST_JSON" "$PUBLIC_BODY"; }
trap cleanup EXIT

EXPECTED_AGENT="meriam"
OPENCLAW_CONFIG="/home/hjhlarsen/.openclaw/openclaw.json"
LOCAL_HOOK_URL="http://127.0.0.1:18789/hooks/basicops-meriam"
BOOTSTRAP_FILE="/home/hjhlarsen/.openclaw/workspace-meriam/BOOTSTRAP.md"
PUBLIC_WEBHOOK_URL="${PUBLIC_WEBHOOK_URL:-https://YOUR_HOST_NAME/webhooks/basicops-meriam}"
export EXPECTED_AGENT OPENCLAW_CONFIG LOCAL_HOOK_URL BOOTSTRAP_FILE STATUS_OUT DIRECT_TEST_JSON PUBLIC_WEBHOOK_URL

echo 'TARGET AGENT: meriam'
echo 'READ ONLY: /home/hjhlarsen/basicops-agent-bundle/generated/meriam/NEXT-STEPS.md'
echo 'Running final readiness gate for meriam...'

if "$SCRIPT_DIR/CHECK-READONLY.sh"; then
  pass "read-only config check passes"
else
  fail "read-only config check failed"
fi

if [[ "$PUBLIC_WEBHOOK_URL" == *YOUR_HOST_NAME* ]]; then
  fail 'PUBLIC_WEBHOOK_URL still uses the YOUR_HOST_NAME placeholder. Re-run with PUBLIC_WEBHOOK_URL set to the real public webhook URL.'
fi

if PUBLIC_WEBHOOK_URL="$PUBLIC_WEBHOOK_URL" "$SCRIPT_DIR/TEST-ROUTING.sh"; then
  pass "routing test passes"
else
  fail "routing test failed"
fi

if openclaw status --all >"$STATUS_OUT" 2>&1; then
  pass 'openclaw status --all completed'
else
  fail 'openclaw status --all failed'
fi

if /usr/bin/python3 - <<'PY'
import os, re, sys
from pathlib import Path
agent_id = os.environ['EXPECTED_AGENT']
text = Path(os.environ['STATUS_OUT']).read_text()
pattern = re.compile(rf"^│\s*{re.escape(agent_id)}\b.*│\s*(ABSENT|PRESENT)\s*│", re.M)
match = pattern.search(text)
if not match:
    print(f"[WARN] agent row not found in openclaw status --all: {agent_id}")
    sys.exit(0)
state = match.group(1)
if state != 'ABSENT':
    print(f"[WARN] openclaw status shows Bootstrap file {state} for {agent_id}. That can be normal before the first successful bootstrap run.")
    sys.exit(0)
print(f"[PASS] openclaw status shows Bootstrap file ABSENT for {agent_id}")
PY
then
  :
fi

if [[ -f "$BOOTSTRAP_FILE" ]]; then
  warn "bootstrap file still present on disk: $BOOTSTRAP_FILE (advisory until the agent finishes bootstrap cleanly)"
else
  pass "bootstrap file absent on disk: $BOOTSTRAP_FILE"
fi

if systemctl --user is-active --quiet basicops-preack@meriam.service; then
  pass "pre-ack service is active: basicops-preack@meriam.service"
else
  fail "pre-ack service is not active: basicops-preack@meriam.service"
fi


if openclaw agent --agent "$EXPECTED_AGENT" --message "reply OK" --json --timeout 120 >"$DIRECT_TEST_JSON"; then
  if /usr/bin/python3 - <<'PY'
import json, os, sys
from pathlib import Path
data = json.loads(Path(os.environ['DIRECT_TEST_JSON']).read_text())
texts = []
def walk(node):
    if isinstance(node, dict):
        for key, value in node.items():
            if key in ('finalAssistantVisibleText', 'finalAssistantRawText') and isinstance(value, str):
                texts.append(value.strip())
            walk(value)
    elif isinstance(node, list):
        for item in node:
            walk(item)
walk(data)
reply = next((item for item in texts if item and item != 'NO_REPLY'), '')
if not reply:
    print('[FAIL] direct OpenClaw agent test did not produce a visible reply')
    sys.exit(1)
print(f"[PASS] direct OpenClaw agent test returned a visible reply: {reply[:120]}")
PY
  then
    :
  else
    status=1
  fi
else
  fail 'direct OpenClaw agent test command failed'
fi

HOOK_MODEL="$(/usr/bin/python3 - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ['OPENCLAW_CONFIG']).expanduser()
hook_path = "basicops-meriam"
agent_id = os.environ['EXPECTED_AGENT']
if not path.is_file():
    print('')
    raise SystemExit(0)
data = json.loads(path.read_text())
mappings = data.get('hooks', {}).get('mappings', []) if isinstance(data, dict) else []
for item in mappings:
    if not isinstance(item, dict):
        continue
    match = item.get('match') if isinstance(item.get('match'), dict) else {}
    if match.get('path') == hook_path and item.get('agentId') == agent_id:
        value = item.get('model')
        print(value.strip() if isinstance(value, str) else '')
        raise SystemExit(0)
print('')
PY
)"
if [[ -n "$HOOK_MODEL" ]]; then
  if openclaw agent --agent "$EXPECTED_AGENT" --message "reply OK" --model "$HOOK_MODEL" --json --timeout 120 >"$MODEL_TEST_JSON"; then
    if MODEL_TEST_JSON="$MODEL_TEST_JSON" /usr/bin/python3 - <<'PY'
import json, os, sys
from pathlib import Path
data = json.loads(Path(os.environ['MODEL_TEST_JSON']).read_text())
texts = []
def walk(node):
    if isinstance(node, dict):
        for key, value in node.items():
            if key in ('finalAssistantVisibleText', 'finalAssistantRawText') and isinstance(value, str):
                texts.append(value.strip())
            walk(value)
    elif isinstance(node, list):
        for item in node:
            walk(item)
walk(data)
reply = next((item for item in texts if item and item != 'NO_REPLY'), '')
if not reply:
    print('[FAIL] explicit hook model override direct test did not produce a visible reply')
    sys.exit(1)
print(f"[PASS] explicit hook model override is authorized via direct test: {reply[:120]}")
PY
    then
      pass "hook model override direct test succeeded: $HOOK_MODEL"
    else
      status=1
    fi
  else
    fail "hook model override direct test failed: $HOOK_MODEL"
  fi
else
  pass 'no explicit hook model override configured'
fi

if [[ "$PUBLIC_WEBHOOK_URL" != *YOUR_HOST_NAME* ]]; then
  if /usr/bin/python3 /home/hjhlarsen/basicops-agent-bundle/scripts/ensure_basicops_webhook.py --profile meriam --agent-id meriam --public-webhook-url "$PUBLIC_WEBHOOK_URL" --wrapper-path /home/hjhlarsen/basicops-agent-bundle/scripts/basicops_mcp.py; then
    pass 'BasicOps registration check passed'
  else
    fail 'BasicOps registration check failed'
  fi
fi

echo
echo 'Expected evidence chain for the first real BasicOps test:'
echo '1. public webhook returns 200'
echo '2. pre-ack logs show the incoming event'
echo '3. OpenClaw hook responds successfully'
echo '4. the target agent session store updates'
echo '5. BasicOps shows the reply'
echo
echo 'Important: use a real BasicOps message for the first end-to-end replay.'
echo 'Synthetic payloads or fake IDs can prove session creation, but reply posting may still fail with "Message not found".'

if [[ $status -eq 0 ]]; then
  echo 'RESULT: PASS. The install looks ready for the first real BasicOps message.'
else
  echo 'RESULT: FAIL. Fix the failing layer above before testing in BasicOps.'
fi
exit $status
