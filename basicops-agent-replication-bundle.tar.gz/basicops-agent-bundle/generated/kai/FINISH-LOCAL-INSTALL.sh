#!/usr/bin/env bash
set -euo pipefail

echo 'TARGET AGENT: kai'
echo 'READ ONLY: /home/hjhlarsen/basicops-agent-bundle/generated/kai/NEXT-STEPS.md'
echo 'Finishing local install for kai...'

/usr/bin/python3 /home/hjhlarsen/basicops-agent-bundle/scripts/basicops_mcp.py --as kai get-self-context --agent-id kai --cache-path /home/hjhlarsen/.cache/basicops-agents/kai-self.json --refresh

/usr/bin/python3 /home/hjhlarsen/basicops-agent-bundle/scripts/render_basicops_hook_config.py --template /home/hjhlarsen/basicops-agent-bundle/templates/prompts/basicops-worker-policy.template.md --openclaw-config /home/hjhlarsen/.openclaw/openclaw.json --self-context-cache /home/hjhlarsen/.cache/basicops-agents/kai-self.json --agent-id kai --basicops-profile kai --hook-path basicops-kai --display-name Kai --mapping-name "BasicOps Kai Hook" --wrapper-path /home/hjhlarsen/basicops-agent-bundle/scripts/basicops_mcp.py --mode render --stdout summary

/usr/bin/python3 /home/hjhlarsen/basicops-agent-bundle/scripts/render_basicops_hook_config.py --template /home/hjhlarsen/basicops-agent-bundle/templates/prompts/basicops-worker-policy.template.md --openclaw-config /home/hjhlarsen/.openclaw/openclaw.json --self-context-cache /home/hjhlarsen/.cache/basicops-agents/kai-self.json --agent-id kai --basicops-profile kai --hook-path basicops-kai --display-name Kai --mapping-name "BasicOps Kai Hook" --wrapper-path /home/hjhlarsen/basicops-agent-bundle/scripts/basicops_mcp.py --hooks-token 082533d9f6b900e05ed9884ac8c655db6715370ee5909a40 --mode apply --backup

openclaw gateway restart
openclaw gateway status

systemctl --user daemon-reload
systemctl --user enable --now basicops-preack@kai.service
systemctl --user status basicops-preack@kai.service --no-pager

export OPENCLAW_HOOKS_TOKEN="$(/usr/bin/python3 - <<'PY'
import json
from pathlib import Path
cfg = json.loads(Path("/home/hjhlarsen/.openclaw/openclaw.json").expanduser().read_text())
hooks = cfg.get('hooks') if isinstance(cfg.get('hooks'), dict) else {}
value = hooks.get('token') if isinstance(hooks.get('token'), str) else ''
print(value.strip())
PY
)"
curl -i -sS http://127.0.0.1:18789/hooks/basicops-kai -H "Authorization: Bearer ${OPENCLAW_HOOKS_TOKEN:?set OPENCLAW_HOOKS_TOKEN first}" -H 'Content-Type: application/json' --data-binary '{}'
