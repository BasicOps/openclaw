# Quick Start

This is now the **manual quickstart**.

If the target machine already has OpenClaw running and the operator is not comfortable with Linux setup, use these files instead:

- `START-HERE.md`
- `INSTALL-WITH-OPENCLAW.md`

Use this document when you want the fastest manual path to get the bundle onto a target machine, scaffold an agent, and hand the operator a clean `NEXT-STEPS.md` to finish from.

This bundle supports both common local service managers used in this flow:

- **Linux**: `systemctl --user`
- **macOS**: `launchd` / `launchctl`

OpenClaw commands like `openclaw gateway status` are the same on both platforms.

## Fast path

1. unpack the bundle on the target machine
2. make sure the machine has the required tools
3. run guided setup
4. restart the gateway if guided setup changed `agents.list`
5. open the generated `NEXT-STEPS.md` and follow it in order

## 1. Unpack the bundle

```bash
BUNDLE_DIR=~/basicops-agent-bundle
if [ -d "$BUNDLE_DIR" ] && [ -n "$(ls -A "$BUNDLE_DIR" 2>/dev/null)" ]; then
  echo "Directory already exists and is not empty: $BUNDLE_DIR"
  echo "Please remove it or choose a different bundle directory."
  exit 1
fi
mkdir -p "$BUNDLE_DIR"
tar -xzf basicops-agent-replication-bundle.tar.gz -C "$BUNDLE_DIR" --strip-components=1
```

## 2. Make sure the machine has the basics

Before guided setup can succeed, the target machine should already have:

- `python3`
- `openclaw`
- `mcporter`
- either a working default OpenClaw model/runtime already configured on the machine, or a specific runtime CLI you intentionally plan to use

Check first:

```bash
python3 --version
openclaw status
mcporter --version
```

If `python3` is missing, install it first.

Examples:

- Debian or Ubuntu:

```bash
sudo apt update
sudo apt install -y python3
```

- macOS with Homebrew:

```bash
brew install python
```

Install `mcporter` if needed:

```bash
sudo npm install -g mcporter
mcporter --version
```

Recommended path: use `--runtime same-as-main` so the new agent inherits the same already-working model/runtime as `main`.

Only if you explicitly choose Codex, install and verify it like this:

```bash
npm install -g @openai/codex
codex --version
codex login status
```

If the Codex install fails with a permissions error, retry with:

```bash
sudo npm install -g @openai/codex
codex --version
codex login status
```

If you choose Codex, also confirm the bundle preflight reports the OpenClaw `acpx` plugin as enabled, not just that the `codex` binary exists.

## 3. Run guided setup

Recommended path:

```bash
python3 ~/basicops-agent-bundle/scripts/guided_setup_agent.py \
  --runtime same-as-main
```

The script now asks for the agent ID up front. If you just press Enter, the default is `helper`.

What guided setup does:

1. runs preflight checks
2. asks for the key values first, including agent ID, display name, profile, hook path, and shim port
3. scaffolds the agent-specific files
4. can add the agent to `agents.list`
5. writes a generated `NEXT-STEPS.md`

On a fresh OpenClaw install, if guided setup registers the first explicit non-main agent, it also seeds a safe default `main` agent so the web control panel keeps working.
By default, if guided setup updates `~/.openclaw/openclaw.json`, it creates a timestamped backup first.
By default, the generated hook mapping does not force a hook model override anymore. If you intentionally want to force a specific route, set an explicit `--hook-model` yourself only after the generated self-test succeeds. In non-interactive assistant flows, prefer `RUN-OPENCLAW-AGENT-SELFTEST.sh` plus `CHECK-OPENCLAW-AGENT-SELFTEST.sh`. In a normal terminal, `OPENCLAW-AGENT-SELFTEST.sh` is fine. If you do not have the generated helper available, capture any low-level `openclaw agent` test to files and inspect those artifacts instead of trusting shell summaries.

Before BasicOps registration, determine the final public webhook URL you actually want to keep. Prefer a hostname with HTTPS if one exists, and use raw IP plus HTTP only as a temporary fallback. Check public DNS separately from local host resolution, for example with `dig @1.1.1.1 <hostname>`, because `/etc/hosts` on the server can point a valid public hostname at `127.0.0.1` or `127.0.1.1`.

If guided setup updates `agents.list`, restart the gateway before live testing:

```bash
openclaw gateway restart
openclaw gateway status
```

If `openclaw gateway restart` prints a quick failure, do not assume the restart really failed. On slower hosts it can time out before the gateway is ready. Wait about 30 seconds and run `openclaw gateway status` again before retrying.

## 4. Finish setup using the generated handoff

Open the generated file for your agent, for example:

- `~/basicops-agent-bundle/generated/helper/NEXT-STEPS.md`

Guided setup prints the exact path it wrote. Once that file exists, the rest of the setup should be done by following that document.

That file is the real handoff. It contains the agent-specific values and the final steps for:

- making the generated files live
- finishing BasicOps persona setup
- applying the OpenClaw hook mapping
- starting the local shim service
- configuring the reverse proxy
- testing locally first, then externally, then in BasicOps

If this is a brand new BasicOps-backed identity, the operator still needs to create the BasicOps user and API key manually. The bundle only handles the local-machine and OpenClaw side.

## Other entry points

### Preflight only

```bash
python3 ~/basicops-agent-bundle/scripts/preflight_replication_bundle.py \
  --runtime same-as-main
```

JSON mode:

```bash
python3 ~/basicops-agent-bundle/scripts/preflight_replication_bundle.py \
  --runtime same-as-main \
  --json
```

### Scaffold directly if you already know the values

```bash
python3 ~/basicops-agent-bundle/scripts/scaffold_agent_from_bundle.py \
  --output-dir ~/basicops-agent-bundle/generated/ops \
  --agent-id ops \
  --display-name OpsAgent \
  --basicops-profile ops \
  --hook-path basicops-ops \
  --shim-port 18892 \
  --register-agent
```

Then open:

- `~/basicops-agent-bundle/generated/ops/NEXT-STEPS.md`

### Full manual guide

If you want the detailed path:

- `docs/INSTALL.md`

## What matters most

For a new operator, the important values are just these three:

- the generated hook path
- the generated local shim port
- the public webhook path used in BasicOps

Those three values must line up.

## Main files

- quickstart: `QUICKSTART.md`
- full manual guide: `docs/INSTALL.md`
- guided setup: `scripts/guided_setup_agent.py`
- preflight: `scripts/preflight_replication_bundle.py`
- scaffolder: `scripts/scaffold_agent_from_bundle.py`
- bundle overview: `README.md`
