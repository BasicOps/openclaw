#!/usr/bin/env python3
import argparse
import json
import re
import sys
from typing import Any

from basicops_payload_compat import REPLY_EVENT_TYPES, coerce_primary_event
from basicops_event_semantics import MESSAGE_SURFACES, normalize_basicops_event_semantics



def _clean_terms(terms: list[str] | set[str] | tuple[str, ...] | None) -> list[str]:
    cleaned = []
    seen = set()
    for term in terms or []:
        if not isinstance(term, str):
            continue
        value = term.strip()
        if not value:
            continue
        key = value.casefold()
        if key in seen:
            continue
        seen.add(key)
        cleaned.append(value)
    return cleaned



def _has_any_term(text: str, terms: list[str]) -> bool:
    if not text or not terms:
        return False
    for term in terms:
        pattern = rf"(?<!\w)@?{re.escape(term)}(?!\w)"
        if re.search(pattern, text, flags=re.I):
            return True
    return False



def _is_project_team_membership_notice(text: str, self_terms: list[str]) -> bool:
    if not text or not self_terms:
        return False
    for term in self_terms:
        added_pattern = rf"\badded\s+@?{re.escape(term)}\s+to\s+the\s+project\s+team\b"
        removed_pattern = rf"\bremoved\s+@?{re.escape(term)}\s+from\s+the\s+project\s+team\b"
        if re.search(added_pattern, text, flags=re.I) or re.search(removed_pattern, text, flags=re.I):
            return True
    return False



def normalize_basicops_skill_payload(payload: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValueError("payload must be a dict")

    if isinstance(payload.get("context"), dict) and "events" not in payload:
        context = dict(payload["context"])
        if not isinstance(context.get("event"), str) and isinstance(payload.get("event"), str):
            context["event"] = payload["event"]
        skill_payload: dict[str, Any] = {
            "context": context,
            "request": payload.get("request") if isinstance(payload.get("request"), str) else "",
        }
        if isinstance(payload.get("instructions"), str):
            skill_payload["instructions"] = payload["instructions"]
        if isinstance(payload.get("agentInstructions"), str):
            skill_payload["agentInstructions"] = payload["agentInstructions"]
        return skill_payload

    normalized = normalize_basicops_event_semantics(payload)
    event_type = normalized["event"]["type"]
    trigger = normalized["trigger"]

    context: dict[str, Any] = {
        "event": event_type,
        "userId": trigger.get("authorUserId"),
    }
    if trigger.get("taskId") is not None:
        context["taskId"] = trigger["taskId"]
    if trigger.get("projectId") is not None:
        context["projectId"] = trigger["projectId"]
    if trigger.get("chatId") is not None:
        context["chatId"] = trigger["chatId"]
    if trigger.get("groupChatId") is not None:
        context["groupChatId"] = trigger["groupChatId"]
    if trigger.get("channelId") is not None:
        context["channelId"] = trigger["channelId"]

    if normalized["event"]["surface"] in MESSAGE_SURFACES or event_type in REPLY_EVENT_TYPES:
        context["messageId"] = trigger.get("replyTargetMessageId")
    if event_type in REPLY_EVENT_TYPES and trigger.get("messageEntityId") is not None:
        context["replyId"] = trigger["messageEntityId"]

    skill_payload = {
        "context": context,
        "request": normalized["request"]["html"] if isinstance(normalized["request"]["html"], str) else "",
    }

    event = coerce_primary_event(payload)
    instructions = event.get("instructions") if isinstance(event.get("instructions"), str) else payload.get("instructions")
    if isinstance(instructions, str):
        skill_payload["instructions"] = instructions

    agent_instructions = event.get("agentInstructions") if isinstance(event.get("agentInstructions"), str) else payload.get("agentInstructions")
    if isinstance(agent_instructions, str):
        skill_payload["agentInstructions"] = agent_instructions

    return skill_payload



def normalize_basicops_event(
    payload: dict[str, Any],
    *,
    agent_id: str,
    agent_name: str | None = None,
    self_user_id: int | str | None = None,
    mention_terms: list[str] | set[str] | tuple[str, ...] | None = None,
    other_agent_terms: list[str] | set[str] | tuple[str, ...] | None = None,
) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValueError("payload must be a dict")

    base = normalize_basicops_event_semantics(payload)
    request_text = base["request"]["text"]
    self_terms = _clean_terms([
        agent_id,
        agent_name or agent_id,
        *(_clean_terms(mention_terms)),
    ])
    other_terms = _clean_terms(other_agent_terms)

    mentions_self = _has_any_term(request_text, self_terms)
    mentions_other_agents = _has_any_term(request_text, other_terms)
    project_team_membership_notice = (
        base["event"]["surface"] == "project_message"
        and _is_project_team_membership_notice(request_text, self_terms)
    )

    trigger = dict(base["trigger"])
    trigger["selfUserId"] = self_user_id
    trigger["isSelfMessage"] = self_user_id is not None and trigger.get("authorUserId") == self_user_id

    request = dict(base["request"])
    request["mentionsSelf"] = mentions_self
    request["mentionsOtherAgents"] = mentions_other_agents
    request["isProjectTeamMembershipNotice"] = project_team_membership_notice

    return {
        "schemaVersion": "basicops.structured.input/1",
        "agent": {
            "id": agent_id,
            "name": agent_name or agent_id,
            "selfUserId": self_user_id,
        },
        "event": base["event"],
        "trigger": trigger,
        "request": request,
        "context": base["context"],
        "capabilities": base["capabilities"],
        "rawRefs": base["rawRefs"],
    }



def main() -> int:
    parser = argparse.ArgumentParser(description="Normalize a BasicOps webhook payload for the BasicOps structured runtime")
    parser.add_argument("payload", nargs="?", help="Optional path to a JSON payload file. Defaults to stdin.")
    parser.add_argument("--agent-id", default="thor")
    parser.add_argument("--agent-name")
    parser.add_argument("--self-user-id", type=int)
    parser.add_argument("--mention-term", action="append", default=[])
    parser.add_argument("--other-agent-term", action="append", default=[])
    parser.add_argument("--pretty", action="store_true")
    args = parser.parse_args()

    if args.payload:
        with open(args.payload, "r", encoding="utf-8") as f:
            payload = json.load(f)
    else:
        payload = json.load(sys.stdin)

    normalized = normalize_basicops_event(
        payload,
        agent_id=args.agent_id,
        agent_name=args.agent_name,
        self_user_id=args.self_user_id,
        mention_terms=args.mention_term,
        other_agent_terms=args.other_agent_term,
    )

    if args.pretty:
        print(json.dumps(normalized, indent=2))
    else:
        print(json.dumps(normalized))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
