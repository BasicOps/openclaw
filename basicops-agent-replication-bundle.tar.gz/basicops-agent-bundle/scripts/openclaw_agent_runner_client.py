#!/usr/bin/env python3
import json
import os
import socket
import subprocess
import time
import uuid
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_SERVER_PATH = SCRIPT_DIR / "openclaw_agent_command_server.mjs"
DEFAULT_SOCKET_PATH = Path(
    os.environ.get("OPENCLAW_AGENT_COMMAND_SOCKET")
    or (Path.home() / ".cache" / "openclaw" / "agent-command.sock")
)
DEFAULT_STARTUP_TIMEOUT_SECONDS = float(os.environ.get("OPENCLAW_AGENT_COMMAND_STARTUP_TIMEOUT_SECONDS", "8"))
DEFAULT_CONNECT_TIMEOUT_SECONDS = float(os.environ.get("OPENCLAW_AGENT_COMMAND_CONNECT_TIMEOUT_SECONDS", "1.5"))
DEFAULT_DISABLE_WARM = os.environ.get("OPENCLAW_AGENT_COMMAND_DISABLE_WARM", "").strip().lower() in {"1", "true", "yes", "on"}


class RunnerClientError(RuntimeError):
    pass


class WarmRunnerTransportError(RunnerClientError):
    pass


class WarmRunnerApplicationError(RunnerClientError):
    pass


def _compact_output_excerpt(text: str, *, limit: int = 1200) -> str:
    value = (text or "").strip()
    if len(value) <= limit:
        return value
    return f"{value[:limit]}... [truncated {len(value) - limit} chars]"


def _extract_last_json_line(text: str) -> str | None:
    for line in reversed((text or "").splitlines()):
        candidate = line.strip()
        if candidate.startswith("{") and candidate.endswith("}"):
            return candidate
    return None


def _normalize_socket_response(raw: str) -> dict[str, Any]:
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise WarmRunnerTransportError(f"warm runner returned invalid JSON: {_compact_output_excerpt(raw)}") from exc
    if not isinstance(value, dict):
        raise WarmRunnerTransportError("warm runner response was not a JSON object")
    return value


def _socket_request(*, socket_path: Path, request: dict[str, Any], timeout_seconds: float) -> dict[str, Any]:
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
            client.settimeout(timeout_seconds)
            client.connect(str(socket_path))
            payload = json.dumps(request, separators=(",", ":"), ensure_ascii=False).encode("utf-8") + b"\n"
            client.sendall(payload)
            chunks: list[bytes] = []
            while True:
                chunk = client.recv(65536)
                if not chunk:
                    break
                chunks.append(chunk)
    except FileNotFoundError as exc:
        raise WarmRunnerTransportError(f"warm runner socket not found at {socket_path}") from exc
    except (ConnectionRefusedError, ConnectionResetError, socket.timeout, OSError) as exc:
        raise WarmRunnerTransportError(f"warm runner request failed: {exc}") from exc

    raw = b"".join(chunks).decode("utf-8", errors="replace").strip()
    if not raw:
        raise WarmRunnerTransportError("warm runner returned an empty response")
    response = _normalize_socket_response(raw)
    status = response.get("status")
    if status == "success":
        envelope = response.get("envelope")
        if not isinstance(envelope, dict):
            raise WarmRunnerTransportError("warm runner success response omitted envelope")
        return envelope

    error = response.get("error") if isinstance(response.get("error"), dict) else {}
    message = error.get("message") if isinstance(error.get("message"), str) else "warm runner request failed"
    retryable = bool(error.get("retryable"))
    if retryable:
        raise WarmRunnerTransportError(message)
    raise WarmRunnerApplicationError(message)


def _spawn_warm_runner(*, server_path: Path, socket_path: Path) -> None:
    socket_path.parent.mkdir(parents=True, exist_ok=True)
    with open(os.devnull, "wb") as devnull:
        subprocess.Popen(
            ["node", str(server_path), "--socket", str(socket_path)],
            stdin=subprocess.DEVNULL,
            stdout=devnull,
            stderr=devnull,
            start_new_session=True,
            cwd=str(SCRIPT_DIR),
        )


def _invoke_via_warm_runner(
    *,
    runner_request: dict[str, Any],
    server_path: Path,
    socket_path: Path,
    startup_timeout_seconds: float,
    connect_timeout_seconds: float,
) -> dict[str, Any]:
    wire_request = {
        "protocolVersion": 1,
        "requestId": str(uuid.uuid4()),
        **runner_request,
    }
    try:
        envelope = _socket_request(
            socket_path=socket_path,
            request=wire_request,
            timeout_seconds=max(connect_timeout_seconds, float(runner_request.get("timeoutSeconds") or 180) + 30.0),
        )
        envelope.setdefault("runnerTransport", {"mode": "warm"})
        return envelope
    except WarmRunnerApplicationError:
        raise
    except WarmRunnerTransportError as first_error:
        _spawn_warm_runner(server_path=server_path, socket_path=socket_path)
        deadline = time.monotonic() + startup_timeout_seconds
        last_error: Exception = first_error
        while time.monotonic() < deadline:
            time.sleep(0.2)
            try:
                envelope = _socket_request(
                    socket_path=socket_path,
                    request=wire_request,
                    timeout_seconds=max(connect_timeout_seconds, float(runner_request.get("timeoutSeconds") or 180) + 30.0),
                )
                envelope.setdefault("runnerTransport", {"mode": "warm"})
                return envelope
            except WarmRunnerApplicationError:
                raise
            except WarmRunnerTransportError as exc:
                last_error = exc
        raise WarmRunnerTransportError(str(last_error)) from last_error


def _invoke_via_one_shot_runner(*, runner_path: Path, runner_request: dict[str, Any]) -> dict[str, Any]:
    cmd = ["node", str(runner_path), "--input", "-"]
    proc = subprocess.run(cmd, input=json.dumps(runner_request), capture_output=True, text=True)
    if proc.returncode != 0:
        raise RunnerClientError(
            "Thor invocation failed with exit "
            f"{proc.returncode}: {(_compact_output_excerpt(proc.stderr or proc.stdout or ''))}"
        )

    raw_json = _extract_last_json_line(proc.stdout)
    if not raw_json:
        raise RunnerClientError(
            f"Thor invocation returned invalid JSON envelope: {_compact_output_excerpt(proc.stdout)}"
        )

    try:
        invocation_result = json.loads(raw_json)
    except json.JSONDecodeError as exc:
        raise RunnerClientError(
            f"Thor invocation returned invalid JSON envelope: {_compact_output_excerpt(proc.stdout)}"
        ) from exc
    if isinstance(invocation_result, dict):
        invocation_result.setdefault("runnerTransport", {"mode": "cold"})
    return invocation_result


def invoke_agent_runner(
    *,
    runner_request: dict[str, Any],
    runner_path: Path,
    server_path: Path | None = None,
    socket_path: Path | None = None,
    startup_timeout_seconds: float = DEFAULT_STARTUP_TIMEOUT_SECONDS,
    connect_timeout_seconds: float = DEFAULT_CONNECT_TIMEOUT_SECONDS,
    disable_warm: bool = DEFAULT_DISABLE_WARM,
) -> dict[str, Any]:
    server_path = server_path or DEFAULT_SERVER_PATH
    socket_path = socket_path or DEFAULT_SOCKET_PATH

    warm_error: str | None = None
    if not disable_warm:
        try:
            return _invoke_via_warm_runner(
                runner_request=runner_request,
                server_path=server_path,
                socket_path=socket_path,
                startup_timeout_seconds=startup_timeout_seconds,
                connect_timeout_seconds=connect_timeout_seconds,
            )
        except WarmRunnerApplicationError as exc:
            raise RunnerClientError(str(exc)) from exc
        except WarmRunnerTransportError as exc:
            warm_error = str(exc)

    invocation_result = _invoke_via_one_shot_runner(runner_path=runner_path, runner_request=runner_request)
    if warm_error and isinstance(invocation_result, dict):
        invocation_result["runnerTransport"] = {
            "mode": "cold-fallback",
            "warmError": warm_error,
        }
    return invocation_result
