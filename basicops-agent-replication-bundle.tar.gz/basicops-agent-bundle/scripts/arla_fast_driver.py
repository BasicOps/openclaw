#!/usr/bin/env python3
import argparse
import subprocess
import sys
from pathlib import Path

GENERIC_DRIVER = Path('/home/hjhlarsen/basicops-agent-bundle/scripts/basicops_fast_driver.py')


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description='Arla fast driver wrapper delegating to the generic BasicOps fast driver')
    parser.add_argument('payload', help='Webhook payload JSON file')
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--execute', action='store_true', help='Execute the Arla fast runtime result')
    mode.add_argument('--dry-run', action='store_true', help='Only build the Arla fast runtime result')
    parser.add_argument('--profile', default='arla')
    parser.add_argument('--arla-session-key', help='Optional explicit Arla session key to reuse for latency tests')
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    cmd = [
        sys.executable,
        str(GENERIC_DRIVER),
        args.payload,
        '--profile',
        args.profile,
        '--agent-id',
        'arla',
    ]
    if args.execute:
        cmd.append('--execute')
    if args.dry_run:
        cmd.append('--dry-run')
    if args.arla_session_key:
        cmd.extend(['--runtime-session-key', args.arla_session_key])
    proc = subprocess.run(cmd)
    return proc.returncode


if __name__ == '__main__':
    raise SystemExit(main())
